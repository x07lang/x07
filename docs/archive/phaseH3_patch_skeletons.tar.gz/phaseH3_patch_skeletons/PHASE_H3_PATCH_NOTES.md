# Phase H3 patch skeletons (standalone OS host adapters)

This folder contains **repo-aligned skeleton files** for implementing:

- `run-os` (standalone-only world)
- `run-os-sandboxed` (standalone-only world, policy-limited sandbox)
- OS-backed stdlib adapters: `std.os.fs`, `std.os.net`, `std.os.process`, `std.os.env`, `std.os.time`
- World binding pattern via `std.world.*` adapters so the **same program source** can run in:
  - deterministic fixture worlds (evaluation)
  - OS worlds (standalone usage)

> **Important:** The evaluator MUST NEVER run `run-os*` worlds. These skeletons include an evaluator gating patch and a shared `evolang-worlds` crate to enforce that.

## What’s included

- `docs/standalone/*`: design docs + security notes
- `schemas/run-os-policy.schema.json`: JSON schema for sandbox policy files
- `worlds/worlds.json`: world registry (string ids → capabilities → eval/standalone tier)
- `crates/evolang-worlds`: shared world registry helper crate (Rust)
- `crates/evolang-os-runner`: standalone runner binary stub (Rust)
- `stdlib/os/0.1.0/*`: OS stdlib package skeleton (Evolang modules)
- `stdlib/std/0.1.0/world/*`: deterministic fixture adapters (Evolang modules)
- `patches/*.patch`: small **surgical patch snippets** you apply to the existing repo

## How to apply (suggested PR breakdown)

### PR H3-01 — Worlds registry + evaluator denylist

1. Add:
   - `worlds/worlds.json`
   - `crates/evolang-worlds`
   - `docs/standalone/run-os.md`
2. Apply `patches/H3-01_evaluator_gate.patch`.

### PR H3-02 — `evolang-os-runner` CLI

1. Add:
   - `crates/evolang-os-runner`
2. Wire it into workspace `Cargo.toml` (see `patches/H3-02_workspace.patch`).

### PR H3-03 — OS policy schema + sandbox scaffolding

1. Add:
   - `schemas/run-os-policy.schema.json`
   - `crates/evolang-os-runner/src/sandbox/*`
2. Implement Linux/Windows sandboxing incrementally (stubs compile today).

### PR H3-04 — `stdlib-os` package + `std.world.*` adapters

1. Add:
   - `stdlib/os/0.1.0/...` (OS adapters)
   - `stdlib/std/0.1.0/world/...` (fixture adapters)
2. Update `stdlib.lock` (or add a `stdlib.os.lock` profile) so `std.world.*` resolves differently in eval vs OS.

### PR H3-05 — Compiler support for `os.*` builtins (standalone-only)

This skeleton assumes new builtins (examples):

- `os.fs.read_file(path: bytes) -> bytes`
- `os.fs.write_file(path: bytes, data: bytes) -> i32`
- `os.env.get(name: bytes) -> bytes`
- `os.time.now_unix_ms() -> i64`
- `os.process.exit(code: i32) -> i32`
- `os.net.http_request(req_bytes: bytes) -> bytes` (optional, later)

Add C codegen hooks and runtime implementations in `crates/evolangc/src/c_emit.rs`.
See `patches/H3-05_c_emit_os_builtins.patch` for the exact insertion points.

## Local smoke (standalone-only)

Once H3-05 exists, you should be able to run:

```bash
cargo run -p evolang-os-runner -- \
  --world run-os \
  --langdef langdef/bundle.json \
  --stdlib-lock stdlib.os.lock \
  examples/h3/read_config_report.evo < input.bin > out.bin
```

## Security notes

- Linux **seccomp is not a sandbox** by itself; it’s a syscall-filtering mechanism intended to be combined with other hardening techniques (namespaces, LSM, etc.). citeturn0search0
- OpenBSD `pledge(2)` and `unveil(2)` are examples of capability-oriented OS primitives you can emulate conceptually (policy-driven deny-by-default). citeturn0search1turn0search13
- FreeBSD Capsicum capability mode is a reference model for “no global namespaces, only capabilities” execution. citeturn0search2
- Windows Job Objects support imposing memory/time/process limits at the OS level. citeturn0search3turn0search7

