# Sandboxing notes (portable, best-effort)

This doc is intentionally pragmatic: Evolang `run-os-sandboxed` is **opt-in** and is never used in deterministic evaluation.

## Linux

- Use rlimits as a universal kill-switch.
- Use namespaces (user/mount/net) + a minimal rootfs when possible.
- Use seccomp-BPF as **syscall filtering**.
  - Note: syscall filtering **is not a sandbox** by itself; it should be combined with other hardening mechanisms. citeturn0search0

## OpenBSD

- `pledge(2)` + `unveil(2)` are very nice primitives to restrict capabilities of a process. citeturn0search1turn0search13

## FreeBSD

- Capsicum capability mode provides a strong conceptual model: once in capability mode, you can only operate on existing capabilities (file descriptors), not global namespaces. citeturn0search2

## Windows

- Job Objects can constrain memory and CPU time; they are useful as baseline sandbox primitives. citeturn0search3turn0search7
