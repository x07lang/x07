# run-os-sandboxed world (standalone-only)

`run-os-sandboxed` is like `run-os`, but access is restricted by a **policy file**.

## Enforcement goals

- Deny-by-default: only explicitly allowed FS roots, net destinations, env keys, etc.
- OS-level enforcement when possible (seccomp, job objects, capability mode), not cooperative checks.
- Fail closed: if sandbox primitives are unavailable, the runner should refuse to start unless `--allow-unsafe` is passed.

## Policy file

See `schemas/run-os-policy.schema.json` for the normative shape.
