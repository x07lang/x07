# run-os world (standalone-only)

`run-os` is a **standalone-only** capability world for Evolang programs compiled to native C.

## Properties

- Real OS filesystem/network/time/env/process access (capability-scoped).
- Not deterministic (by design).
- **Never used by evaluator**. The evaluator must reject `run-os`/`run-os-sandboxed` suites.

## Intended usage

- Development: run Evolang programs like normal CLI tools.
- Production: run in `run-os-sandboxed` with a policy file.

## Contract with stdlib

Stdlib should be written against `std.io` traits and `std.world.*` adapters:

- `std.fs` imports `std.world.fs`
- `std.net` imports `std.world.net`
- etc.

In deterministic evaluation, `std.world.*` resolves to fixture-backed adapters.
In standalone, it resolves to OS-backed adapters.

This separation keeps program source identical; only the lockfile/world binding changes.
