use clap::Parser;
use evolang_worlds::WorldId;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

mod policy;
mod sandbox;

#[derive(Parser, Debug)]
#[command(name = "evolang-os-runner")]
#[command(about = "Standalone Evolang runner (run-os / run-os-sandboxed worlds).", long_about = None)]
struct Args {
    /// Which world to run in: run-os or run-os-sandboxed.
    #[arg(long)]
    world: String,

    /// Path to the program (.evo).
    #[arg(value_name = "PROGRAM_EVO")]
    program: PathBuf,

    /// Path to the pinned LangDef bundle.
    #[arg(long)]
    langdef: PathBuf,

    /// Path to the stdlib lockfile used for module resolution.
    #[arg(long)]
    stdlib_lock: PathBuf,

    /// Policy file (required for run-os-sandboxed).
    #[arg(long)]
    policy: Option<PathBuf>,

    /// Allow running run-os-sandboxed without OS-level sandbox support (unsafe).
    #[arg(long, default_value_t = false)]
    allow_unsafe: bool,

    /// Keep intermediate C / executable artifacts.
    #[arg(long, default_value_t = false)]
    keep_temp: bool,
}

fn main() {
    if let Err(e) = real_main() {
        eprintln!("evolang-os-runner: error: {e}");
        std::process::exit(2);
    }
}

fn real_main() -> Result<(), String> {
    let args = Args::parse();

    let world = WorldId::parse(&args.world)
        .ok_or_else(|| format!("unknown world: {}", args.world))?;

    if world.is_eval_world() {
        return Err(format!(
            "refusing to run eval world '{}' in evolang-os-runner",
            world.as_str()
        ));
    }

    // Load policy if sandboxed.
    let policy = match world {
        WorldId::RunOs => None,
        WorldId::RunOsSandboxed => {
            let p = args.policy.clone().ok_or_else(|| "--policy is required for run-os-sandboxed".to_string())?;
            let txt = fs::read_to_string(&p).map_err(|e| format!("read policy: {e}"))?;
            let pol: policy::Policy = serde_json::from_str(&txt).map_err(|e| format!("parse policy json: {e}"))?;
            pol.validate_basic()?;
            Some(pol)
        }
        _ => return Err("internal: unexpected world enum".to_string()),
    };

    if let Some(ref pol) = policy {
        sandbox::apply_sandbox(pol).map_err(|e| {
            if args.allow_unsafe {
                eprintln!("WARNING: sandbox requested but not enforced: {e}");
                String::new()
            } else {
                e
            }
        })?;
    }

    // Compile pipeline skeleton: call existing evolangc CLI to emit C, then cc/clang to native exe.
    // This keeps H3 self-contained and avoids exposing OS worlds to the evaluator runner.
    //
    // TODO(H3-05): wire to evolangc crate API directly once stable.

    let tmp = std::env::temp_dir().join(format!("evolang-os-run-{}", std::process::id()));
    fs::create_dir_all(&tmp).map_err(|e| format!("create temp dir: {e}"))?;
    let out_c = tmp.join("prog.c");
    let out_exe = tmp.join("prog.exe");

    compile_to_c(
        &args.program,
        &args.langdef,
        &args.stdlib_lock,
        &out_c,
        world.as_str(),
    )?;
    compile_c_to_exe(&out_c, &out_exe)?;

    // Execute with the selected world in env.
    // Program I/O convention for now: read stdin bytes; write stdout bytes.
    let status = Command::new(&out_exe)
        .env("EVOLANG_WORLD", world.as_str())
        .status()
        .map_err(|e| format!("run exe: {e}"))?;

    if !status.success() {
        return Err(format!("program exited with status: {status}")); 
    }

    if !args.keep_temp {
        let _ = fs::remove_dir_all(&tmp);
    } else {
        eprintln!("kept temp dir: {}", tmp.display());
    }

    Ok(())
}

fn compile_to_c(program: &Path, langdef: &Path, stdlib_lock: &Path, out_c: &Path, world: &str) -> Result<(), String> {
    // Assumes there is an `evolangc-cli` binary on PATH.
    // If not, build it: `cargo build -p evolangc-cli`.
    let status = Command::new("evolangc-cli")
        .arg("compile")
        .arg("--langdef").arg(langdef)
        .arg("--stdlib-lock").arg(stdlib_lock)
        .arg("--world").arg(world)
        .arg("--out-c").arg(out_c)
        .arg(program)
        .status()
        .map_err(|e| format!("spawn evolangc-cli: {e}"))?;
    if !status.success() {
        return Err(format!("evolangc-cli failed: {status}")); 
    }
    Ok(())
}

fn compile_c_to_exe(c_file: &Path, out_exe: &Path) -> Result<(), String> {
    // Prefer cc from PATH. Adjust flags as needed.
    let status = Command::new("cc")
        .arg("-O2")
        .arg("-std=c11")
        .arg(c_file)
        .arg("-o")
        .arg(out_exe)
        .status()
        .map_err(|e| format!("spawn cc: {e}"))?;
    if !status.success() {
        return Err(format!("cc failed: {status}")); 
    }
    Ok(())
}
