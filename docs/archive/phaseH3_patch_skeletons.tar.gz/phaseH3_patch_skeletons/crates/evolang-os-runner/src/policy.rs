use serde::Deserialize;

/// Policy file for `run-os-sandboxed`.
///
/// This should match `schemas/run-os-policy.schema.json` (normative).
#[derive(Debug, Clone, Deserialize)]
pub struct Policy {
    pub schema_version: String,
    pub policy_id: String,
    pub notes: Option<String>,
    pub limits: Limits,
    pub fs: Fs,
    pub net: Net,
    pub env: Env,
    pub time: Time,
    pub process: Process,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Limits {
    pub cpu_ms: u64,
    pub wall_ms: u64,
    pub mem_bytes: u64,
    pub fds: u32,
    pub procs: u32,
    pub core_dumps: Option<bool>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Fs {
    pub enabled: bool,
    pub read_roots: Vec<String>,
    pub write_roots: Vec<String>,
    pub deny_hidden: bool,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Net {
    pub enabled: bool,
    pub allow_dns: bool,
    pub allow_tcp: bool,
    pub allow_udp: bool,
    pub allow_hosts: Vec<NetHost>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct NetHost {
    pub host: String,
    pub ports: Vec<u16>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Env {
    pub enabled: bool,
    pub allow_keys: Vec<String>,
    pub deny_keys: Vec<String>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Time {
    pub enabled: bool,
    pub allow_monotonic: bool,
    pub allow_wall_clock: bool,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Process {
    pub enabled: bool,
    pub allow_spawn: bool,
    pub allow_exec: bool,
    pub allow_exit: bool,
}

impl Policy {
    pub fn validate_basic(&self) -> Result<(), String> {
        if self.schema_version != "evolang.run-os-policy@0.1.0" {
            return Err(format!("unsupported schema_version: {}", self.schema_version));
        }
        if self.policy_id.is_empty() || self.policy_id.len() > 64 {
            return Err("policy_id length invalid".to_string());
        }
        Ok(())
    }
}
