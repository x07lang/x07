//! Sandbox implementations.
//!
//! The goal is "best-effort OS enforcement", not perfect portability.
//! If the sandbox is requested but unavailable, the runner should fail closed
//! unless --allow-unsafe is provided.

use crate::policy::Policy;

pub fn apply_sandbox(_policy: &Policy) -> Result<(), String> {
    // Skeleton behavior:
    // - In PR H3-03, implement rlimits + per-OS sandbox.
    // - For now, do nothing.
    Ok(())
}
