//! Shared world registry helpers.
//!
//! This crate exists so both:
//! - the evaluator (Python) and
//! - runners (Rust)
//! can share an authoritative list of worlds and whether they are allowed in evaluation.

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum WorldId {
    SolvePure,
    SolveFs,
    SolveRr,
    SolveKv,
    SolveFull,
    RunOs,
    RunOsSandboxed,
}

impl WorldId {
    pub fn as_str(self) -> &'static str {
        match self {
            WorldId::SolvePure => "solve-pure",
            WorldId::SolveFs => "solve-fs",
            WorldId::SolveRr => "solve-rr",
            WorldId::SolveKv => "solve-kv",
            WorldId::SolveFull => "solve-full",
            WorldId::RunOs => "run-os",
            WorldId::RunOsSandboxed => "run-os-sandboxed",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "solve-pure" => Some(WorldId::SolvePure),
            "solve-fs" => Some(WorldId::SolveFs),
            "solve-rr" => Some(WorldId::SolveRr),
            "solve-kv" => Some(WorldId::SolveKv),
            "solve-full" => Some(WorldId::SolveFull),
            "run-os" => Some(WorldId::RunOs),
            "run-os-sandboxed" => Some(WorldId::RunOsSandboxed),
            _ => None,
        }
    }

    /// True if this world is permitted in the evaluator.
    pub fn is_eval_world(self) -> bool {
        matches!(
            self,
            WorldId::SolvePure | WorldId::SolveFs | WorldId::SolveRr | WorldId::SolveKv | WorldId::SolveFull
        )
    }

    /// True if this world is never permitted in deterministic evaluation.
    pub fn is_standalone_only(self) -> bool {
        matches!(self, WorldId::RunOs | WorldId::RunOsSandboxed)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn eval_worlds_are_not_standalone_only() {
        for &w in &[
            WorldId::SolvePure,
            WorldId::SolveFs,
            WorldId::SolveRr,
            WorldId::SolveKv,
            WorldId::SolveFull,
        ] {
            assert!(w.is_eval_world());
            assert!(!w.is_standalone_only());
        }
    }

    #[test]
    fn standalone_worlds_are_not_eval_worlds() {
        for &w in &[WorldId::RunOs, WorldId::RunOsSandboxed] {
            assert!(!w.is_eval_world());
            assert!(w.is_standalone_only());
        }
    }
}
