<!-- EVSL_V1_BEGIN -->
## Slice lists (EVSL v1)

Some stdlib APIs return a **slice list**: a list of (start,len) pairs pointing into an underlying `bytes`/`bytes_view`
buffer. This enables zero-copy text scanning and parsing while keeping encodings deterministic.

**All slice lists MUST be encoded as EVSL v1 bytes.** Do not hand-roll alternative encodings.

EVSL v1 binary layout:

- `magic`: 4 bytes ASCII `EVSL`
- `version`: `u32_le` (must be `1`)
- `count`: `u32_le` number of rows
- rows: `count × (start_u32_le, len_u32_le)`

Where each `(start,len)` is a byte range in the **base buffer**. Empty segments are valid (`len=0`) and occur for leading/trailing/consecutive separators.

Use `std.text.slices` for building/validating/accessing EVSL:

- `std.text.slices.validate_v1(evsl_bytes)` -> `result_i32` (OK(count) or ERR(code))
- `std.text.slices.count_v1(evsl_bytes)` -> i32
- `std.text.slices.start_v1(evsl_bytes, idx)` / `len_v1(...)`
- `std.text.slices.view_at_v1(base_view, evsl_bytes, idx)` -> `bytes_view`
- `std.text.slices.copy_at_v1(base_view, evsl_bytes, idx)` -> `bytes`

Known EVSL producers (v1):

- `std.text.ascii.split_lines_view(input_bytes)` -> EVSL v1 bytes (line slices)
- `std.text.ascii.split_u8(view, sep_u8)` -> EVSL v1 bytes (separator slices)

See `docs/text/evsl-v1.md` for the normative EVSL v1 contract.
<!-- EVSL_V1_END -->
