EVSL v1 incremental bundle (for stdlib/std/0.1.1)

This bundle:
- Updates the EVSL smoke suite to v0.1.1 and adds an edgecase task with a matrix of cases.
- Adds a snippet + helper script to ensure docs/spec/language-guide.md explicitly states:
  "slice-list outputs are EVSL v1".
- Provides patch files for docs/spec/language-guide.md and crates/evolangc/src/guide.rs.

Recommended steps:
1) Extract at repo root:
   tar -xzf evsl_v1_incremental_bundle_stdlib_0.1.1.tar.gz

2) Update docs/spec/language-guide.md:
   - Option A (recommended): run
       python3 scripts/patch_language_guide_evsl_v1.py
     then commit the resulting docs/spec/language-guide.md change.
   - Option B: apply patches/*.patch manually (they may require minor context adjustments).

3) Update your guide generator (crates/evolangc/src/guide.rs or equivalent) to include the EVSL section.
   See patches/guide-rs-evsl-v1.patch for a suggested insertion.

4) Run the EVSL smoke suite:
   benchmarks/solve-pure/evsl-v1-smoke.json
