#!/usr/bin/env python3
"""Idempotently inject the EVSL v1 slice-list section into docs/spec/language-guide.md.

This is a dev helper to keep guide text in sync when the file is hand-edited.
It is deterministic and safe to run multiple times.

Usage:
  python3 scripts/patch_language_guide_evsl_v1.py [--check]

Exit codes:
  0: OK (patched or already present)
  2: In --check mode, section missing or differs
  1: Other error
"""

from __future__ import annotations
import argparse
from pathlib import Path

BEGIN = "<!-- EVSL_V1_BEGIN -->"
END = "<!-- EVSL_V1_END -->"

SNIPPET = r"""<!-- EVSL_V1_BEGIN -->
## Slice lists (EVSL v1)

Some stdlib APIs return a **slice list**: a list of (start,len) pairs pointing into an underlying `bytes`/`bytes_view`
buffer. This enables zero-copy text scanning and parsing while keeping encodings deterministic.

**All slice lists MUST be encoded as EVSL v1 bytes.** Do not hand-roll alternative encodings.

EVSL v1 binary layout:

- `magic`: 4 bytes ASCII `EVSL`
- `version`: `u32_le` (must be `1`)
- `count`: `u32_le` number of rows
- rows: `count × (start_u32_le, len_u32_le)`

Where each `(start,len)` is a byte range in the **base buffer**. Empty segments are valid (`len=0`) and occur for leading/trailing/consecutive separators.

Use `std.text.slices` for building/validating/accessing EVSL:

- `std.text.slices.validate_v1(evsl_bytes)` -> `result_i32` (OK(count) or ERR(code))
- `std.text.slices.count_v1(evsl_bytes)` -> i32
- `std.text.slices.start_v1(evsl_bytes, idx)` / `len_v1(...)`
- `std.text.slices.view_at_v1(base_view, evsl_bytes, idx)` -> `bytes_view`
- `std.text.slices.copy_at_v1(base_view, evsl_bytes, idx)` -> `bytes`

Known EVSL producers (v1):

- `std.text.ascii.split_lines_view(input_bytes)` -> EVSL v1 bytes (line slices)
- `std.text.ascii.split_u8(view, sep_u8)` -> EVSL v1 bytes (separator slices)

See `docs/text/evsl-v1.md` for the normative EVSL v1 contract.
<!-- EVSL_V1_END -->
""".rstrip() + "\n"

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()

    path = Path("docs/spec/language-guide.md")
    if not path.exists():
        raise SystemExit(f"missing: {path}")

    s = path.read_text(encoding="utf-8")
    if BEGIN in s and END in s:
        pre, rest = s.split(BEGIN, 1)
        mid, post = rest.split(END, 1)
        current = (BEGIN + mid + END).strip() + "\n"
        desired = SNIPPET
        if current == desired:
            return 0
        if args.check:
            return 2
        path.write_text(pre.rstrip() + "\n\n" + desired + post.lstrip(), encoding="utf-8")
        return 0

    # No markers: append at end.
    if args.check:
        return 2
    path.write_text(s.rstrip() + "\n\n" + SNIPPET, encoding="utf-8")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
