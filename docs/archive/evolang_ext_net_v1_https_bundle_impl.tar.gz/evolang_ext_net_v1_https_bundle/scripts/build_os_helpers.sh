#!/usr/bin/env bash
set -euo pipefail

# Build standalone OS helper binaries deterministically-ish (same inputs => same outputs on same toolchain).
# These are NOT used in solve-* evaluation; they are only for run-os / run-os-sandboxed smoke tests.

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="${ROOT}/deps/evolang"
mkdir -p "${OUT_DIR}"

echo "[build_os_helpers] building evolang-net-stub-server..."
cargo build -q -p evolang-net-stub-server --release

BIN_SRC="${ROOT}/target/release/evolang-net-stub-server"
BIN_DST="${OUT_DIR}/net-stub-server"

if [[ ! -f "${BIN_SRC}" ]]; then
  echo "missing built binary at ${BIN_SRC}" >&2
  exit 1
fi

# Install/copy
cp -f "${BIN_SRC}" "${BIN_DST}"
chmod 0755 "${BIN_DST}"

# Emit checksum for debugging / cache keys
if command -v sha256sum >/dev/null 2>&1; then
  sha256sum "${BIN_DST}" | tee "${BIN_DST}.sha256"
elif command -v shasum >/dev/null 2>&1; then
  shasum -a 256 "${BIN_DST}" | tee "${BIN_DST}.sha256"
fi

echo "[build_os_helpers] OK -> ${BIN_DST}"
