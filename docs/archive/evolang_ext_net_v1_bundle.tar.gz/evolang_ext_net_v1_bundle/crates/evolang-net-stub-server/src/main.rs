use std::env;
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::PathBuf;
use std::time::Duration;

fn parse_arg(flag: &str) -> Option<String> {
    let mut it = env::args().skip(1);
    while let Some(a) = it.next() {
        if a == flag {
            return it.next();
        }
    }
    None
}

fn write_port_file(path: &PathBuf, port: u16) {
    // Best-effort; used for smoke tests only.
    let _ = std::fs::write(path, format!("{}\n", port));
}

fn handle_echo(mut s: TcpStream) {
    let mut buf = [0u8; 64 * 1024];
    loop {
        match s.read(&mut buf) {
            Ok(0) => break,
            Ok(n) => {
                let _ = s.write_all(&buf[..n]);
            }
            Err(_) => break,
        }
    }
}

fn handle_http(mut s: TcpStream) {
    // Minimal HTTP/1.1 parser for smoke tests.
    let mut req = Vec::new();
    let _ = s.set_read_timeout(Some(Duration::from_secs(2)));
    let _ = s.set_write_timeout(Some(Duration::from_secs(2)));

    let mut buf = [0u8; 8192];
    loop {
        match s.read(&mut buf) {
            Ok(0) => break,
            Ok(n) => {
                req.extend_from_slice(&buf[..n]);
                if req.windows(4).any(|w| w == b"\r\n\r\n") {
                    break;
                }
                if req.len() > 64 * 1024 {
                    break;
                }
            }
            Err(_) => break,
        }
    }

    let first_line = req.split(|&b| b == b'\n').next().unwrap_or(&[]);
    let first_line = String::from_utf8_lossy(first_line);
    let mut parts = first_line.split_whitespace();
    let method = parts.next().unwrap_or("");
    let path = parts.next().unwrap_or("/");

    let (status, body) = if method == "GET" && path == "/healthz" {
        (200, b"OK".to_vec())
    } else if method == "GET" && path == "/hello" {
        (200, b"hello".to_vec())
    } else {
        (404, b"not_found".to_vec())
    };

    let resp = format!(
        "HTTP/1.1 {} {}\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
        status,
        if status == 200 { "OK" } else { "Not Found" },
        body.len()
    );

    let _ = s.write_all(resp.as_bytes());
    let _ = s.write_all(&body);
}

fn main() {
    let mode = parse_arg("--mode").unwrap_or_else(|| "tcp-echo".to_string());
    let host = parse_arg("--host").unwrap_or_else(|| "127.0.0.1".to_string());
    let port_base: u16 = parse_arg("--port-base").and_then(|s| s.parse().ok()).unwrap_or(18080);
    let port_max: u16 = parse_arg("--port-max").and_then(|s| s.parse().ok()).unwrap_or(18100);
    let port_file = parse_arg("--port-file").map(PathBuf::from);

    // Bind first available port in range.
    let mut bound = None;
    for p in port_base..=port_max {
        let addr = format!("{}:{}", host, p);
        if let Ok(l) = TcpListener::bind(&addr) {
            bound = Some((l, p));
            break;
        }
    }
    let (listener, port) = bound.expect("no free port in range");
    if let Some(path) = port_file.as_ref() {
        write_port_file(path, port);
    }

    for conn in listener.incoming() {
        match conn {
            Ok(s) => {
                if mode == "http" {
                    handle_http(s);
                } else {
                    handle_echo(s);
                }
            }
            Err(_) => break,
        }
    }
}
