#!/usr/bin/env bash
set -euo pipefail

# Build OS helper binaries deterministically and copy into deps/evolang/
#
# Intended usage:
#   ./scripts/build_os_helpers.sh
#
# Notes:
# - For reproducibility, this script should be run in CI with a fixed Rust toolchain.
# - The produced binary is used only in run-os* smoke suites (never in solve-* evaluation).

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$ROOT/deps/evolang"
mkdir -p "$OUT_DIR"

cargo build -p evolang-net-stub-server --release

BIN="$ROOT/target/release/evolang-net-stub-server"
if [[ -f "$BIN.exe" ]]; then
  cp -f "$BIN.exe" "$OUT_DIR/evolang-net-stub-server.exe"
else
  cp -f "$BIN" "$OUT_DIR/evolang-net-stub-server"
fi
