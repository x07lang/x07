# Evolang Networking v1 (run-os* only)

**Status:** Draft normative spec (net-v1).
**Applies to:** `run-os`, `run-os-sandboxed` only.
**Forbidden in deterministic eval worlds:** any `solve-*` compile target MUST hard-error if the program references any `os.net.*` builtins or `std.os.net` adapters.

This document defines:

- the **bytes-level contracts** (request/response blobs) for OS-backed networking builtins;
- the **sandbox policy** shape needed to control network capability in `run-os-sandboxed`;
- portability rules so the same Evolang program works on Linux/macOS/Windows in `run-os*`.

## 1. Terminology

The keywords **MUST**, **MUST NOT**, **SHOULD**, **MAY** are used as in RFC 2119.

## 2. Determinism separation

Evolang has two execution regimes:

- **Deterministic evaluation worlds** (`solve-*`): networking is not allowed. Any reference to `os.net.*` MUST be rejected at compile time for these worlds.
- **Standalone OS worlds** (`run-os`, `run-os-sandboxed`): networking is allowed (subject to policy); behavior is **not deterministic** and is not used in evaluation.

This separation is non-negotiable: it is what keeps deterministic suites comparable.

## 3. High-level model

- All network operations are expressed as **opaque handles** (`i32`) to runtime-managed resources.
- All data exchange between Evolang and the host adapters uses **explicit byte blobs** with a stable ABI.
- The runtime enforces **caps** on all I/O: timeouts, max bytes, and policy allowlists.

## 4. Canonical integer + string encodings

**Unless explicitly stated otherwise:**

- All multi-byte integers are **u32 little-endian** (stored in 4 bytes).
- Strings are **UTF-8 bytes**; no NUL terminators.
- Boolean fields are stored as u32 (`0` or `1`).

Rationale: Evolang already has stable u32_le helpers; using fixed-width u32_le avoids u16/u64 corner cases for agents.

## 5. Common error model

Host adapters return errors as a **tagged bytes doc**, never by ambient stderr text.

### 5.1 ErrorDocV1

```
ErrorDocV1 :=
  u8  tag = 0
  u32 code_le
  u32 detail_len_le
  u8[detail_len] detail_utf8
```

- `detail_utf8` is optional and MAY be empty.
- `code_le` values are defined in section 11.

## 6. Address encoding

### 6.1 NetAddrV1

```
NetAddrV1 :=
  u8  tag
  u32 port_le      ; 0..65535
  payload...

payload for tag=1 (ipv4):
  u8[4]  ipv4_octets

payload for tag=2 (ipv6):
  u8[16] ipv6_octets

payload for tag=3 (dns name):
  u32 name_len_le
  u8[name_len] name_utf8
```

- IPv4/IPv6 bytes are the standard network-order octets.
- DNS `name_utf8` SHOULD be an ASCII hostname for maximum portability; UTF-8 is allowed but may fail resolution.

### 6.2 NetAddrListDocV1

DNS lookup returns a list doc:

```
NetAddrListDocV1 :=
  u8  tag = 1
  u32 count_le
  repeated count times:
    u32 addr_len_le
    u8[addr_len] NetAddrV1
```

If DNS fails, return `ErrorDocV1` (`tag=0`).

## 7. Capability encoding

### 7.1 NetCapsV1

```
NetCapsV1 :=
  u32 connect_timeout_ms_le
  u32 rw_timeout_ms_le
  u32 max_read_bytes_le
  u32 max_write_bytes_le
  u32 max_total_bytes_le
  u32 flags_le
```

Flags (bitmask in `flags_le`):

- bit 0 (`1`): allow_ipv6
- bit 1 (`2`): allow_dns
- bit 2 (`4`): allow_loopback
- bit 3 (`8`): allow_private_ranges
- bit 4 (`16`): allow_public_internet

Notes:
- `run-os-sandboxed` policy may still deny a request even if caps allow it.
- `max_total_bytes_le` caps the sum of bytes read + written on a socket handle.

## 8. Stream (socket) operations

Streams are opaque `i32` handles. Handle value `0` is reserved as invalid.

### 8.1 Builtins (run-os* only)

- `(os.net.tcp_connect_v1 addr:bytes caps:bytes) -> bytes`
  - returns `StreamDocV1` on success, else `ErrorDocV1`.

- `(os.net.tcp_listen_v1 addr:bytes caps:bytes) -> bytes`
  - returns `ListenerDocV1` on success, else `ErrorDocV1`.

- `(os.net.tcp_accept_v1 listener_handle:i32 caps:bytes) -> bytes`
  - returns `StreamDocV1` or `ErrorDocV1`.

- `(os.net.stream_read_v1 stream_handle:i32 max_bytes:i32 caps:bytes) -> bytes`
  - returns `ReadDocV1`.

- `(os.net.stream_write_v1 stream_handle:i32 data:bytes caps:bytes) -> bytes`
  - returns `WriteDocV1`.

- `(os.net.stream_shutdown_v1 stream_handle:i32 how:i32) -> i32`
  - `how`: 0=read, 1=write, 2=both.

- `(os.net.stream_close_v1 stream_handle:i32) -> i32`
  - closes and releases the handle; idempotent.

- `(os.net.stream_wait_v1 stream_handle:i32 events:i32 timeout_ms:i32) -> i32`
  - readiness wait; returns event bitmask (section 8.4).

All of the above MUST hard-error if referenced in any `solve-*` compilation.

### 8.2 StreamDocV1

```
StreamDocV1 :=
  u8  tag = 1
  u32 handle_le
```

### 8.3 ListenerDocV1

```
ListenerDocV1 :=
  u8  tag = 1
  u32 handle_le
```

### 8.4 ReadDocV1

```
ReadDocV1 :=
  u8  tag
  if tag=1:
    u32 n_le
    u8[n] data
  if tag=0:
    ErrorDocV1 (embedded without re-tagging)
```

- For EOF, return tag=1 with `n_le = 0` and empty data.
- `max_bytes` MUST be enforced by the adapter regardless of what the program requests.

### 8.5 WriteDocV1

```
WriteDocV1 :=
  u8 tag
  if tag=1:
    u32 n_written_le
  if tag=0:
    ErrorDocV1
```

### 8.6 Readiness event bits

`os.net.stream_wait_v1` returns a bitmask:

- bit 0 (`1`) = readable
- bit 1 (`2`) = writable
- bit 2 (`4`) = hangup (peer closed)
- bit 3 (`8`) = error

Portability:
- On POSIX systems, implementations typically use `poll()`/`select()` for readiness.
- On Windows, implementations typically use `WSAPoll()`/`select()`.

## 9. DNS

- `(os.net.dns_lookup_v1 name:bytes port:i32 caps:bytes) -> bytes`
  - returns `NetAddrListDocV1` or `ErrorDocV1`.

## 10. HTTP (optional layer)

HTTP request and response are defined so agents can stay in bytes-land.
URL syntax is expected to follow RFC 3986 (URI generic syntax), and HTTP semantics align with RFC 9110. (References are informational; Evolang defines its own bytes ABI.)

### 10.1 HttpReqV1

```
HttpReqV1 :=
  u8  tag = 1
  u32 method_le      ; 1=GET,2=POST,3=PUT,4=DELETE,5=PATCH,6=HEAD
  u32 url_len_le
  u8[url_len] url_utf8
  u32 hdr_count_le
  repeated hdr_count times:
    u32 k_len_le
    u8[k_len] k_utf8
    u32 v_len_le
    u8[v_len] v_utf8
  u32 body_len_le
  u8[body_len] body
  NetCapsV1
```

### 10.2 HttpRespDocV1

```
HttpRespDocV1 :=
  u8  tag
  if tag=1:
    u32 status_le
    u32 hdr_count_le
    repeated headers (k/v like request)
    u32 body_len_le
    u8[body_len] body
  if tag=0:
    ErrorDocV1
```

### 10.3 HTTP builtin (optional)

- `(os.net.http_fetch_v1 req:bytes) -> bytes`
  - returns `HttpRespDocV1`.

Implementations MAY use a native HTTP library (libcurl, WinHTTP, etc) as long as:
- caps are enforced (`max_body_bytes`, timeouts);
- policy is enforced (`run-os-sandboxed`).

## 11. Error codes (u32)

These codes are stable and MUST NOT be changed once published:

- `1`  = `EV_NET_ERR_POLICY_DENIED`
- `2`  = `EV_NET_ERR_INVALID`
- `3`  = `EV_NET_ERR_DNS_FAILED`
- `4`  = `EV_NET_ERR_CONNECT_FAILED`
- `5`  = `EV_NET_ERR_TIMEOUT`
- `6`  = `EV_NET_ERR_IO`
- `7`  = `EV_NET_ERR_CLOSED`
- `8`  = `EV_NET_ERR_LIMIT`
- `9`  = `EV_NET_ERR_UNSUPPORTED`

## 12. Sandbox policy mapping (run-os-sandboxed)

- Every `os.net.*` op MUST check policy first.
- If denied, return `ErrorDocV1` with code `EV_NET_ERR_POLICY_DENIED`.

Policy is described in `schemas/run-os-policy.schema.json` (network section). The runner MUST pass it to the program via deterministic env vars (implementation-defined), and the generated C runtime reads those env vars once at startup.

## 13. Compliance tests

Cross-platform smoke suites SHOULD:
- use a local helper server (`deps/evolang/evolang-net-stub-server[.exe]`) for deterministic reachability;
- avoid touching public internet for CI reliability;
- validate that `run-os-sandboxed` denies network by default.

