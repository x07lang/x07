# run-os-policy.schema.json — network section integration notes (draft)

This folder contains a **copy/paste** JSON fragment:

- `schemas/run-os-policy.network.section.json`

To integrate:

1. Merge `$defs.net_addr_rule_v1` and `$defs.net_policy_v1` into your schema’s `$defs`.
2. Add top-level property:

   ```json
   "network": { "$ref": "#/$defs/net_policy_v1" }
   ```

3. Ensure the runner defaults `network.enabled=false` unless explicitly set.

Semantics (validator rules, beyond JSON Schema):

- If `network.enabled=false`, **ALL** `os.net.*` operations must be denied.
- If `allow_rules` is empty, treat as **deny all** unless you explicitly want allow-all (not recommended).
- `deny_rules` always overrides `allow_rules`.
- `port_min/port_max` are inclusive and are clamped to 0..65535.

