# Time v1 (ext.time.*)

This document pins the **v1** contracts for Evolang’s external time package.

Goals:

- **Single canonical way** for all common time tasks:
  - durations
  - RFC3339 parse/format
  - time zone offsets via a pinned tzdb snapshot
  - OS time access (run-os* only, policy gated)
- **LLM-first**: agents should never hand-roll binary encodings or slice offsets. Use the pack/unpack/accessor helpers.

Modules (package `evolang:ext-time-rs`):

- `ext.time.duration` — duration values and arithmetic (pure, deterministic)
- `ext.time.rfc3339` — RFC3339 parse/format (pure, deterministic)
- `ext.time.tzdb` — time zone database access (pure, deterministic; backed by a pinned tzdb snapshot)
- `ext.time.instant` — thin wrappers for “absolute time” built on `ext.time.duration` encoding (pure)
- `ext.time.os` — OS adapters: now/sleep/local_tzid (run-os / run-os-sandboxed only; policy gated)

Key design constraints:

- `solve-*` worlds remain deterministic. Any API that touches real time MUST be under `ext.time.os` and is only available in run-os* worlds.
- `ext.time.tzdb` MUST be deterministic and MUST NOT consult the host OS tzdb at runtime. It uses a pinned tzdb snapshot shipped with the package/toolchain.

See also:

- `docs/time/duration-v1.md`
- `docs/time/rfc3339-v1.md`
- `docs/time/tzdb-v1.md`
- `docs/time/os-time-v1.md`
