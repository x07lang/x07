# evolang_ext_time_v1_bundle

Drop-in bundle for a production-ready external time package.

Contents:
- `packages/ext/evolang-ext-time-rs/0.1.0` — package skeleton + modules
- `docs/time/*` — pinned v1 contracts
- `schemas/run-os-policy.time.*` — schema patch + examples
- `benchmarks/*` — smoke suite JSON shapes
- `tests/*` — smoke programs (pure + run-os)

Notes:
- `ext.time.duration` and `ext.time.rfc3339` are based directly on the current implementations.
- `ext.time.rfc3339` exports `parse_v1` / `format_v1` as the single canonical 64-bit API.
- `ext.time.tzdb` and `ext.time.os` require native builtins in the runner/toolchain:
  - `os.time.now_instant_v1`
  - `os.time.sleep_ms_v1`
  - `os.time.local_tzid_v1`
  - `os.time.tzdb_is_valid_tzid_v1`
  - `os.time.tzdb_offset_duration_v1`
  - `os.time.tzdb_snapshot_id_v1`
