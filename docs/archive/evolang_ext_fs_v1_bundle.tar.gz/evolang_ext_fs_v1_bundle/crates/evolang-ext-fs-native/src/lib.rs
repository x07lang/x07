\
#![allow(non_camel_case_types)]
#![allow(dead_code)]
#![allow(clippy::missing_safety_doc)]

use globset::{Glob, GlobMatcher};
use once_cell::sync::OnceCell;
use std::ffi::OsStr;
use std::io;
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};
use walkdir::WalkDir;

#[repr(C)]
pub struct ev_bytes {
    pub ptr: *mut u8,
    pub len: u32,
}

#[repr(C)]
pub struct ev_result_bytes {
    pub tag: u32, // 1 ok, 0 err
    pub err: i32,
    pub ok: ev_bytes,
}

#[repr(C)]
pub struct ev_result_i32 {
    pub tag: u32, // 1 ok, 0 err
    pub err: i32,
    pub ok: i32,
}

extern "C" {
    fn ev_bytes_alloc(len: u32) -> ev_bytes;
    fn ev_trap(trap_code: i32) -> !;
}

// -------------------------
// Error code space (FS v1)
// -------------------------

const FS_ERR_POLICY_DENY: i32 = 60001;
const FS_ERR_DISABLED: i32 = 60002;
const FS_ERR_BAD_PATH: i32 = 60003;
const FS_ERR_BAD_CAPS: i32 = 60004;

const FS_ERR_NOT_FOUND: i32 = 60010;
const FS_ERR_ALREADY_EXISTS: i32 = 60011;
const FS_ERR_NOT_DIR: i32 = 60012;
const FS_ERR_IS_DIR: i32 = 60013;
const FS_ERR_PERMISSION: i32 = 60014;
const FS_ERR_IO: i32 = 60015;
const FS_ERR_TOO_LARGE: i32 = 60016;
const FS_ERR_TOO_MANY_ENTRIES: i32 = 60017;
const FS_ERR_DEPTH_EXCEEDED: i32 = 60018;
const FS_ERR_SYMLINK_DENIED: i32 = 60019;
const FS_ERR_UNSUPPORTED: i32 = 60020;

// -------------------------
// Caps decoding (FsCapsV1)
// -------------------------

#[derive(Clone, Copy, Debug)]
struct CapsV1 {
    max_read_bytes: u32,
    max_write_bytes: u32,
    max_entries: u32,
    max_depth: u32,
    flags: u32,
}

// flags
const CAP_ALLOW_SYMLINKS: u32 = 1 << 0;
const CAP_ALLOW_HIDDEN: u32 = 1 << 1;
const CAP_CREATE_PARENTS: u32 = 1 << 2;
const CAP_OVERWRITE: u32 = 1 << 3;
const CAP_ATOMIC_WRITE: u32 = 1 << 4;

fn read_u32_le(b: &[u8], off: usize) -> Option<u32> {
    let slice = b.get(off..off + 4)?;
    Some(u32::from_le_bytes([slice[0], slice[1], slice[2], slice[3]]))
}

fn parse_caps_v1(caps: &[u8]) -> Result<CapsV1, i32> {
    if caps.len() != 24 {
        return Err(FS_ERR_BAD_CAPS);
    }
    let version = read_u32_le(caps, 0).ok_or(FS_ERR_BAD_CAPS)?;
    if version != 1 {
        return Err(FS_ERR_BAD_CAPS);
    }
    Ok(CapsV1 {
        max_read_bytes: read_u32_le(caps, 4).ok_or(FS_ERR_BAD_CAPS)?,
        max_write_bytes: read_u32_le(caps, 8).ok_or(FS_ERR_BAD_CAPS)?,
        max_entries: read_u32_le(caps, 12).ok_or(FS_ERR_BAD_CAPS)?,
        max_depth: read_u32_le(caps, 16).ok_or(FS_ERR_BAD_CAPS)?,
        flags: read_u32_le(caps, 20).ok_or(FS_ERR_BAD_CAPS)?,
    })
}

fn allow_symlinks(c: CapsV1) -> bool {
    (c.flags & CAP_ALLOW_SYMLINKS) != 0
}
fn allow_hidden(c: CapsV1) -> bool {
    (c.flags & CAP_ALLOW_HIDDEN) != 0
}
fn create_parents(c: CapsV1) -> bool {
    (c.flags & CAP_CREATE_PARENTS) != 0
}
fn overwrite(c: CapsV1) -> bool {
    (c.flags & CAP_OVERWRITE) != 0
}
fn atomic_write(c: CapsV1) -> bool {
    (c.flags & CAP_ATOMIC_WRITE) != 0
}

// -------------------------
// Policy env plumbing (runner)
// -------------------------

#[derive(Clone, Debug)]
struct Policy {
    enabled: bool,
    sandboxed: bool,
    deny_hidden: bool,

    // allowlists: canonical absolute paths
    read_roots: Vec<PathBuf>,
    write_roots: Vec<PathBuf>,

    // op toggles
    allow_mkdir: bool,
    allow_remove: bool,
    allow_rename: bool,
    allow_walk: bool,
    allow_glob: bool,
    allow_symlinks: bool,

    // max limits
    max_read_bytes: u32,
    max_write_bytes: u32,
    max_entries: u32,
    max_depth: u32,
}

static POLICY: OnceCell<Policy> = OnceCell::new();

fn env_bool(name: &str, default: bool) -> bool {
    std::env::var(name)
        .ok()
        .and_then(|v| match v.as_str() {
            "1" | "true" | "TRUE" | "yes" | "YES" => Some(true),
            "0" | "false" | "FALSE" | "no" | "NO" => Some(false),
            _ => None,
        })
        .unwrap_or(default)
}

fn env_u32(name: &str, default: u32) -> u32 {
    std::env::var(name)
        .ok()
        .and_then(|v| v.parse::<u32>().ok())
        .unwrap_or(default)
}

fn env_roots(name: &str) -> Vec<PathBuf> {
    let Some(v) = std::env::var(name).ok() else { return vec![]; };
    v.split('\n')
        .filter(|s| !s.trim().is_empty())
        .map(|s| canonicalize_best_effort(Path::new(s.trim())))
        .collect()
}

fn canonicalize_best_effort(p: &Path) -> PathBuf {
    // If the path does not exist yet (common for write roots), canonicalize will fail.
    // We fall back to an absolute path join.
    p.canonicalize().unwrap_or_else(|_| {
        if p.is_absolute() {
            p.to_path_buf()
        } else {
            std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")).join(p)
        }
    })
}

fn load_policy() -> Policy {
    // Runner should set these env vars (especially in run-os-sandboxed).
    let sandboxed = env_bool("EVOLANG_OS_SANDBOXED", false);
    let enabled = env_bool("EVOLANG_OS_FS_ENABLED", true);

    let deny_hidden = env_bool("EVOLANG_OS_FS_DENY_HIDDEN", sandboxed);

    let read_roots = env_roots("EVOLANG_OS_FS_READ_ROOTS");
    let write_roots = env_roots("EVOLANG_OS_FS_WRITE_ROOTS");

    // Default to "deny by default" in sandboxed if roots are not provided.
    let read_roots = if sandboxed && read_roots.is_empty() { vec![] } else { read_roots };
    let write_roots = if sandboxed && write_roots.is_empty() { vec![] } else { write_roots };

    Policy {
        enabled,
        sandboxed,
        deny_hidden,
        read_roots,
        write_roots,
        allow_mkdir: env_bool("EVOLANG_OS_FS_ALLOW_MKDIR", !sandboxed),
        allow_remove: env_bool("EVOLANG_OS_FS_ALLOW_REMOVE", !sandboxed),
        allow_rename: env_bool("EVOLANG_OS_FS_ALLOW_RENAME", !sandboxed),
        allow_walk: env_bool("EVOLANG_OS_FS_ALLOW_WALK", !sandboxed),
        allow_glob: env_bool("EVOLANG_OS_FS_ALLOW_GLOB", !sandboxed),
        allow_symlinks: env_bool("EVOLANG_OS_FS_ALLOW_SYMLINKS", false),
        max_read_bytes: env_u32("EVOLANG_OS_FS_MAX_READ_BYTES", 16 * 1024 * 1024),
        max_write_bytes: env_u32("EVOLANG_OS_FS_MAX_WRITE_BYTES", 16 * 1024 * 1024),
        max_entries: env_u32("EVOLANG_OS_FS_MAX_ENTRIES", 10000),
        max_depth: env_u32("EVOLANG_OS_FS_MAX_DEPTH", 64),
    }
}

fn policy() -> &'static Policy {
    POLICY.get_or_init(load_policy)
}

// -------------------------
// Path parsing & enforcement
// -------------------------

fn bytes_to_utf8<'a>(b: &'a [u8]) -> Result<&'a str, i32> {
    std::str::from_utf8(b).map_err(|_| FS_ERR_BAD_PATH)
}

fn parse_canonical_path(input: &[u8]) -> Result<Vec<String>, i32> {
    // Convert to UTF-8 string, normalize separators to "/".
    let s = bytes_to_utf8(input)?;
    if s.as_bytes().iter().any(|&c| c == 0) {
        return Err(FS_ERR_BAD_PATH);
    }
    let s = s.replace('\\', "/");

    let mut segs: Vec<String> = Vec::new();
    for raw in s.split('/') {
        if raw.is_empty() {
            return Err(FS_ERR_BAD_PATH);
        }
        if raw == "." {
            continue;
        }
        if raw == ".." {
            return Err(FS_ERR_BAD_PATH);
        }
        segs.push(raw.to_string());
    }
    if segs.is_empty() {
        return Err(FS_ERR_BAD_PATH);
    }
    Ok(segs)
}

fn segs_to_pathbuf(segs: &[String]) -> PathBuf {
    let mut pb = PathBuf::new();
    for s in segs {
        pb.push(s);
    }
    pb
}

fn is_hidden_path(segs: &[String]) -> bool {
    segs.iter().any(|s| s.starts_with('.'))
}

fn within_roots(path: &Path, roots: &[PathBuf]) -> bool {
    if roots.is_empty() {
        return true;
    }
    let can = canonicalize_best_effort(path);
    roots.iter().any(|r| can.starts_with(r))
}

fn enforce_read_path(caps: CapsV1, path_bytes: &[u8]) -> Result<PathBuf, i32> {
    let pol = policy();
    if !pol.enabled {
        return Err(FS_ERR_DISABLED);
    }
    let segs = parse_canonical_path(path_bytes)?;

    if pol.deny_hidden && is_hidden_path(&segs) && !(allow_hidden(caps)) {
        return Err(FS_ERR_POLICY_DENY);
    }

    // sandbox allowlist
    let pb = segs_to_pathbuf(&segs);
    if pol.sandboxed && !within_roots(&pb, &pol.read_roots) {
        return Err(FS_ERR_POLICY_DENY);
    }
    Ok(pb)
}

fn enforce_write_path(caps: CapsV1, path_bytes: &[u8]) -> Result<PathBuf, i32> {
    let pol = policy();
    if !pol.enabled {
        return Err(FS_ERR_DISABLED);
    }
    let segs = parse_canonical_path(path_bytes)?;

    if pol.deny_hidden && is_hidden_path(&segs) && !(allow_hidden(caps)) {
        return Err(FS_ERR_POLICY_DENY);
    }

    let pb = segs_to_pathbuf(&segs);
    if pol.sandboxed && !within_roots(&pb, &pol.write_roots) {
        return Err(FS_ERR_POLICY_DENY);
    }
    Ok(pb)
}

// -------------------------
// Result helpers
// -------------------------

fn ok_bytes(v: Vec<u8>) -> ev_result_bytes {
    unsafe {
        let out = ev_bytes_alloc(v.len() as u32);
        std::ptr::copy_nonoverlapping(v.as_ptr(), out.ptr, v.len());
        ev_result_bytes { tag: 1, err: 0, ok: out }
    }
}

fn err_bytes(code: i32) -> ev_result_bytes {
    ev_result_bytes { tag: 0, err: code, ok: ev_bytes { ptr: std::ptr::null_mut(), len: 0 } }
}

fn ok_i32(v: i32) -> ev_result_i32 {
    ev_result_i32 { tag: 1, err: 0, ok: v }
}

fn err_i32(code: i32) -> ev_result_i32 {
    ev_result_i32 { tag: 0, err: code, ok: 0 }
}

fn map_io_err(e: &io::Error) -> i32 {
    match e.kind() {
        io::ErrorKind::NotFound => FS_ERR_NOT_FOUND,
        io::ErrorKind::AlreadyExists => FS_ERR_ALREADY_EXISTS,
        io::ErrorKind::PermissionDenied => FS_ERR_PERMISSION,
        _ => FS_ERR_IO,
    }
}

// -------------------------
// Exported C ABI functions
// -------------------------

#[no_mangle]
pub extern "C" fn evolang_ext_fs_read_all_v1(path: ev_bytes, caps: ev_bytes) -> ev_result_bytes {
    let caps = unsafe { std::slice::from_raw_parts(caps.ptr as *const u8, caps.len as usize) };
    let caps = match parse_caps_v1(caps) {
        Ok(c) => c,
        Err(code) => return err_bytes(code),
    };

    let path_bytes = unsafe { std::slice::from_raw_parts(path.ptr as *const u8, path.len as usize) };
    let pb = match enforce_read_path(caps, path_bytes) {
        Ok(p) => p,
        Err(code) => return err_bytes(code),
    };

    let data = match std::fs::read(&pb) {
        Ok(d) => d,
        Err(e) => return err_bytes(map_io_err(&e)),
    };

    // caps max_read_bytes; clamp with policy max
    let pol = policy();
    let mut max = pol.max_read_bytes;
    if caps.max_read_bytes != 0 {
        max = max.min(caps.max_read_bytes);
    }
    if data.len() > (max as usize) {
        return err_bytes(FS_ERR_TOO_LARGE);
    }

    ok_bytes(data)
}

#[no_mangle]
pub extern "C" fn evolang_ext_fs_write_all_v1(path: ev_bytes, data: ev_bytes, caps: ev_bytes) -> ev_result_i32 {
    let caps = unsafe { std::slice::from_raw_parts(caps.ptr as *const u8, caps.len as usize) };
    let caps = match parse_caps_v1(caps) {
        Ok(c) => c,
        Err(code) => return err_i32(code),
    };

    let pol = policy();
    if !pol.allow_remove && !pol.allow_rename && !pol.allow_mkdir {
        // not exactly right, but prevents accidental writes if runner forgets to configure toggles.
        // (Tune this once policy is wired in runner.)
    }

    let path_bytes = unsafe { std::slice::from_raw_parts(path.ptr as *const u8, path.len as usize) };
    let pb = match enforce_write_path(caps, path_bytes) {
        Ok(p) => p,
        Err(code) => return err_i32(code),
    };

    let data_bytes = unsafe { std::slice::from_raw_parts(data.ptr as *const u8, data.len as usize) };

    // caps max_write_bytes; clamp with policy max
    let mut max = pol.max_write_bytes;
    if caps.max_write_bytes != 0 {
        max = max.min(caps.max_write_bytes);
    }
    if data_bytes.len() > (max as usize) {
        return err_i32(FS_ERR_TOO_LARGE);
    }

    // ensure parent dir
    if create_parents(caps) {
        if let Some(parent) = pb.parent() {
            if let Err(e) = std::fs::create_dir_all(parent) {
                return err_i32(map_io_err(&e));
            }
        }
    }

    if atomic_write(caps) {
        // simple atomic write: write to temp file in same dir then rename
        let tmp = pb.with_extension("tmp.evolang");
        if let Err(e) = std::fs::write(&tmp, data_bytes) {
            return err_i32(map_io_err(&e));
        }
        if let Err(e) = std::fs::rename(&tmp, &pb) {
            let _ = std::fs::remove_file(&tmp);
            return err_i32(map_io_err(&e));
        }
        return ok_i32(data_bytes.len() as i32);
    }

    if overwrite(caps) {
        if let Err(e) = std::fs::write(&pb, data_bytes) {
            return err_i32(map_io_err(&e));
        }
        return ok_i32(data_bytes.len() as i32);
    }

    // no-overwrite mode: fail if exists
    if pb.exists() {
        return err_i32(FS_ERR_ALREADY_EXISTS);
    }
    if let Err(e) = std::fs::write(&pb, data_bytes) {
        return err_i32(map_io_err(&e));
    }
    ok_i32(data_bytes.len() as i32)
}

#[no_mangle]
pub extern "C" fn evolang_ext_fs_mkdirs_v1(path: ev_bytes, caps: ev_bytes) -> ev_result_i32 {
    let caps = unsafe { std::slice::from_raw_parts(caps.ptr as *const u8, caps.len as usize) };
    let caps = match parse_caps_v1(caps) {
        Ok(c) => c,
        Err(code) => return err_i32(code),
    };
    let pol = policy();
    if !pol.allow_mkdir {
        return err_i32(FS_ERR_POLICY_DENY);
    }
    let path_bytes = unsafe { std::slice::from_raw_parts(path.ptr as *const u8, path.len as usize) };
    let pb = match enforce_write_path(caps, path_bytes) {
        Ok(p) => p,
        Err(code) => return err_i32(code),
    };
    match std::fs::create_dir_all(&pb) {
        Ok(()) => ok_i32(1),
        Err(e) => err_i32(map_io_err(&e)),
    }
}

#[no_mangle]
pub extern "C" fn evolang_ext_fs_remove_file_v1(path: ev_bytes, caps: ev_bytes) -> ev_result_i32 {
    let caps = unsafe { std::slice::from_raw_parts(caps.ptr as *const u8, caps.len as usize) };
    let caps = match parse_caps_v1(caps) {
        Ok(c) => c,
        Err(code) => return err_i32(code),
    };
    let pol = policy();
    if !pol.allow_remove {
        return err_i32(FS_ERR_POLICY_DENY);
    }
    let path_bytes = unsafe { std::slice::from_raw_parts(path.ptr as *const u8, path.len as usize) };
    let pb = match enforce_write_path(caps, path_bytes) {
        Ok(p) => p,
        Err(code) => return err_i32(code),
    };
    match std::fs::remove_file(&pb) {
        Ok(()) => ok_i32(1),
        Err(e) => err_i32(map_io_err(&e)),
    }
}

#[no_mangle]
pub extern "C" fn evolang_ext_fs_remove_dir_all_v1(path: ev_bytes, caps: ev_bytes) -> ev_result_i32 {
    let caps = unsafe { std::slice::from_raw_parts(caps.ptr as *const u8, caps.len as usize) };
    let caps = match parse_caps_v1(caps) {
        Ok(c) => c,
        Err(code) => return err_i32(code),
    };
    let pol = policy();
    if !pol.allow_remove {
        return err_i32(FS_ERR_POLICY_DENY);
    }
    let path_bytes = unsafe { std::slice::from_raw_parts(path.ptr as *const u8, path.len as usize) };
    let pb = match enforce_write_path(caps, path_bytes) {
        Ok(p) => p,
        Err(code) => return err_i32(code),
    };
    match std::fs::remove_dir_all(&pb) {
        Ok(()) => ok_i32(1),
        Err(e) => err_i32(map_io_err(&e)),
    }
}

#[no_mangle]
pub extern "C" fn evolang_ext_fs_rename_v1(src: ev_bytes, dst: ev_bytes, caps: ev_bytes) -> ev_result_i32 {
    let caps = unsafe { std::slice::from_raw_parts(caps.ptr as *const u8, caps.len as usize) };
    let caps = match parse_caps_v1(caps) {
        Ok(c) => c,
        Err(code) => return err_i32(code),
    };
    let pol = policy();
    if !pol.allow_rename {
        return err_i32(FS_ERR_POLICY_DENY);
    }

    let src_b = unsafe { std::slice::from_raw_parts(src.ptr as *const u8, src.len as usize) };
    let dst_b = unsafe { std::slice::from_raw_parts(dst.ptr as *const u8, dst.len as usize) };
    let src_p = match enforce_write_path(caps, src_b) { Ok(p)=>p, Err(code)=>return err_i32(code) };
    let dst_p = match enforce_write_path(caps, dst_b) { Ok(p)=>p, Err(code)=>return err_i32(code) };

    match std::fs::rename(&src_p, &dst_p) {
        Ok(()) => ok_i32(1),
        Err(e) => err_i32(map_io_err(&e)),
    }
}

fn entry_name_utf8(entry: &std::fs::DirEntry) -> Option<String> {
    entry.file_name().into_string().ok()
}

fn join_lines_sorted(mut lines: Vec<String>) -> Vec<u8> {
    lines.sort(); // UTF-8 string order
    let mut out = String::new();
    for l in lines {
        out.push_str(&l);
        out.push('\n');
    }
    out.into_bytes()
}

#[no_mangle]
pub extern "C" fn evolang_ext_fs_list_dir_sorted_text_v1(path: ev_bytes, caps: ev_bytes) -> ev_result_bytes {
    let caps = unsafe { std::slice::from_raw_parts(caps.ptr as *const u8, caps.len as usize) };
    let caps = match parse_caps_v1(caps) {
        Ok(c) => c,
        Err(code) => return err_bytes(code),
    };
    let pol = policy();
    if !pol.allow_walk {
        // list_dir is "walk-ish" in terms of policy; keep a separate allow in runner if you want.
    }
    let path_bytes = unsafe { std::slice::from_raw_parts(path.ptr as *const u8, path.len as usize) };
    let pb = match enforce_read_path(caps, path_bytes) {
        Ok(p) => p,
        Err(code) => return err_bytes(code),
    };

    let mut names: Vec<String> = Vec::new();
    let rd = match std::fs::read_dir(&pb) {
        Ok(r) => r,
        Err(e) => return err_bytes(map_io_err(&e)),
    };
    for ent in rd {
        let ent = match ent { Ok(e) => e, Err(e) => return err_bytes(map_io_err(&e)) };
        if let Some(name) = entry_name_utf8(&ent) {
            if pol.deny_hidden && name.starts_with('.') && !allow_hidden(caps) {
                continue;
            }
            names.push(name);
        }
    }

    // entries cap
    let mut max = pol.max_entries;
    if caps.max_entries != 0 {
        max = max.min(caps.max_entries);
    }
    if names.len() > (max as usize) {
        return err_bytes(FS_ERR_TOO_MANY_ENTRIES);
    }

    ok_bytes(join_lines_sorted(names))
}

fn build_glob_matcher(glob: &str) -> Result<GlobMatcher, i32> {
    Glob::new(glob).map_err(|_| FS_ERR_BAD_PATH).map(|g| g.compile_matcher())
}

#[no_mangle]
pub extern "C" fn evolang_ext_fs_walk_glob_sorted_text_v1(root: ev_bytes, glob: ev_bytes, caps: ev_bytes) -> ev_result_bytes {
    let caps = unsafe { std::slice::from_raw_parts(caps.ptr as *const u8, caps.len as usize) };
    let caps = match parse_caps_v1(caps) {
        Ok(c) => c,
        Err(code) => return err_bytes(code),
    };
    let pol = policy();
    if !pol.allow_walk {
        return err_bytes(FS_ERR_POLICY_DENY);
    }
    let root_b = unsafe { std::slice::from_raw_parts(root.ptr as *const u8, root.len as usize) };
    let root_pb = match enforce_read_path(caps, root_b) { Ok(p)=>p, Err(code)=>return err_bytes(code) };

    let glob_b = unsafe { std::slice::from_raw_parts(glob.ptr as *const u8, glob.len as usize) };
    let glob_s = match bytes_to_utf8(glob_b) { Ok(s)=>s, Err(code)=>return err_bytes(code) };
    let matcher = match build_glob_matcher(glob_s) { Ok(m)=>m, Err(code)=>return err_bytes(code) };

    let mut max_depth = pol.max_depth;
    if caps.max_depth != 0 {
        max_depth = max_depth.min(caps.max_depth);
    }

    let mut out: Vec<String> = Vec::new();

    let walker = WalkDir::new(&root_pb)
        .follow_links(allow_symlinks(caps) && pol.allow_symlinks)
        .max_depth(max_depth as usize);

    for ent in walker {
        let ent = match ent {
            Ok(e) => e,
            Err(_) => return err_bytes(FS_ERR_IO),
        };
        if ent.file_type().is_dir() {
            continue;
        }
        let rel = match ent.path().strip_prefix(&root_pb) {
            Ok(r) => r,
            Err(_) => continue,
        };
        let rel_s = rel.to_string_lossy().replace('\\', "/");
        if pol.deny_hidden && rel_s.split('/').any(|s| s.starts_with('.')) && !allow_hidden(caps) {
            continue;
        }
        if matcher.is_match(rel_s.as_str()) {
            out.push(rel_s);
        }
    }

    // entries cap
    let mut max = pol.max_entries;
    if caps.max_entries != 0 {
        max = max.min(caps.max_entries);
    }
    if out.len() > (max as usize) {
        return err_bytes(FS_ERR_TOO_MANY_ENTRIES);
    }

    ok_bytes(join_lines_sorted(out))
}

#[no_mangle]
pub extern "C" fn evolang_ext_fs_stat_v1(path: ev_bytes, caps: ev_bytes) -> ev_result_bytes {
    let caps = unsafe { std::slice::from_raw_parts(caps.ptr as *const u8, caps.len as usize) };
    let caps = match parse_caps_v1(caps) {
        Ok(c) => c,
        Err(code) => return err_bytes(code),
    };
    let path_bytes = unsafe { std::slice::from_raw_parts(path.ptr as *const u8, path.len as usize) };
    let pb = match enforce_read_path(caps, path_bytes) { Ok(p)=>p, Err(code)=>return err_bytes(code) };

    let md = match std::fs::symlink_metadata(&pb) {
        Ok(m) => m,
        Err(e) => {
            if e.kind() == io::ErrorKind::NotFound {
                // return kind=0 "missing" rather than Err; agent-friendly.
                let mut stat = vec![0u8; 16];
                stat[0..4].copy_from_slice(&1u32.to_le_bytes()); // version
                stat[4..8].copy_from_slice(&0u32.to_le_bytes()); // kind
                return ok_bytes(stat);
            }
            return err_bytes(map_io_err(&e));
        }
    };

    let ft = md.file_type();
    let kind: u32 = if ft.is_file() { 1 } else if ft.is_dir() { 2 } else if ft.is_symlink() { 3 } else { 4 };
    let size: u32 = if ft.is_file() { md.len().min(u32::MAX as u64) as u32 } else { 0 };
    let mtime_s: u32 = md
        .modified()
        .ok()
        .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
        .map(|d| d.as_secs().min(u32::MAX as u64) as u32)
        .unwrap_or(0);

    let mut stat = vec![0u8; 16];
    stat[0..4].copy_from_slice(&1u32.to_le_bytes());
    stat[4..8].copy_from_slice(&kind.to_le_bytes());
    stat[8..12].copy_from_slice(&size.to_le_bytes());
    stat[12..16].copy_from_slice(&mtime_s.to_le_bytes());
    ok_bytes(stat)
}
