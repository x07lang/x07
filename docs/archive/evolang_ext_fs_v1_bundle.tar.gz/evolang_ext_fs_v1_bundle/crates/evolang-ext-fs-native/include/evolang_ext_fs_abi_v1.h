\
#ifndef EVOLANG_EXT_FS_ABI_V1_H
#define EVOLANG_EXT_FS_ABI_V1_H

// C ABI surface for evolang:ext-fs v1 native shim.
// This header is pinned and must remain backward compatible within v1.

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct ev_bytes {
  uint8_t* ptr;
  uint32_t len;
} ev_bytes;

// result_bytes layout (matches evolangc runtime ABI):
//   tag = 1 => ok is valid
//   tag = 0 => err is valid
typedef struct ev_result_bytes {
  uint32_t tag;
  int32_t err;
  ev_bytes ok;
} ev_result_bytes;

// result_i32 layout:
//   tag = 1 => ok is valid
//   tag = 0 => err is valid
typedef struct ev_result_i32 {
  uint32_t tag;
  int32_t err;
  int32_t ok;
} ev_result_i32;

// Provided by evolang runtime:
extern ev_bytes ev_bytes_alloc(uint32_t len);
extern void ev_trap(int32_t trap_code);

// v1 entrypoints used by os.fs.* builtins:
ev_result_bytes evolang_ext_fs_read_all_v1(ev_bytes path, ev_bytes caps);
ev_result_i32   evolang_ext_fs_write_all_v1(ev_bytes path, ev_bytes data, ev_bytes caps);
ev_result_i32   evolang_ext_fs_mkdirs_v1(ev_bytes path, ev_bytes caps);
ev_result_i32   evolang_ext_fs_remove_file_v1(ev_bytes path, ev_bytes caps);
ev_result_i32   evolang_ext_fs_remove_dir_all_v1(ev_bytes path, ev_bytes caps);
ev_result_i32   evolang_ext_fs_rename_v1(ev_bytes src, ev_bytes dst, ev_bytes caps);
ev_result_bytes evolang_ext_fs_list_dir_sorted_text_v1(ev_bytes path, ev_bytes caps);
ev_result_bytes evolang_ext_fs_walk_glob_sorted_text_v1(ev_bytes root, ev_bytes glob, ev_bytes caps);
ev_result_bytes evolang_ext_fs_stat_v1(ev_bytes path, ev_bytes caps);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // EVOLANG_EXT_FS_ABI_V1_H
