#!/usr/bin/env bash
set -euo pipefail

# Build the evolang:ext-fs native shim as a static library and stage it into deps/evolang/.
# This mirrors the pattern used by ext-math / ext-db native shims.

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CRATE="$ROOT/crates/evolang-ext-fs-native"
OUT="$ROOT/deps/evolang"

mkdir -p "$OUT/include" "$OUT/lib"

cargo build --manifest-path "$CRATE/Cargo.toml" --release

# Linux/macOS staticlib output:
if [[ -f "$CRATE/target/release/libevolang_ext_fs_native.a" ]]; then
  cp "$CRATE/target/release/libevolang_ext_fs_native.a" "$OUT/lib/libevolang_ext_fs.a"
fi

# Windows (MSVC) output (name may vary by toolchain):
if [[ -f "$CRATE/target/release/evolang_ext_fs_native.lib" ]]; then
  cp "$CRATE/target/release/evolang_ext_fs_native.lib" "$OUT/lib/evolang_ext_fs.lib"
fi

cp "$CRATE/include/evolang_ext_fs_abi_v1.h" "$OUT/include/"

echo "staged: $OUT/include/evolang_ext_fs_abi_v1.h"
echo "staged: $OUT/lib/*ext_fs*"
