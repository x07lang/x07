# evolang:ext-fs v1 — Drop-in bundle

Contents:

- `docs/fs/fs-v1.md` — pinned v1 spec (caps, outputs, error codes, policy knobs)
- `schemas/run-os-policy.fs.section.schema.json` — fs section schema snippet
- `schemas/run-os-policy.schema.json.patch` — additive patch against `schemas/run-os-policy.schema.json`
- `packages/ext/evolang-ext-fs/0.1.0/` — external package skeleton (stdlib wrappers + spec)
- `crates/evolang-ext-fs-native/` — native shim crate layout + C ABI header
- `scripts/build_ext_fs_native.sh` — helper script to build + stage native shim
- `benchmarks/run-os/fs-smoke.json` — run-os smoke suite shape
- `benchmarks/run-os-sandboxed/fs-policy-smoke.json` — sandbox policy smoke suite shape
- `benchmarks/fixtures/os/fs-smoke-v1/` — fixtures for the smoke programs
- `tests/external_os/fs_smoke_ok/` — smoke program exercising core ops
- `tests/external_os/fs_policy_deny_smoke/` — smoke program exercising allowlist deny

Apply the policy schema patch:

```bash
git apply schemas/run-os-policy.schema.json.patch
```

Build the native shim (stages into `deps/evolang/`):

```bash
./scripts/build_ext_fs_native.sh
```
