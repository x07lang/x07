# Net v1 — External networking package (run-os / run-os-sandboxed)

This document is **normative** for the external networking package `evolang:ext-net@0.1.0`.

It defines:
- deterministic **binary encodings** (bytes contracts) for requests/responses
- required **OS-world builtins** (standalone only; never used in solve-* worlds)
- sandbox **policy fields** for `run-os-sandboxed`
- agent-friendly **spec helpers** so agents never hand-roll binary formats

> The intent is “LLM-first”: agents should call the helpers in `std.net.*.spec` instead of
> manually concatenating bytes.

---

## Package layout

External package:
- `packages/evolang-ext-net/0.1.0/...`

Modules (public surface):
- `std.net` (root)
- `std.net.codec` (NetAddr/NetCaps pack/unpack)
- `std.net.stream` (stream helpers)
- `std.net.tcp` (TCP client/server)
- `std.net.http` + `std.net.http.client` + `std.net.http.spec` (HTTP/HTTPS)

---

## Worlds

- **Allowed**: `run-os`, `run-os-sandboxed`
- **Forbidden**: `solve-*` worlds (deterministic evaluation worlds never touch real network)

The compiler/runner must hard-error if `os.net.*` builtins appear in any `solve-*` target.

---

## Common conventions

### Endianness and integers

All multi-byte integers are **little-endian u32** (`u32_le`). In Evolang they are carried in `i32`,
but interpreted as `u32` when encoding/decoding.

### Error codes

All OS builtins return either:
- a successful bytes payload, or
- a structured **error** with a deterministic numeric code (u32).

The recommended shape is `result_bytes` (typed result) where:
- `Ok(payload_bytes)` carries the payload
- `Err(code_i32)` carries the numeric code

(If your runtime currently returns “tagged bytes docs”, keep the same tag=1/0 convention,
but expose helpers to treat it like `result_bytes`.)

---

## HeadersTableV1 encoding (canonical)

Headers are represented as a deterministic bytes blob used by both requests and responses.

### Binary layout

```
HeadersTableV1 :=
  count:u32_le
  repeated count times:
    key_len:u32_le
    key_bytes[key_len]
    val_len:u32_le
    val_bytes[val_len]
```

### Canonicalization rules (v1)

To reduce “same semantics, different bytes” mistakes:

- Header **keys MUST be ASCII lowercase** (`A-Z` folded to `a-z`) in the canonical form.
- Header **values are bytes**; v1 does not normalize whitespace.
- Ordering:
  - `headers_canon_v1(table)` preserves insertion order (deterministic if built with the helpers).
  - `headers_canon_sorted_v1(table)` sorts entries by `(key_bytes, value_bytes)` lexicographically to produce order-insensitive canonical bytes (recommended for hashing/policy).
  - WARNING: HTTP allows multiple header field lines with the same name, and the order of those lines can be significant when values are combined. Only use sorted canonicalization if you treat duplicate `(key,value)` pairs as order-insensitive (recommended: combine ordered lists into a single header value).


**Agents SHOULD build headers with**:
- `std.net.http.spec.headers_empty_v1()`
- `std.net.http.spec.headers_push_canon_v1(table, key, val)`
- or `std.net.http.spec.headers1_canon_v1(key, val)`

---

## HttpReqV1 encoding

### Method codes

- `METHOD_GET = 1`
- `METHOD_POST = 2`

### Binary layout

```
HttpReqV1 :=
  method:u32_le
  url_len:u32_le
  url_bytes[url_len]          ; UTF-8 URL (bytes)
  headers_len:u32_le
  headers_bytes[headers_len]  ; HeadersTableV1
  body_len:u32_le
  body_bytes[body_len]
  caps_len:u32_le
  caps_bytes[caps_len]        ; NetCapsV1 (see std.net.codec)
```

### Agent-friendly builders

- `std.net.http.spec.req_get_v1(url, headers_table, caps)`  
  Builds a GET request with an empty body.
- `std.net.http.spec.req_post_v1(url, headers_table, body, caps)`  
  Builds a POST request with a body.

These helpers:
- treat `headers_table` with length `< 4` as empty (so agents can pass `(bytes.alloc 0)` safely)
- canonicalize header table via `headers_canon_sorted_v1` (lowercase keys + sorted entries; for stable hashing/policy)

---

## HttpRespV1 encoding (captured body)

Used by the **capture** HTTP builtin (body returned as one bytes blob).

### Binary layout

```
HttpRespV1 :=
  status:u32_le
  headers_len:u32_le
  headers_bytes[headers_len]  ; HeadersTableV1 (keys should already be lowercase)
  body_len:u32_le
  body_bytes[body_len]
```

### Helpers

- `std.net.http.spec.resp_v1(status, headers_table, body)`
- `std.net.http.spec.resp_status_v1(resp)`
- `std.net.http.spec.resp_headers_v1(resp)`
- `std.net.http.spec.resp_body_v1(resp)`

---

## HttpRespStreamV1 encoding (streamed body)

Used by the **stream** HTTP builtin (body read via `std.net.stream.read_v1`).

### Binary layout

```
HttpRespStreamV1 :=
  status:u32_le
  headers_len:u32_le
  headers_bytes[headers_len]     ; HeadersTableV1
  body_len_hint:u32_le           ; 0xFFFFFFFF if unknown
  stream_handle:u32_le           ; opaque OS stream handle
```

### Helpers

- `std.net.http.spec.resp_stream_v1(status, headers_table, body_len_hint, stream_handle)`
- `std.net.http.spec.resp_stream_handle_v1(doc)`
- `std.net.http.spec.resp_stream_body_len_hint_v1(doc)`
- `std.net.http.spec.resp_stream_status_v1(doc)`
- `std.net.http.spec.resp_stream_headers_v1(doc)`

---

## OS builtins required (standalone worlds only)

These are *not* part of the Evolang core language; they only exist when compiling for `run-os*`.

### HTTP/HTTPS

Capture (small responses):

- `os.net.http_fetch_v1(req: bytes) -> result_bytes`
  - `Ok(payload)` is **HttpRespV1**
  - `Err(code)` is a deterministic net error code

Stream (large responses):

- `os.net.http_fetch_stream_v1(req: bytes) -> result_bytes`
  - `Ok(payload)` is **HttpRespStreamV1**
  - `Err(code)` is a deterministic net error code

### Stream I/O

- `os.net.stream_read_v1(handle_i32, max_i32, caps_bytes) -> bytes`
  - returns empty bytes on EOF
  - errors: trap or return deterministic error doc (implementation choice; keep stable)

- `os.net.stream_write_v1(handle_i32, data_bytes, caps_bytes) -> i32`
- `os.net.stream_close_v1(handle_i32) -> i32`

### TCP (optional surface, required for servers)

- `os.net.tcp_connect_v1(addr_bytes, caps_bytes) -> result_bytes` (Ok payload = stream_handle:u32_le)
- `os.net.tcp_listen_v1(addr_bytes, caps_bytes) -> result_bytes` (Ok payload = listener_handle:u32_le)
- `os.net.tcp_accept_v1(listener_handle_i32, caps_bytes) -> result_bytes` (Ok payload = stream_handle:u32_le)

---

## run-os-sandboxed policy fields (network)

The policy must be able to constrain network behavior **without breaking the bytes contracts**.

Minimum recommended fields (see schemas):

- `network.enabled: bool`
- `network.allow_outbound: bool`
- `network.allow_inbound: bool`
- `network.allow_listen: bool`
- `network.allow_dns: bool`
- `network.allow_dns_names: [string]` (exact or glob)
- `network.allow_cidrs: [string]` (CIDR ranges)
- `network.allow_ports: [{min:u16,max:u16}]`
- `network.tls.allow_insecure: bool`
- resource gates:
  - `network.max_live_conns: u32`
  - `network.max_total_dials: u32`

---

## Implementation note: HTTP+TLS backend choice

For a cross-platform implementation of `http_fetch_v1`/`http_fetch_stream_v1`, `libcurl` is a pragmatic
default because it supports multiple TLS backends depending on platform/build (OpenSSL, Schannel on Windows,
Secure Transport on macOS, etc). Reference: curl/libcurl TLS documentation.

