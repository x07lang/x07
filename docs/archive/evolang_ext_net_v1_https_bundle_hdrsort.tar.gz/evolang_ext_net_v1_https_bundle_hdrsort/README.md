# evolang-ext-net v1 (bundle)

This bundle contains:

- `docs/net/net-v1.md` – normative spec for ext-net v1 (DNS/TCP/HTTP(S)).
- `schemas/run-os-policy.network.section.schema.json` – schema snippet to merge into your run-os-sandboxed policy schema.
- `packages/evolang-ext-net/0.1.0/` – external package skeleton with stub modules.
- `crates/evolang-net-stub-server/` – tiny helper binary for run-os smoke tests (HTTP/HTTPS/TCP echo).
- `benchmarks/run-os/net-smoke.json` and `benchmarks/run-os-sandboxed/net-policy-smoke.json` – copy/paste-ready smoke suite JSON shapes.

Notes:
- The `tests/external_os/*` programs included are **placeholders**. Replace them with real programs that:
  1) start `deps/evolang/net-stub-server` with a port-file,
  2) call `std.net.http.get_v1` against `https://127.0.0.1:<port>/`,
  3) validate response bytes and exit 0.

