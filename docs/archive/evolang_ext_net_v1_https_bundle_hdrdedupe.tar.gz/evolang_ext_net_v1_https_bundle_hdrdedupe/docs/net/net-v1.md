# Net v1 (evolang-ext-net)

This document is **normative** for the external networking package:

- `packages/evolang-ext-net/0.1.0/`

Scope:

- The v1 package is intended for **standalone worlds only**: `run-os` and `run-os-sandboxed`.
- `solve-*` deterministic worlds must never enable OS networking.

---

## Binary encoding conventions

All integer fields are **unsigned u32 little-endian** unless explicitly stated otherwise.

A “bytes blob” is encoded as:

- `len_u32_le`
- followed by `len` raw bytes

---

## NetAddrV1

Used for policy allowlists and (where applicable) for bind/connect targets.

Binary format:

- `tag_u32_le`
  - `1` = DNS name
  - `2` = IPv4 CIDR
  - `3` = IPv6 CIDR
- then variant payload:

### tag=1 (DNS name)

- `host_bytes` (bytes blob, UTF-8)

### tag=2 (IPv4 CIDR)

- `ip_u32_le` (network-order IPv4 packed as u32; i.e. `a<<24 | b<<16 | c<<8 | d`)
- `prefix_len_u32_le` (`0..32`)

### tag=3 (IPv6 CIDR)

- `ip16_bytes` (bytes blob; must be exactly 16 bytes)
- `prefix_len_u32_le` (`0..128`)

---

## NetCapsV1

Caps are passed into requests and are separately enforced by `run-os-sandboxed` policy.

Binary format:

- `connect_timeout_ms_u32_le`
- `read_timeout_ms_u32_le`
- `write_timeout_ms_u32_le`
- `max_body_bytes_u32_le`
- `max_header_bytes_u32_le`
- `tls_verify_mode_u32_le`
  - `0` = default (verify)
  - `1` = insecure (no verify) **(policy may forbid)**

---

## HeadersV1 (header table encoding)

Headers are represented as a compact table, not as raw `\r\n` HTTP text.

Binary format:

- `count_u32_le`
- then `count` entries:

Each entry:

- `key_len_u32_le`
- `key_bytes` (header field name)
- `val_len_u32_le`
- `val_bytes` (header field value)

### Canonical header keys

HTTP field names are case-insensitive; canonicalization stores **lowercased ASCII** keys. See RFC 9110 for field-name casing rules.

### Duplicate header names

HTTP allows repeated field names, and some fields are defined as comma-separated lists. RFC 9110 defines how multiple field lines can be combined into a “combined field value” (comma-separated), with well-known exceptions like `set-cookie`.

For agent-friendliness, the package provides **two deterministic approaches**:

1) **No-duplicates builder (overwrite semantics)**

- `std.net.http.spec.headers_set_v1(table, key, val) -> bytes`
- Behavior:
  - lowercases `key`
  - removes *all* existing entries with that key
  - inserts exactly one entry (preserving the position of the first occurrence if present; otherwise appends)

This guarantees the resulting table has **at most one** entry for that name.

2) **Duplicate-combining canonicalizer**

- `std.net.http.spec.headers_canon_join_sorted_v1(table) -> bytes`
- Behavior:
  - runs `headers_canon_sorted_v1` (lowercase + stable sort by `(key, value)`)
  - then groups adjacent equal keys and joins values with the literal separator `", "` (comma + single space)
  - the joined value order is deterministic (sorted-by-value)

This is the canonical choice when you want encoded requests to match the common “one field line per name” style.

**Note:** do not use join-canonicalization for response headers that are not list-combinable (e.g. `set-cookie`) unless you intentionally want the combined representation.

---

## HttpReqV1

Binary format:

- `method_u32_le`
  - `1` = GET
  - `2` = POST
  - `3` = PUT
  - `4` = DELETE
- `url_bytes` (bytes blob; UTF-8)
- `headers_table_bytes` (bytes blob; contains a full HeadersV1 blob)
- `body_bytes` (bytes blob)
- `caps_bytes` (bytes blob; contains a full NetCapsV1 blob)

Agent helpers:

- `std.net.http.spec.req_get_v1(url, headers_table, caps)`
- `std.net.http.spec.req_post_v1(url, headers_table, body, caps)`

Both helpers **canonicalize headers** via `headers_canon_join_sorted_v1(...)` before encoding.

---

## HttpRespV1

Binary format:

- `ok_tag_u32_le`
  - `1` = OK
  - `0` = ERR
- if OK:
  - `status_u32_le`
  - `headers_table_bytes` (bytes blob; HeadersV1)
  - `body_bytes` (bytes blob)
- if ERR:
  - `err_code_u32_le` (deterministic)
  - `err_detail_bytes` (bytes blob; optional debug string)

---

## Determinism notes

- Canonical encoding is required to keep request hashes stable.
- When in doubt: build headers with `headers_set_v1`, and let `req_*_v1` do final canonicalization.

