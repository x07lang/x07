# Native math backend (libevolang_math)

This document describes the **native** implementation strategy for the external
math package (`evolang-ext-math`).

## What is pinned

The C ABI between `evolangc`-emitted code and the math backend is pinned by:

- `crates/evolangc/include/evolang_math_abi_v1.h`

Backends must export the symbols declared in that header.

## Required runtime hooks

The math backend does not own memory. It allocates result `bytes` using the
Evolang runtime allocator:

- `ev_bytes ev_bytes_alloc(uint32_t len)`

The backend may trap (abort) on invariant violations:

- `void ev_trap(int32_t code)`

## Building

Use:

- `scripts/build_ext_math.sh`

This builds `crates/evolang-math-native` and stages the outputs into:

- `deps/evolang/libevolang_math.a`
- `deps/evolang/include/evolang_math_abi_v1.h`

## CI

- `scripts/ci/check_math_smoke.sh`

Runs the two smoke suites:

- `benchmarks/smoke/math-f64-bits-smoke.json` (pure)
- `benchmarks/smoke/math-f64-libm-smoke.json` (run-os)
