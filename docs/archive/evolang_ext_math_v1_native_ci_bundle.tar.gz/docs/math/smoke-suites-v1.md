# Math package smoke suites (v1)

These JSON files are *shapes* intended for a simple smoke runner:
- compile the program (`program_evojson`)
- run it in the specified world
- compare `stdout` bytes to `expected_b64` for each case
- optionally pass a sandbox policy file (run-os-sandboxed)

Files:
- `benchmarks/smoke/math-f64-bits-smoke.json` (pure, deterministic)
- `benchmarks/smoke/math-f64-libm-smoke.json` (run-os, requires native backend)

Note: the repo may already have a different test harness; these shapes are meant to be copy/paste-ready as a starting point.
