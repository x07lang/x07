#!/usr/bin/env bash
set -euo pipefail

# CI entrypoint: build the native math backend and run its smoke suites.
#
# This script is intentionally lightweight and should work in:
# - Linux/macOS shells
# - Windows Git-Bash (or MSYS2) environments
#
# Environment overrides:
# - EVOLANG_BIN: path to the Evolang CLI (defaults to target/release/evolang)
# - EVOLANG_SMOKE_CMD: full command to run a smoke suite (defaults to "$EVOLANG_BIN smoke")

ROOT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)

# 1) Build + stage the native backend
"$ROOT_DIR/scripts/build_ext_math.sh"

# 2) Find the Evolang CLI
EVOLANG_BIN=${EVOLANG_BIN:-"$ROOT_DIR/target/release/evolang"}
if [[ ! -x "$EVOLANG_BIN" ]]; then
  # fallback for local dev
  if [[ -x "$ROOT_DIR/target/debug/evolang" ]]; then
    EVOLANG_BIN="$ROOT_DIR/target/debug/evolang"
  else
    echo "ERROR: Evolang CLI not found. Set EVOLANG_BIN=/path/to/evolang" >&2
    exit 2
  fi
fi

SMOKE_CMD=${EVOLANG_SMOKE_CMD:-"$EVOLANG_BIN smoke"}

# 3) Run suites
cd "$ROOT_DIR"

echo "[math-smoke] running suite: benchmarks/smoke/math-f64-bits-smoke.json"
$SMOKE_CMD benchmarks/smoke/math-f64-bits-smoke.json

echo "[math-smoke] running suite: benchmarks/smoke/math-f64-libm-smoke.json"
$SMOKE_CMD benchmarks/smoke/math-f64-libm-smoke.json

echo "[math-smoke] OK"
