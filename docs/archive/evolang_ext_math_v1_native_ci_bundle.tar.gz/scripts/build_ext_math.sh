#!/usr/bin/env bash
set -euo pipefail

# Builds the native math backend static library and stages it into deps/.
#
# Expected consumers:
# - evolangc link step should add deps/evolang/libevolang_math.a (or .lib on MSVC)
# - generated C can include deps/evolang/include/evolang_math_abi_v1.h

ROOT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)

# Force a deterministic, repo-root target dir so downstream scripts can find artifacts.
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-$ROOT_DIR/target}"

# 1) Build the native library
(
  cd "$ROOT_DIR"
  cargo build --manifest-path crates/evolang-math-native/Cargo.toml --release
)

# 2) Locate the produced static library artifact
LIB_CANDIDATES=(
  "$ROOT_DIR/target/release/libevolang_math.a"
  "$ROOT_DIR/target/release/evolang_math.lib"
  "$ROOT_DIR/target/release/libevolang_math.lib"
)

LIB_PATH=""
for c in "${LIB_CANDIDATES[@]}"; do
  if [[ -f "$c" ]]; then
    LIB_PATH="$c"
    break
  fi
done

if [[ -z "$LIB_PATH" ]]; then
  echo "ERROR: could not find built evolang_math static library under target/release/." >&2
  echo "Tried: ${LIB_CANDIDATES[*]}" >&2
  exit 2
fi

# 3) Stage deterministically into deps/
DEPS_DIR="$ROOT_DIR/deps/evolang"
mkdir -p "$DEPS_DIR/include"

cp -f "$ROOT_DIR/crates/evolang-math-native/include/evolang_math_abi_v1.h" \
  "$DEPS_DIR/include/evolang_math_abi_v1.h"

# Normalize name for non-MSVC platforms; keep original extension alongside for MSVC.
if [[ "$LIB_PATH" == *.a ]]; then
  cp -f "$LIB_PATH" "$DEPS_DIR/libevolang_math.a"
else
  cp -f "$LIB_PATH" "$DEPS_DIR/$(basename "$LIB_PATH")"
fi

echo "Staged:"
echo "  $DEPS_DIR/include/evolang_math_abi_v1.h"
echo "  $DEPS_DIR/$(basename "$LIB_PATH")"
