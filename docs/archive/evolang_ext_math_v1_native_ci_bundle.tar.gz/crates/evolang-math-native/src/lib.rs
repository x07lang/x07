#![allow(non_camel_case_types)]
#![allow(clippy::missing_safety_doc)]

// NOTE: This crate is a *native backend* for Evolang's external math package.
// It exposes a pinned C ABI (see include/evolang_math_abi_v1.h) so the generated C
// from evolangc can call these functions directly.
//
// Determinism goals:
// - math functions use the `libm` crate (pure Rust implementations).
// - float formatting uses the `ryu` crate (shortest, correctly-rounded, deterministic).
// - parsing uses Rust's built-in `f64::from_str` for now; if you need tighter guarantees
//   or faster parsing, swap in a pinned parser crate behind the same error codes.

use core::ffi::c_void;

#[repr(C)]
#[derive(Copy, Clone)]
pub struct ev_bytes {
    pub ptr: *mut u8,
    pub len: u32,
}

#[repr(C)]
#[derive(Copy, Clone)]
pub struct ev_result_bytes {
    pub tag: u32, // 1 = ok, 0 = err
    pub err: i32,
    pub ok: ev_bytes,
}

extern "C" {
    // Provided by the Evolang runtime (generated C).
    fn ev_bytes_alloc(len: u32) -> ev_bytes;

    // Must not return.
    fn ev_trap(code: i32) -> !;

    // Optional: if your runtime wants to charge fuel / stats for native ops,
    // you can provide a hook here and call it from each builtin.
    #[allow(dead_code)]
    fn ev_native_tick(_op: u32, _arg0: u32, _arg1: u32) -> c_void;
}

// Keep these in sync with the header.
const EV_TRAP_MATH_BADLEN_F64: i32 = 9100;
const EV_TRAP_MATH_BADLEN_U32LE: i32 = 9101;

// SPEC_ERR space (math package) — mirrored from docs/math/math-v1.md.
const SPEC_ERR_F64_PARSE_INVALID: i32 = 1001;
const SPEC_ERR_F64_PARSE_NONFINITE: i32 = 1002;

#[inline]
unsafe fn bytes_as_slice(b: ev_bytes) -> &'static [u8] {
    core::slice::from_raw_parts(b.ptr as *const u8, b.len as usize)
}

#[inline]
unsafe fn bytes_as_mut_slice(b: ev_bytes) -> &'static mut [u8] {
    core::slice::from_raw_parts_mut(b.ptr as *mut u8, b.len as usize)
}

#[inline]
fn canonicalize_nan(x: f64) -> f64 {
    if x.is_nan() {
        // Canonical quiet NaN payload.
        f64::from_bits(0x7ff8_0000_0000_0000)
    } else {
        x
    }
}

#[inline]
unsafe fn read_f64_le(b: ev_bytes) -> f64 {
    if b.len != 8 {
        ev_trap(EV_TRAP_MATH_BADLEN_F64);
    }
    let s = bytes_as_slice(b);
    let mut arr = [0u8; 8];
    arr.copy_from_slice(&s[0..8]);
    f64::from_bits(u64::from_le_bytes(arr))
}

#[inline]
unsafe fn write_f64_le(dst: ev_bytes, x: f64) {
    if dst.len != 8 {
        ev_trap(EV_TRAP_MATH_BADLEN_F64);
    }
    let s = bytes_as_mut_slice(dst);
    let bits = canonicalize_nan(x).to_bits().to_le_bytes();
    s[0..8].copy_from_slice(&bits);
}

#[inline]
unsafe fn alloc_bytes(len: u32) -> ev_bytes {
    let out = ev_bytes_alloc(len);
    if out.len != len {
        // A conservative check: runtime should return exactly requested length.
        // If it doesn't, fail fast.
        ev_trap(9102);
    }
    out
}

#[inline]
fn ok_bytes(b: ev_bytes) -> ev_result_bytes {
    ev_result_bytes { tag: 1, err: 0, ok: b }
}

#[inline]
fn err(code: i32) -> ev_result_bytes {
    ev_result_bytes {
        tag: 0,
        err: code,
        ok: ev_bytes { ptr: core::ptr::null_mut(), len: 0 },
    }
}

// --- f64 arithmetic ---

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_add_v1(a: ev_bytes, b: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let y = read_f64_le(b);
    let out = alloc_bytes(8);
    write_f64_le(out, x + y);
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_sub_v1(a: ev_bytes, b: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let y = read_f64_le(b);
    let out = alloc_bytes(8);
    write_f64_le(out, x - y);
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_mul_v1(a: ev_bytes, b: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let y = read_f64_le(b);
    let out = alloc_bytes(8);
    write_f64_le(out, x * y);
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_div_v1(a: ev_bytes, b: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let y = read_f64_le(b);
    let out = alloc_bytes(8);
    write_f64_le(out, x / y);
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_neg_v1(a: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let out = alloc_bytes(8);
    write_f64_le(out, -x);
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_abs_v1(a: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let out = alloc_bytes(8);
    write_f64_le(out, x.abs());
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_min_v1(a: ev_bytes, b: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let y = read_f64_le(b);
    let out = alloc_bytes(8);
    // IEEE 754 minNum behavior isn't the same as Rust's min when NaNs are involved.
    // We define v1 as: if either is NaN => canonical NaN; else smaller.
    let r = if x.is_nan() || y.is_nan() { f64::NAN } else { x.min(y) };
    write_f64_le(out, r);
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_max_v1(a: ev_bytes, b: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let y = read_f64_le(b);
    let out = alloc_bytes(8);
    let r = if x.is_nan() || y.is_nan() { f64::NAN } else { x.max(y) };
    write_f64_le(out, r);
    out
}

// --- f64 libm-ish ---

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_sqrt_v1(a: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let out = alloc_bytes(8);
    write_f64_le(out, libm::sqrt(x));
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_sin_v1(a: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let out = alloc_bytes(8);
    write_f64_le(out, libm::sin(x));
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_cos_v1(a: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let out = alloc_bytes(8);
    write_f64_le(out, libm::cos(x));
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_exp_v1(a: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let out = alloc_bytes(8);
    write_f64_le(out, libm::exp(x));
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_ln_v1(a: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let out = alloc_bytes(8);
    write_f64_le(out, libm::log(x));
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_pow_v1(a: ev_bytes, b: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let y = read_f64_le(b);
    let out = alloc_bytes(8);
    write_f64_le(out, libm::pow(x, y));
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_atan2_v1(y: ev_bytes, x: ev_bytes) -> ev_bytes {
    let yy = read_f64_le(y);
    let xx = read_f64_le(x);
    let out = alloc_bytes(8);
    write_f64_le(out, libm::atan2(yy, xx));
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_floor_v1(a: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let out = alloc_bytes(8);
    write_f64_le(out, libm::floor(x));
    out
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_ceil_v1(a: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let out = alloc_bytes(8);
    write_f64_le(out, libm::ceil(x));
    out
}

// --- f64 cmp ---

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_cmp_v1(a: ev_bytes, b: ev_bytes) -> ev_bytes {
    let x = read_f64_le(a);
    let y = read_f64_le(b);

    let code: u32 = if x.is_nan() || y.is_nan() {
        3 // unordered
    } else if x < y {
        0
    } else if x > y {
        2
    } else {
        1
    };

    let out = alloc_bytes(4);
    if out.len != 4 {
        ev_trap(EV_TRAP_MATH_BADLEN_U32LE);
    }
    let s = bytes_as_mut_slice(out);
    s[0..4].copy_from_slice(&code.to_le_bytes());
    out
}

// --- f64 parse / fmt ---

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_parse_v1(s: ev_bytes) -> ev_result_bytes {
    // We only accept ASCII/UTF-8 here; invalid UTF-8 is an error.
    let bs = bytes_as_slice(s);
    let st = match core::str::from_utf8(bs) {
        Ok(v) => v.trim(),
        Err(_) => return err(SPEC_ERR_F64_PARSE_INVALID),
    };

    if st.is_empty() {
        return err(SPEC_ERR_F64_PARSE_INVALID);
    }

    // Parse using Rust's from_str (locale-independent). If you want tighter control,
    // replace this with a pinned parser crate but keep error codes stable.
    let x: f64 = match st.parse() {
        Ok(v) => v,
        Err(_) => return err(SPEC_ERR_F64_PARSE_INVALID),
    };

    if !x.is_finite() {
        return err(SPEC_ERR_F64_PARSE_NONFINITE);
    }

    let out = alloc_bytes(8);
    write_f64_le(out, x);
    ok_bytes(out)
}

#[no_mangle]
pub unsafe extern "C" fn ev_math_f64_fmt_shortest_v1(x: ev_bytes) -> ev_bytes {
    let v = read_f64_le(x);
    // Avoid *all* Rust heap allocations: either use a constant string, or ryu's
    // stack buffer for finite numbers.
    let mut buf = ryu::Buffer::new();
    let s: &str = if v.is_nan() {
        "nan"
    } else if v == f64::INFINITY {
        "inf"
    } else if v == f64::NEG_INFINITY {
        "-inf"
    } else {
        buf.format_finite(v)
    };

    let out = alloc_bytes(s.len() as u32);
    let dst = bytes_as_mut_slice(out);
    dst.copy_from_slice(s.as_bytes());
    out
}

