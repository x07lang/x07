# evolang-math-native

This crate builds **`libevolang_math.a`** (or the platform-equivalent) and exposes the
pinned C ABI declared in:

- `include/evolang_math_abi_v1.h`

It is intended to be linked into binaries emitted by `evolangc` whenever the
external `evolang-ext-math` package is used.

## Determinism notes

- Formatting uses the `ryu` algorithm (shortest, correctly-rounded) so output is stable.
- Math functions use the pure-Rust `libm` implementations.
- Parsing currently uses Rust's `f64::from_str` (UTF-8, ASCII-ish). If you need a
  stricter/pinned decimal parser, swap in a dedicated parser crate and keep the
  `SPEC_ERR_F64_*` codes.

## Building

```bash
cargo build -p evolang-math-native --release
```

Then run:

```bash
scripts/build_ext_math.sh
```

which copies the header + staticlib into `deps/evolang/` for toolchain linking.
