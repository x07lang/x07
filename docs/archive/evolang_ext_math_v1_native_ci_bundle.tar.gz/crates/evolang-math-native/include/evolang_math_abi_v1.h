#ifndef EVOLANG_MATH_ABI_V1_H
#define EVOLANG_MATH_ABI_V1_H

// Evolang Math Backend ABI (v1)
//
// This header is *pinned* and is intended to be included by:
//  - the generated C produced by evolangc (call sites)
//  - the native math backend library implementation (libevolang_math.a)
//
// Design goals:
//  - Stable C ABI across platforms (Linux/macOS/Windows)
//  - Minimal surface: only what the math builtins need
//  - No dependency on Rust layout defaults (everything is explicit)

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// --- Core value types (must match evolangc's runtime ABI) ---

// bytes = (ptr, len) where len is the number of bytes.
// The runtime owns the allocation pointed to by ptr.
//
// IMPORTANT: the math backend must allocate outputs using ev_bytes_alloc().
// Do NOT malloc/free directly.
typedef struct {
  uint8_t* ptr;
  uint32_t len;
} ev_bytes;

// result_bytes = either Ok(bytes) or Err(i32)
// tag: 1 = Ok, 0 = Err
typedef struct {
  uint32_t tag;
  int32_t err;
  ev_bytes ok;
} ev_result_bytes;

// --- Runtime hooks required by the math backend ---

// Allocate a bytes buffer of exactly `len` bytes in the Evolang runtime allocator.
// This must be provided by the generated runtime.
ev_bytes ev_bytes_alloc(uint32_t len);

// Trap (non-recoverable). This must be provided by the generated runtime.
// The math backend uses traps only for impossible-in-well-typed-programs invariants
// (e.g. wrong-length f64 bytes).
void ev_trap(int32_t code);

// --- Trap codes (reserved range for math backend) ---

// These codes must not overlap other runtime trap codes.
// If you already have a global trap catalog, map these into it.
enum {
  EV_TRAP_MATH_BADLEN_F64 = 9100,  // input bytes len != 8
  EV_TRAP_MATH_BADLEN_U32 = 9101,  // input bytes len != 4
  EV_TRAP_MATH_INTERNAL   = 9102
};

// --- Encoding conventions ---

// f64 values are encoded as 8 bytes, little-endian IEEE-754 binary64 bit patterns.
// u32 values are encoded as 4 bytes, little-endian.
//
// All functions below:
//  - TRAP with EV_TRAP_MATH_BADLEN_* if any input byte string has the wrong length.
//  - Allocate output bytes via ev_bytes_alloc().

// --- f64 arithmetic ---

// (math.f64.add_v1 a b) -> f64_bytes
// (math.f64.sub_v1 a b) -> f64_bytes
// (math.f64.mul_v1 a b) -> f64_bytes
// (math.f64.div_v1 a b) -> f64_bytes

ev_bytes ev_math_f64_add_v1(ev_bytes a, ev_bytes b);
ev_bytes ev_math_f64_sub_v1(ev_bytes a, ev_bytes b);
ev_bytes ev_math_f64_mul_v1(ev_bytes a, ev_bytes b);
ev_bytes ev_math_f64_div_v1(ev_bytes a, ev_bytes b);

// --- f64 unary ops ---

ev_bytes ev_math_f64_neg_v1(ev_bytes x);
ev_bytes ev_math_f64_abs_v1(ev_bytes x);
ev_bytes ev_math_f64_sqrt_v1(ev_bytes x);
ev_bytes ev_math_f64_floor_v1(ev_bytes x);
ev_bytes ev_math_f64_ceil_v1(ev_bytes x);

// --- f64 transcendentals ---

ev_bytes ev_math_f64_sin_v1(ev_bytes x);
ev_bytes ev_math_f64_cos_v1(ev_bytes x);
ev_bytes ev_math_f64_exp_v1(ev_bytes x);
ev_bytes ev_math_f64_ln_v1(ev_bytes x);
ev_bytes ev_math_f64_pow_v1(ev_bytes x, ev_bytes y);
ev_bytes ev_math_f64_atan2_v1(ev_bytes y, ev_bytes x);

// --- f64 comparisons (returns i32 as 4-byte LE) ---

// (math.f64.cmp_v1 a b) -> u32_le:
//   0 = less, 1 = equal, 2 = greater, 3 = unordered (NaN involved)
ev_bytes ev_math_f64_cmp_v1(ev_bytes a, ev_bytes b);

// --- f64 text interop ---

// (math.f64.fmt_shortest_v1 x) -> bytes (UTF-8, ASCII subset)
// Canonical formatting:
//  - no leading '+',
//  - 'nan', 'inf', '-inf' for non-finite,
//  - otherwise shortest round-trippable decimal.
ev_bytes ev_math_f64_fmt_shortest_v1(ev_bytes x);

// (math.f64.parse_v1 s) -> result_bytes
// Accepts:
//  - optional leading/trailing ASCII spaces,
//  - optional leading sign,
//  - decimal, optional exponent.
// Returns Err(code) on invalid syntax or overflow.
ev_result_bytes ev_math_f64_parse_v1(ev_bytes s);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // EVOLANG_MATH_ABI_V1_H
