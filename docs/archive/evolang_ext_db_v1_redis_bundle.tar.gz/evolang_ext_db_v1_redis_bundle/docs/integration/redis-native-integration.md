# Redis native adapter integration (REFERENCE)

This file is **implementation guidance**, not a normative contract.

Recommended native client: **hiredis** + **hiredis_ssl** (RESP3 + SSL landed in hiredis v1.0.0).

- hiredis changelog / v1.0.0 notes: https://github.com/redis/hiredis/blob/master/CHANGELOG.md

## High-level plan

1. Add a new adapter module in the run-os runtime:
   - Builtins:
     - os.db.redis.open_v1(req: bytes, caps: bytes) -> bytes
     - os.db.redis.cmd_v1(req: bytes, caps: bytes) -> bytes
     - os.db.redis.close_v1(req: bytes, caps: bytes) -> bytes

2. Parse request encodings:
   - EVRO (OpenReqV1)
   - EVRQ (CmdReqV1)
   - EVRX (CloseReqV1)
   - EVRV (ArgvTableV1)

3. Policy enforcement (run-os-sandboxed):
   - Require db.drivers.redis == true
   - Enforce db.net allowlists (DNS name allowlist + CIDR allowlist)
   - Enforce db.max_conns, db.max_queries, db.max_bytes_in/out (if you already have these limits for other DB drivers)

4. Connection establishment (open_v1):
   - Connect TCP (or UNIX on POSIX).
   - If TLS flag is set, create SSL context and initiate SSL (hiredis_ssl).
   - Negotiate RESP3: send `HELLO 3` immediately after connect.
   - If user/pass are provided: send `AUTH user pass` (or `AUTH pass` if user empty).
   - If db != 0: send `SELECT db`.

   Return EVDB.ok with payload EVRK (OpenOkV1).

5. Command execution (cmd_v1):
   - Parse EVRV into `argc` + `argv[]` byte slices.
   - Use `redisCommandArgv()` (hiredis) so you never have to re-encode RESP manually.
   - Convert `redisReply*` to an EVDM DataModel doc:
     - map/set: sort keys/elements for canonical DataModel encoding.
   - Enforce `caps.max_resp_bytes` (fail with DB_REDIS_ERR_RESP_TOO_LARGE).

6. Close (close_v1):
   - Free the hiredis context and remove conn_id from process table.
   - Return EVDB.ok with empty payload (len=0).

## Determinism notes

Redis I/O is non-deterministic by nature in run-os worlds, but the adapter should still be **stable**:

- Always sort RESP3 map keys and set elements before encoding DataModel so programs see canonical output for the same logical reply.
