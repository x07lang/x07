# Redis v1 (ext-db-redis)

This document pins the **Redis adapter contract v1** for Evolang’s external database ecosystem.

Scope:

- **Worlds:** `run-os` and `run-os-sandboxed` only (non-deterministic I/O).
- **Protocol:** Redis **RESP3** with `HELLO 3` on connect.
- **TLS:** supported in v1 (rediss:// equivalent), with optional “insecure” mode for tests.
- **Return type:** all command results are returned as an **EVDM DataModel doc** (so Redis integrates naturally with your DataModel-first ecosystem).

References (normative protocol behavior):

- Redis `HELLO` / protocol negotiation (RESP3 via `HELLO 3`).  
  https://redis.io/docs/latest/commands/hello/
- Redis `AUTH` (ACL-style username/password).  
  https://redis.io/docs/latest/commands/auth/
- Redis protocol / RESP3 type system.  
  https://redis.io/docs/latest/develop/reference/protocol-spec/

---

## 1. API surface

### 1.1 Builtins (runner/adapter side)

These are implemented in the `run-os*` runtime (C/Rust), *not* in pure stdlib code:

- `os.db.redis.open_v1(req: bytes, caps: bytes) -> bytes`
- `os.db.redis.cmd_v1(req: bytes, caps: bytes) -> bytes`
- `os.db.redis.close_v1(req: bytes, caps: bytes) -> bytes`

All three return an `EVDB` response envelope (see `docs/db/db-v1.md` in ext-db-core).

### 1.2 Stdlib wrappers (this package)

The package `evolang:ext-db-redis@0.1.0` provides:

- `std.db.redis.open_req_tcp_v1(host, port, user, pass, db, flags) -> bytes`
- `std.db.redis.open_req_unix_v1(path, user, pass, db, flags) -> bytes`
- `std.db.redis.open_v1(req, caps) -> bytes`
- `std.db.redis.open_ok_conn_id_v1(resp) -> i32`

- `std.db.redis.argv.empty_v1() -> bytes`
- `std.db.redis.argv.push_v1(argv, arg_bytes) -> bytes`
- `std.db.redis.argv.from1_v1(a0) -> bytes`
- `std.db.redis.argv.from2_v1(a0,a1) -> bytes`
- `std.db.redis.argv.from3_v1(a0,a1,a2) -> bytes`

- `std.db.redis.cmd_req_v1(conn_id, argv, flags) -> bytes`
- `std.db.redis.cmd_v1(req, caps) -> bytes`
- `std.db.redis.cmd_doc_v1(resp) -> bytes`  (returns `EVDM` doc)

- `std.db.redis.close_req_v1(conn_id, flags) -> bytes`
- `std.db.redis.close_v1(req, caps) -> bytes`

---

## 2. Encodings (bytes contracts)

All encodings in this doc are **little-endian** for integers.

### 2.1 ArgvTableV1 (EVRV)

Binary encoding used for Redis `cmd_v1` argv lists (agents never hand-roll; they use helpers).

```
EVRV (ArgvTableV1)
  0..4   magic ASCII "EVRV"
  4..8   version_u32 = 1
  8..12  count_u32
  12..   rows...

Row i (repeated count times):
  u32_le byte_len
  [byte_len] bytes payload (raw bytes; may be non-utf8)
```

### 2.2 OpenReqV1 (EVRO)

```
EVRO (OpenReqV1)
  0..4   magic ASCII "EVRO"
  4..8   version_u32 = 1
  8..12  flags_u32
  12..16 kind_u32 (1=tcp, 2=unix)

If kind=1 (tcp):
  16..20 host_len_u32
  20..   host bytes
  ..+4   port_u32

If kind=2 (unix):
  16..20 path_len_u32
  20..   path bytes
```

Auth + db selection (optional):

After the address fields, both kinds append:

```
  user_len_u32, user bytes
  pass_len_u32, pass bytes
  db_u32   (0 means “no SELECT”; non-zero means run SELECT db on connect)
```

### 2.3 CmdReqV1 (EVRQ)

```
EVRQ (CmdReqV1)
  0..4   magic ASCII "EVRQ"
  4..8   version_u32 = 1
  8..12  flags_u32
  12..16 conn_id_u32
  16..20 argv_len_u32
  20..   argv bytes (EVRV)
```

### 2.4 CloseReqV1 (EVRX)

```
EVRX (CloseReqV1)
  0..4   magic ASCII "EVRX"
  4..8   version_u32 = 1
  8..12  flags_u32
  12..16 conn_id_u32
```

### 2.5 OpenOkV1 payload (EVRK) inside EVDB.ok_payload

For `os.db.redis.open_v1`, the EVDB ok payload is:

```
EVRK (OpenOkV1)
  0..4   magic ASCII "EVRK"
  4..8   version_u32 = 1
  8..12  conn_id_u32
```

### 2.6 Caps (EVDC)

Redis reuses the **standard DB caps** encoding `EVDC` already used by SQLite/PG/MySQL:

- connect_timeout_ms_u32
- query_timeout_ms_u32
- max_rows_u32 (ignored by Redis adapter; reserved for uniformity)
- max_resp_bytes_u32 (hard cap; MUST be enforced)

See `std.db.*.spec.caps_pack_v1` in existing DB packages for the exact EVDC layout.

---

## 3. RESP3 → DataModel mapping

The adapter MUST negotiate RESP3 (`HELLO 3`) and then map the reply into a DataModel value:

- **Null** (`_`) → DataModel `null`
- **Boolean** (`#t/#f`) → DataModel `bool`
- **Integer** (`:`) → DataModel `number` (decimal ASCII bytes)
- **Double** (`,`) → DataModel `number` (the exact ASCII returned by Redis)
- **Simple string / blob string / verbatim** (`+`, `$`, `=`) → DataModel `string` (raw bytes)
- **Array** (`*`) → DataModel `seq` (order preserved)
- **Map** (`%`) → DataModel `map`
  - Keys are encoded as DataModel `string` bytes.
  - **Determinism rule:** map entries MUST be sorted by key bytes ascending before encoding, because DataModel maps are canonicalized.
- **Set** (`~`) → DataModel `seq`
  - **Determinism rule:** set elements MUST be sorted by element bytes ascending before encoding.

Attributes (`|`) are ignored for v1 (apply to the following reply, but do not surface in DataModel).

Error replies:
- If the top-level reply is an error (`-` / `!`), the adapter MUST return `EVDB.err` with:
  - `err_code = DB_REDIS_ERR_SERVER_REPLY`
  - `err_msg = server error string bytes`

---

## 4. Error codes (reserved numeric space)

Allocate Redis-specific adapter/spec codes under:

- `2000640000 .. 2000640999`  (DB_REDIS_*)

Suggested v1 set:

- `2000640001` DB_REDIS_ERR_INVALID_REQ
- `2000640002` DB_REDIS_ERR_INVALID_CAPS
- `2000640003` DB_REDIS_ERR_POLICY_DENIED
- `2000640004` DB_REDIS_ERR_CONNECT_FAILED
- `2000640005` DB_REDIS_ERR_TLS_FAILED
- `2000640006` DB_REDIS_ERR_TIMEOUT
- `2000640007` DB_REDIS_ERR_PROTOCOL
- `2000640008` DB_REDIS_ERR_RESP_TOO_LARGE
- `2000640009` DB_REDIS_ERR_SERVER_REPLY
- `2000640010` DB_REDIS_ERR_CONN_CLOSED
- `2000640011` DB_REDIS_ERR_MAX_CONNS
- `2000640012` DB_REDIS_ERR_MAX_QUERIES

---

## 5. run-os-sandboxed policy requirements

The adapter must be gated by policy:

- `db.drivers.redis: true`
- the target address must be allowed by `db.net.host_allowlist` and/or `db.net.cidr_allowlist`

See `schemas/run-os-policy.db.section.redis.json` in this bundle for the schema fragment.
