# EVSL v1 — Evolang Slice List (canonical bytes encoding)

EVSL is the **canonical** bytes encoding for a list of slices `(start,len)` into some **base** byte buffer (or `bytes_view`).
It is designed to be:
- deterministic (stable across runs/platforms),
- compact (8 bytes per slice),
- and easy for agents to consume without manual offset math (via `std.text.slices` helpers).

This document is **normative** for EVSL v1.

## Byte order and integer types

- All integers are **u32 little-endian** (`u32_le`) encoded as 4 bytes.
- `start` and `len` are interpreted as `u32` offsets into a base buffer.

## Encoding

An EVSL v1 blob is:

- Header (12 bytes)
  1. `magic[4]` = ASCII bytes `EVSL` (`0x45 0x56 0x53 0x4C`)
  2. `version_u32_le` = `1`
  3. `count_u32_le` = number of rows

- Rows (`count` × 8 bytes)
  - `start_u32_le`
  - `len_u32_le`

### Total length

The total byte length **MUST** be exactly:

```
12 + count*8
```

Trailing bytes are **not allowed**.

## Semantics

- Each row describes a slice `[start, start+len)` into some base buffer.
- EVSL does **not** include the base buffer length. Bounds checks require the base length.

### Canonical row order

Producers **SHOULD** emit rows in **ascending `start`** order.
If multiple rows share the same `start`, they **SHOULD** be ordered by ascending `len`.

(Consumers may rely on this for binary-search-based lookups.)

## Validation error codes (std.text.slices.validate_v1)

`std.text.slices.validate_v1(evsl)` returns `result_i32` with:

- `OK(count)` on success
- `ERR(code)` on failure, using these deterministic codes:

| Code (hex)     | Name                       | Meaning |
|---------------:|----------------------------|---------|
| `0x7E510001`    | `EVSL_ERR_TRUNCATED`       | `bytes.len(evsl) < 12` |
| `0x7E510002`    | `EVSL_ERR_UNSUPPORTED_VER` | `version != 1` |
| `0x7E510003`    | `EVSL_ERR_LEN_MISMATCH`    | `bytes.len(evsl) != 12 + count*8` |
| `0x7E510004`    | `EVSL_ERR_BAD_MAGIC`       | first 4 bytes are not `EVSL` |

Notes:
- v1 validation checks **only** the EVSL framing (magic/version/length).
  Checking whether `(start+len) <= base_len` is done by the caller (because base_len is not in EVSL).

## Stdlib helpers

See `stdlib/std/0.1.1/modules/std/text/slices.evo.json`:

- Builder:
  - `std.text.slices.builder_new_v1(cap_hint)`
  - `std.text.slices.builder_push_v1(out,start,len)`
  - `std.text.slices.builder_finish_v1(out,count)` → `bytes`

- Accessors:
  - `std.text.slices.count_v1(evsl)` → `i32` (count or `-1` on invalid)
  - `std.text.slices.start_v1(evsl,idx)` → `i32`
  - `std.text.slices.len_v1(evsl,idx)` → `i32`
  - `std.text.slices.view_at_v1(base_view,evsl,idx)` → `bytes_view`
  - `std.text.slices.copy_at_v1(base_view,evsl,idx)` → `bytes` (explicit copy)
