# evolang:cli@0.1.0

CLI v1 package for Evolang.

- Authoring format: `SpecRows` JSON (see `spec/evocli.specrows.schema.json`)
- Normative doc: `docs/cli/cli-v1.md`

This is a **skeleton** package: the modules contain stub functions with stable names/signatures and placeholder behavior.
