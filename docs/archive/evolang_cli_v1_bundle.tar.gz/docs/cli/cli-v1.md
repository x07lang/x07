# CLI v1 (EvoCLI) — SpecRows + deterministic parser

This document defines the **normative** v1 contract for Evolang’s CLI package (`evolang:cli`).

Goals:

- **LLM-first authoring**: CLI interfaces are defined as *data* (`SpecRows`) that tools can lint, format, and compile.
- **Deterministic parsing**: the same `SpecRows` + same argv bytes ⇒ identical `matches` bytes.
- **Two-world binding**:
  - pure world: validate/compile specs (no OS access)
  - run-os / run-os-sandboxed: read argv/env, print help, exit with codes

Non-goals (v1):

- Nested subcommands (only root + 1 level subcommands).
- Rich terminal UI (colors, paging).
- Internationalization.

---

## Files / Formats

### 1) SpecRows JSON (authoring format)

`SpecRows` is a JSON object that validates against `spec/evocli.specrows.schema.json`.

It is intentionally “row-based” (like a spreadsheet) to stay **easy to diff**, **easy to sort**, and **easy for agents to generate**.

Minimal example:

```json
{
  "schema_version": "evocli.specrows@0.1.0",
  "app": { "name": "mytool", "version": "0.1.0", "about": "Demo tool" },
  "rows": [
    ["root", "about", "Demo tool"],
    ["root", "help", "-h", "--help", "Show help"],
    ["root", "version", "", "--version", "Show version"],

    ["root", "flag", "-v", "--verbose", "verbose", "Increase verbosity", {"global": true}],
    ["root", "opt", "", "--out", "out", "PATH", "Output path", {"required": false}],
    ["root", "arg", "INPUT", "input", "Input file", {"required": true}],

    ["serve", "about", "Run server"],
    ["serve", "opt", "", "--port", "port", "U32", "Port number", {"default": 8080}]
  ]
}
```

#### Row semantics (v1)

- `scope` is `"root"` or a subcommand name (e.g. `"serve"`).
- Any row whose scope is not `"root"` implicitly creates that subcommand.
- `key` is the stable identifier used in `matches`.

Reserved keys:

- `help`, `version` are reserved (must not be used by user rows except in `help/version` rows).

### 2) argv_v1 bytes (OS binding)

`argv_v1` is a `bytes` blob:

- `u32_le argc`
- repeated `argc` times:
  - `u32_le len`
  - `len` bytes (UTF-8), **no NUL**

This avoids ambiguous escaping and allows deterministic binary parsing.

### 3) matches_v1 JSON (parse output)

`std.cli.parse_*` returns `result_bytes`:

- `Ok(bytes)` is UTF-8 canonical JSON with this shape:

  ```json
  {
    "cmd": "root",
    "flags": { "verbose": 2 },
    "opts":  { "out": "out.txt", "port": 8080 },
    "args":  { "input": ["file1.txt"] },
    "rest":  ["--", "ignored"]
  }
  ```

  Rules:
  - All object keys are sorted lexicographically.
  - Flags are emitted as integer counts (`0,1,2,...`).
  - Options are emitted as strings or integers depending on `value_kind`.
  - Positionals are arrays (even when arity is 1) to avoid “sometimes scalar” traps.
  - Unknown args after `--` go to `rest` (including the `--` itself).

- `Err(code)` uses the deterministic CLI error codes listed below.

---

## Parsing rules

### Options and `--`

- Long options: `--name` and `--name=value`.
- Short options: `-a` and short bundles like `-abc` (only flags can bundle).
- The token `--` terminates option parsing; remaining tokens are operands/rest.

(This is aligned with the POSIX utility conventions for `--` as end-of-options.)

### Subcommands

- If the first non-option token matches a declared subcommand scope, parsing switches to that scope.
- v1 supports **only one** subcommand level.

### Duplicate policy

- flags: count occurrences
- options:
  - if `multiple=false` (default): last-wins
  - if `multiple=true`: becomes an array
- args:
  - if `multiple=false` (default): first positional binds, remaining are error unless a later arg row allows multiple
  - if `multiple=true`: collect

---

## Deterministic error codes (v1)

All CLI parsing functions must use the following fixed `i32` codes:

- `CLI_E_OK = 0`
- `CLI_E_INVALID_SPEC = 1001` (SpecRows schema/semantic failure)
- `CLI_E_USAGE = 1002` (unknown option, missing required, bad arity)
- `CLI_E_BAD_VALUE = 1003` (value_kind parse failure)
- `CLI_E_INTERNAL = 1099` (should never happen; indicates a bug)

In OS mode, callers SHOULD map usage errors to exit code **64** (EX_USAGE) when producing a process exit code.

---

## World adapters

The CLI package is split so the bulk stays pure and testable:

Pure API (solve-pure compatible):

- `std.cli.specrows.validate(spec_json_bytes) -> result_i32`
- `std.cli.specrows.compile(spec_json_bytes) -> result_bytes`  (emits a compact specbin)
- `std.cli.help.render(spec_json_bytes) -> bytes` (help text)
- `std.cli.complete.render(spec_json_bytes, shell_kind_bytes) -> bytes`

OS binding (run-os / run-os-sandboxed only):

- `std.cli.os.argv_v1() -> bytes`  (argv_v1 encoding)
- `std.cli.os.env_get(key_bytes) -> option_bytes`
- `std.cli.os.exit(code_i32) -> i32`
- `std.cli.os.stdout_write(bytes) -> i32`
- `std.cli.os.stderr_write(bytes) -> i32`

Unified parse helpers:

- `std.cli.parse_specrows_or_exit(spec_json_bytes) -> bytes` (returns matches JSON bytes or exits)
- `std.cli.parse_compiled_or_exit(specbin_bytes) -> bytes`

---

## Completion scripts

v1 supports a minimal completion surface:

- `shell_kind_bytes` is one of: `bash`, `zsh`, `fish`, `powershell`.
- Completion generation must be deterministic (sorted options, stable quoting).
- Recommendation: generate completion on demand (so it stays in sync with the binary).

---

## Implementation checklist (for this package)

- A semantic validator must reject:
  - duplicate keys within a scope
  - invalid short bundles (e.g. options with values inside a bundle)
  - `--` used as a declared option
  - reserved keys used by user definitions
- A compiler must canonicalize:
  - stable row ordering
  - stable implied defaults (help/version implied if omitted)
- Parser must:
  - be total (never panic)
  - be deterministic
  - never allocate unbounded memory (cap counts/lengths)

---

## Versioning

- Breaking changes require `cli-v2` (new schema_version).
- v1 parsers must reject unknown `schema_version`.
