# Postgres adapter v1 (run-os*)

This document pins the **package-layer contract** for Postgres in ext-db v1.

It defines:
- request bytes encodings (`EVPO/EVPQ/EVPE/EVPC`)
- required OS builtins (`os.db.pg.*`)
- response format (`EVDB`, from `std.db.spec`)

The goal: agents never hand-roll binary encodings; they call `std.db.pg.spec.*`.

## Builtins required (runner/toolchain)

The run-os* world must provide these builtins:

- `os.db.pg.open_v1(req_bytes, caps_bytes) -> bytes` (DbRespV1)
- `os.db.pg.query_v1(req_bytes, caps_bytes) -> bytes` (DbRespV1)
- `os.db.pg.exec_v1(req_bytes, caps_bytes) -> bytes` (DbRespV1)
- `os.db.pg.close_v1(req_bytes, caps_bytes) -> bytes` (DbRespV1)

All return `DbRespV1` (`EVDB`) defined by `std.db.spec`.

## Shared caps encoding (EVDC v1)

`std.db.pg.spec.caps_pack_v1(connect_timeout_ms, query_timeout_ms, max_rows, max_resp_bytes) -> bytes`

Exact bytes encoding (little-endian u32):

```
EVDC: [69,86,68,67]
u32  version            = 1
u32  connect_timeout_ms
u32  query_timeout_ms
u32  max_rows
u32  max_resp_bytes
```

This matches `std.db.sqlite.spec.caps_pack_v1` so the same caps tooling works across drivers.

## Requests encoding

All request blobs are little-endian and start with a 4-byte ASCII magic + u32 version.

### PgOpenReqV1 (EVPO)

Produced by: `std.db.pg.spec.open_req_v1(host, port, user, pass, db, flags)`

Encoding:

```
EVPO: [69,86,80,79]
u32 version   = 1
u32 flags

u32 host_len
u8  host[host_len]      ; bytes (UTF-8 recommended)

u32 port                ; 1..65535

u32 user_len
u8  user[user_len]

u32 pass_len
u8  pass[pass_len]

u32 db_len
u8  db[db_len]
```

### PgQueryReqV1 (EVPQ)

Produced by: `std.db.pg.spec.query_req_v1(conn_id, sql_bytes, params_doc, flags)`

Encoding:

```
EVPQ: [69,86,80,81]
u32 version   = 1
u32 conn_id
u32 flags

u32 sql_len
u8  sql[sql_len]            ; UTF-8 SQL

u32 params_len
u8  params_doc[params_len]  ; DataModel doc (see std.db.params)
```

**Parameter placeholder convention:** Postgres uses `$1`, `$2`, … for parameters. citeturn1search6

### PgExecReqV1 (EVPE)

Produced by: `std.db.pg.spec.exec_req_v1(conn_id, sql_bytes, params_doc, flags)`

Same layout as PgQueryReqV1, magic = `EVPE`.

### PgCloseReqV1 (EVPC)

Produced by: `std.db.pg.spec.close_req_v1(conn_id)`

Encoding:

```
EVPC: [69,86,80,67]
u32 version   = 1
u32 conn_id
```

## Response format: DbRespV1 (EVDB)

All builtins return `DbRespV1` (`EVDB`) from `std.db.spec`:

- OK: `resp_is_ok_v1(resp) == 1`
  - open: OK payload is `conn_id_u32le` (4 bytes)
  - query: OK payload is a **DataModel doc** (`ext.data_model.doc_ok(table_value)`)
  - exec: OK payload is a DataModel doc (v1: implementation-defined, but recommended `{rows_affected:number}`)

- ERR: `resp_is_ok_v1(resp) == 0`
  - ERR payload is a deterministic error code (u32le), and optional message bytes.
  - Codes come from the DB v1 error space pinned in `docs/db/db-v1.md`.

## TLS + sandbox policy

For run-os-sandboxed, the runner must enforce host/port allowlists and TLS requirements.

Postgres “sslmode” semantics include `disable`, `require`, `verify-ca`, `verify-full`. citeturn1search1turn1search2

**v1 recommendation:**
- policy drives TLS (request cannot weaken policy)
- allow localhost non-TLS for dev-only smoke suites
- production: require TLS + verification
