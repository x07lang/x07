# MySQL adapter v1 (run-os*)

This document pins the **package-layer contract** for MySQL in ext-db v1.

It defines:
- request bytes encodings (`EVMO/EVMQ/EVME/EVMC`)
- required OS builtins (`os.db.mysql.*`)
- response format (`EVDB`, from `std.db.spec`)

## Builtins required (runner/toolchain)

The run-os* world must provide these builtins:

- `os.db.mysql.open_v1(req_bytes, caps_bytes) -> bytes` (DbRespV1)
- `os.db.mysql.query_v1(req_bytes, caps_bytes) -> bytes` (DbRespV1)
- `os.db.mysql.exec_v1(req_bytes, caps_bytes) -> bytes` (DbRespV1)
- `os.db.mysql.close_v1(req_bytes, caps_bytes) -> bytes` (DbRespV1)

All return `DbRespV1` (`EVDB`) defined by `std.db.spec`.

## Shared caps encoding (EVDC v1)

Same as Postgres + SQLite (see `std.db.sqlite.spec.caps_pack_v1`).

## Requests encoding

All request blobs are little-endian and start with a 4-byte ASCII magic + u32 version.

### MysqlOpenReqV1 (EVMO)

Produced by: `std.db.mysql.spec.open_req_v1(host, port, user, pass, db, flags)`

Encoding:

```
EVMO: [69,86,77,79]
u32 version   = 1
u32 flags

u32 host_len
u8  host[host_len]

u32 port                ; 1..65535

u32 user_len
u8  user[user_len]

u32 pass_len
u8  pass[pass_len]

u32 db_len
u8  db[db_len]
```

### MysqlQueryReqV1 (EVMQ)

Produced by: `std.db.mysql.spec.query_req_v1(conn_id, sql_bytes, params_doc, flags)`

Encoding:

```
EVMQ: [69,86,77,81]
u32 version   = 1
u32 conn_id
u32 flags

u32 sql_len
u8  sql[sql_len]

u32 params_len
u8  params_doc[params_len]
```

**v1 limitation:** Params are carried for forward-compatibility, but you may choose to require `params_len==0` until prepared-statement binding lands.

### MysqlExecReqV1 (EVME)

Produced by: `std.db.mysql.spec.exec_req_v1(conn_id, sql_bytes, params_doc, flags)`

Same layout as MysqlQueryReqV1, magic = `EVME`.

### MysqlCloseReqV1 (EVMC)

Produced by: `std.db.mysql.spec.close_req_v1(conn_id)`

Encoding:

```
EVMC: [69,86,77,67]
u32 version   = 1
u32 conn_id
```

## Response format: DbRespV1 (EVDB)

Same `EVDB` envelope as all DB drivers:
- open OK payload is `conn_id_u32le`
- query OK payload is a DataModel doc representing a `{cols, rows}` table
- exec OK payload recommended `{rows_affected:number}`

## TLS + sandbox policy

MySQL client libraries typically control TLS via a dedicated option (for example `MYSQL_OPT_SSL_MODE`)
with modes like `REQUIRED`, `VERIFY_CA`, `VERIFY_IDENTITY`. citeturn1search3turn0search3

**v1 recommendation:**
- policy drives TLS requirements
- request cannot weaken policy
