# Evolang ext-db v1: Postgres + MySQL package layer (delta)

This bundle fills the gaps after the SQLite-first path:

- Adds **std.db.pg** + **std.db.mysql** modules with:
  - deterministic **bytes encodings** for open/query/exec/close requests (parallel to std.db.sqlite)
  - `caps_pack_v1` / `caps_default_v1` (same EVDC encoding)
  - ergonomic wrappers that call the expected OS builtins (`os.db.pg.*`, `os.db.mysql.*`)
- Adds **std.db.pg.pool** + **std.db.mysql.pool** (built on std.db.pool from the pool-delta bundle).
- Adds **run-os-sandboxed smoke suites** + smoke programs that:
  - connect to localhost Postgres/MySQL (expected to be provided by the developer, e.g. docker-compose)
  - run a tiny query
  - assert the returned **DataModel doc bytes match exactly**.

IMPORTANT: Like the earlier SQLite bundle, this bundle **does not implement the native runner/builtin adapters**.
It only provides the package layer (spec pack/unpack + helpers + smokes).
Your toolchain must provide:

- `os.db.pg.{open_v1,query_v1,exec_v1,close_v1}`
- `os.db.mysql.{open_v1,query_v1,exec_v1,close_v1}`

matching the request/response encodings pinned in docs.

Apply by copying these paths into your repo root, overwriting existing placeholders:
- packages/evolang-ext-db-postgres/0.1.0/...
- packages/evolang-ext-db-mysql/0.1.0/...
- tests/external_os/db_pg_smoke_ok/...
- tests/external_os/db_mysql_smoke_ok/...
- benchmarks/run-os-sandboxed/db-pg-smoke.json
- benchmarks/run-os-sandboxed/db-mysql-smoke.json
- schemas/run-os-policy.db.pg.example.json
- schemas/run-os-policy.db.mysql.example.json
- docs/db/postgres-v1.md
- docs/db/mysql-v1.md
