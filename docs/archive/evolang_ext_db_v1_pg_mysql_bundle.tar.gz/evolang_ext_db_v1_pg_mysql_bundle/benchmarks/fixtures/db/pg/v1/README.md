# Postgres fixture (dev)

Bring up a local Postgres for the smoke suite:

```bash
cd benchmarks/fixtures/db/pg/v1
docker compose up -d
```

It will expose:
- host: localhost
- port: 5432
- db: evo
- user: evo
- pass: evo
