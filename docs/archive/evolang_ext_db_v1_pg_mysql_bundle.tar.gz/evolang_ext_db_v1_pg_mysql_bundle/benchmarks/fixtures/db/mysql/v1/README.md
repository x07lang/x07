# MySQL fixture (dev)

Bring up a local MySQL for the smoke suite:

```bash
cd benchmarks/fixtures/db/mysql/v1
docker compose up -d
```

It will expose:
- host: localhost
- port: 3306
- db: evo
- user: evo
- pass: evo
