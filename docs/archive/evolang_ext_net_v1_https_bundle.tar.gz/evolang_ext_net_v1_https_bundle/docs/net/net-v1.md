# Net v1 (run-os* worlds)

This document is **normative** for the external networking package **`evolang:ext-net@0.1.0`**.

It defines:

- the **bytes encodings** for network requests/capabilities/results,
- the **minimum OS builtins** required (run-os / run-os-sandboxed only),
- the **sandbox policy model** for outbound/servers/TLS.

> Scope note:
> - `solve-*` worlds remain deterministic and **must not** expose OS networking.
> - Networking exists only in **standalone OS worlds** (`run-os`, `run-os-sandboxed`).

---

## Goals (LLM-first)

- **Small** surface area: agents can reliably call a few functions.
- **Explicit bytes contracts**: no “guessing” how to encode a request or parse a result.
- **Policy-first**: sandbox rules are enforced centrally by `run-os-sandboxed`.
- **Composable tiers**:
  - raw TCP streams (client + server),
  - DNS lookup,
  - HTTP(S) client (HTTPS required in v1).

HTTPS requirement rationale:
- Most real-world endpoints require TLS.
- Implementations typically rely on a TLS backend rather than re-implementing TLS in the language runtime. For example, curl/libcurl supports HTTPS by building against a TLS library (OpenSSL, Schannel, Secure Transport, rustls, etc.). citeturn0search16

---

## OS builtin surface (required)

These builtins exist only when compiling for `run-os*` targets. Any attempt to use them in `solve-*` must be a **hard compile error**.

### DNS

- `os.net.dns_lookup_v1(name_bytes, caps_bytes) -> bytes`
  - returns `ResultDoc<NetIpListV1, NetErrV1>`

### TCP client + server

- `os.net.tcp_connect_v1(addr_bytes, caps_bytes) -> bytes`
  - returns `ResultDoc<StreamHandleV1, NetErrV1>`

- `os.net.tcp_listen_v1(addr_bytes, caps_bytes) -> bytes`
  - returns `ResultDoc<ListenerHandleV1, NetErrV1>`

- `os.net.tcp_accept_v1(listener_handle_i32, caps_bytes) -> bytes`
  - returns `ResultDoc<StreamHandleV1, NetErrV1>`

### Stream I/O

- `os.net.stream_read_v1(stream_handle_i32, max_bytes_i32, caps_bytes) -> bytes`
  - returns `ResultDoc<BytesBlobV1, NetErrV1>`
  - reads up to `max_bytes_i32` bytes (may return fewer)
  - returns empty bytes on EOF

- `os.net.stream_write_v1(stream_handle_i32, data_bytes, caps_bytes) -> bytes`
  - returns `ResultDoc<U32V1, NetErrV1>` where ok payload is `written_u32`

- `os.net.stream_close_v1(stream_handle_i32) -> bytes`
  - returns `ResultDoc<UnitV1, NetErrV1>`

### HTTP(S) client (HTTPS required)

- `os.net.http_fetch_v1(req_bytes) -> bytes`
  - returns `ResultDoc<HttpRespV1, NetErrV1>`
  - MUST support `https://...` URLs and validate certificates by default.
  - MAY be implemented using libcurl (recommended for portability), which supports multiple TLS backends across platforms. citeturn0search16turn0search20

---

## Common result wrapper

All OS net builtins return a `ResultDoc`:

### `ResultDoc<T, NetErrV1>` encoding

- `tag_u8`:
  - `0` = Err
  - `1` = Ok

Then:

- If `tag == 0`:
  - `code_u32_le` (NetErrCode)
  - `detail_len_u32_le`
  - `detail_bytes[detail_len]` (UTF-8 diagnostic, optional; may be empty)

- If `tag == 1`:
  - `payload_len_u32_le`
  - `payload_bytes[payload_len]`

This keeps parsing uniform and agent-friendly.

---

## Encodings

All integer fields are **unsigned little-endian** unless stated otherwise.

### NetAddrV1

Used for `tcp_connect_v1` and `tcp_listen_v1`.

Encoding:

- `addr_tag_u8`:
  - `1` = IPv4
  - `2` = IPv6
  - `3` = DNS name

- `port_u16_le`
- `reserved_u16_le` (must be 0)

Then:

- If IPv4: `ip[4]`
- If IPv6: `ip[16]`
- If DNS: `name_len_u32_le` + `name_bytes[name_len]` (UTF-8, lowercasing recommended)

### NetCapsV1

Used for DNS/TCP/streams (and indirectly by HTTP via `HttpReqV1`).

Fixed size = 24 bytes:

1. `connect_timeout_ms_u32_le`
2. `io_timeout_ms_u32_le`
3. `max_read_bytes_u32_le` (per read call cap; 0 = default)
4. `max_write_bytes_u32_le` (per write call cap; 0 = default)
5. `max_total_bytes_u32_le` (aggregate cap for the operation; 0 = default)
6. `flags_u32_le`

Flags:

- bit 0: `NETCAP_TLS_INSECURE_OK`
  - only applies to HTTPS in `http_fetch_v1`
  - if set, TLS verification MAY be disabled **only** when policy allows it (see policy)

### StreamHandleV1 payload

`StreamHandleV1` ok payload is:

- `handle_i32_le` (signed i32 handle)

### ListenerHandleV1 payload

- `handle_i32_le`

### NetIpListV1 payload

Returned by `dns_lookup_v1`.

- `count_u32_le`
- for each:
  - `ip_tag_u8` (1=IPv4, 2=IPv6)
  - `reserved_u8[3]` (0)
  - `ip_bytes` (4 or 16)

### BytesBlobV1 payload

- `len_u32_le`
- `bytes[len]`

### U32V1 payload

- `value_u32_le`

### UnitV1 payload

- length = 0

---

## HTTP request/response (v1)

### HttpReqV1

`http_fetch_v1(req_bytes)` consumes `HttpReqV1`.

Encoding:

- `version_u8` (must be `1`)
- `method_u8`:
  - `1` = GET
  - `2` = POST
  - `3` = PUT
  - `4` = DELETE

- `reserved_u16_le` (0)
- `url_len_u32_le`
- `url_bytes[url_len]` (UTF-8; MUST support `https://...`)

- `header_count_u32_le`
- repeated `header_count` times:
  - `k_len_u32_le` + `k_bytes`
  - `v_len_u32_le` + `v_bytes`

- `body_len_u32_le`
- `body_bytes[body_len]`

- `caps_bytes_len_u32_le` (must be 24)
- `NetCapsV1` bytes (24 bytes)

### HttpRespV1

Ok payload for `http_fetch_v1`:

- `version_u8` (must be `1`)
- `reserved_u8[3]` (0)
- `status_u32_le` (e.g. 200)
- `header_count_u32_le`
- repeated headers:
  - `k_len_u32_le` + `k_bytes`
  - `v_len_u32_le` + `v_bytes`
- `body_len_u32_le`
- `body_bytes[body_len]`

Header ordering:
- Implementations SHOULD preserve the received header order if available.
- `std.net.http` will also provide helpers to search headers deterministically (case-insensitive ASCII match).

### HTTP/TLS verification rules

- Default: verify certificates (system trust store) and hostname/SNI.
- If `NETCAP_TLS_INSECURE_OK` is set:
  - `run-os`: MAY skip verification.
  - `run-os-sandboxed`: MAY skip verification only if `policy.network.tls.allow_insecure == true`.

Implementation note:
- Many TLS stacks exist (OpenSSL, rustls, Schannel/Secure Transport, etc.). curl/libcurl supports using different TLS backends depending on platform build. citeturn0search16turn0search20
- Rustls is a memory-safe TLS implementation in Rust; it supports building TLS clients and servers. citeturn0search17turn0search21
- OpenSSL 3.0+ uses an Apache-2.0 license, which may be relevant if you choose OpenSSL as the TLS backend. citeturn0search18

---

## Sandbox policy model (run-os-sandboxed)

Networking must be **explicitly enabled** and allowlisted.

Policy MUST support both DNS name and CIDR allowlists:

- DNS:
  - exact host allowlist (`dns_exact`)
  - suffix allowlist (`dns_suffix`)
- CIDR:
  - allowlist of IPv4/IPv6 CIDRs

### Enforcement rules (normative)

Outbound connect by IP:
- Allowed if a policy rule matches the IP and port.

Outbound connect by DNS name:
- Allowed only if:
  1) a rule matches the DNS name (`dns_exact` or `dns_suffix`) AND
  2) after resolution, at least one resolved IP matches `cidr` rules AND
  3) the chosen IP for the connection is one of the allowed resolved IPs
- This dual check mitigates DNS rebinding-style issues.

Listening (servers):
- Allowed only if `policy.network.allow_listen == true` AND a rule matches the bind address + port.

---

## NetErr codes (v1)

These are **stable** error codes (u32).

- 1  `NET_ERR_POLICY_DENIED`
- 2  `NET_ERR_INVALID_REQ`
- 3  `NET_ERR_DNS_FAILED`
- 4  `NET_ERR_CONNECT_FAILED`
- 5  `NET_ERR_LISTEN_FAILED`
- 6  `NET_ERR_ACCEPT_FAILED`
- 7  `NET_ERR_IO_FAILED`
- 8  `NET_ERR_TIMEOUT`
- 9  `NET_ERR_TLS_FAILED`
- 10 `NET_ERR_HTTP_FAILED`
- 11 `NET_ERR_HTTP_BODY_LIMIT`

`detail_bytes` may contain a short UTF-8 explanation; it is non-normative and should not be parsed for logic.

---

## Recommended stdlib wrappers (agent-friendly)

The external package provides these stable wrappers:

- `std.net.codec.*` – build/parse NetAddrV1 and NetCapsV1
- `std.net.dns.lookup_v1(name, caps) -> result_bytes` (ResultDoc)
- `std.net.tcp.connect_v1(addr, caps) -> result_bytes`
- `std.net.tcp.listen_v1(addr, caps) -> result_bytes`
- `std.net.tcp.accept_v1(listener_handle, caps) -> result_bytes`
- `std.net.stream.read_v1(handle, max, caps) -> result_bytes`
- `std.net.stream.write_v1(handle, data, caps) -> result_bytes`
- `std.net.http.get_v1(url, caps) -> result_bytes`
- `std.net.http.post_v1(url, headers, body, caps) -> result_bytes`

End-users should rely on `std.net.*` wrappers; OS builtins remain low-level.

