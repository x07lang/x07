# MySQL adapter (db/mysql v1)

Status: design pinned (v1)

## Connector choice

For a MySQL-protocol C client library, consider MariaDB Connector/C for portability + TLS support documentation.

## Execution model

- Use prepared statements + parameter binding.
- Convert results into DataModel docs the same way as other adapters.

## TLS policy

- Require TLS and verification (policy-controlled).
- Disallow plaintext connections in run-os-sandboxed by default.
