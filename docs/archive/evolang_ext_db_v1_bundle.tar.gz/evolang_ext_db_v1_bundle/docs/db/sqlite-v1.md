# SQLite adapter (db/sqlite v1)

Status: design pinned (v1)

## Implementation sketch

- Use `sqlite3_open_v2` (or equivalent) to open the database.
- Use prepared statements:
  - `sqlite3_prepare_v2`
  - `sqlite3_bind_*`
  - `sqlite3_step`
  - `sqlite3_finalize`

- Convert row values:
  - NULL -> DataModel null
  - INTEGER -> DataModel number (decimal ASCII)
  - REAL -> DataModel number (decimal ASCII; no promise of exact float roundtrip)
  - TEXT -> DataModel string (UTF-8)
  - BLOB -> DataModel string with `b64:` prefix and base64url payload (v1 convention)

SQLite is public domain; embedding/linking is straightforward.

## Policy

- sqlite is file-backed:
  - enforce allowlisted paths (no absolute, no `..`)
  - allow/deny create and in-memory DB per policy
