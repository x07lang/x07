This bundle adds the DB v1 external package skeletons + docs + policy schema fragment + smoke suite shapes.

Apply:
- copy `docs/db/*` into your repo
- merge schema: apply `schemas/run-os-policy.db.patch.json` to your existing `schemas/run-os-policy.schema.json` (or manually merge `schemas/run-os-policy.db.section.json` under `properties.db`)
- copy packages under `packages/`
- copy benchmarks suites + fixtures under `benchmarks/`

Notes:
- The `std.db` facade in this bundle is stubbed (returns NOT_IMPLEMENTED) until you add native adapters/builtins.
- The `std.db.spec` envelope and `std.db.params` builders are real and should compile once imported.
