// Tiny cross-platform stub server helper for Evolang net smoke tests.
//
// Modes:
// - tcp-echo: accept 1 connection, echo all received bytes, exit.
// - http: accept 1 connection, respond with 200 + body, exit.
// - https: accept 1 TLS connection (self-signed localhost), respond with 200 + body, exit.
//
// This is NOT a production server; it exists purely to validate run-os networking adapters.

use std::env;
use std::fs;
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};

fn usage() -> ! {
    eprintln!("usage: evolang-net-stub-server --mode <tcp-echo|http|https> [--bind IP] [--port N] [--port-file PATH] [--body TEXT]");
    std::process::exit(2);
}

fn arg_value(args: &[String], key: &str) -> Option<String> {
    let mut i = 0;
    while i < args.len() {
        if args[i] == key {
            if i + 1 >= args.len() { return None; }
            return Some(args[i + 1].clone());
        }
        i += 1;
    }
    None
}

fn has_flag(args: &[String], key: &str) -> bool {
    args.iter().any(|a| a == key)
}

fn write_port_file(port_file: &Option<String>, port: u16) -> std::io::Result<()> {
    if let Some(p) = port_file {
        fs::write(p, format!("{}\n", port))?;
    }
    Ok(())
}

fn read_http_req(stream: &mut dyn Read, cap: usize) -> std::io::Result<Vec<u8>> {
    let mut buf = vec![0u8; cap];
    let mut out = Vec::new();
    loop {
        let n = stream.read(&mut buf)?;
        if n == 0 { break; }
        out.extend_from_slice(&buf[..n]);
        if out.windows(4).any(|w| w == b"\r\n\r\n") { break; }
        if out.len() > cap { break; }
    }
    Ok(out)
}

fn write_http_resp(stream: &mut dyn Write, body: &[u8]) -> std::io::Result<()> {
    let hdr = format!(
        "HTTP/1.1 200 OK\r\nContent-Length: {}\r\nContent-Type: text/plain\r\nConnection: close\r\n\r\n",
        body.len()
    );
    stream.write_all(hdr.as_bytes())?;
    stream.write_all(body)?;
    Ok(())
}

fn serve_tcp_echo(mut s: TcpStream) -> std::io::Result<()> {
    let mut buf = [0u8; 8192];
    let mut data = Vec::new();
    loop {
        let n = s.read(&mut buf)?;
        if n == 0 { break; }
        data.extend_from_slice(&buf[..n]);
        if data.len() > 1_000_000 { break; } // avoid unbounded memory
    }
    s.write_all(&data)?;
    Ok(())
}

fn serve_http(mut s: TcpStream, body: &[u8]) -> std::io::Result<()> {
    let _req = read_http_req(&mut s, 64 * 1024)?;
    write_http_resp(&mut s, body)?;
    Ok(())
}

fn serve_https(s: TcpStream, body: &[u8]) -> std::io::Result<()> {
    use rustls::pki_types::{CertificateDer, PrivateKeyDer};
    use rustls::{ServerConfig, ServerConnection, StreamOwned};

    // Load embedded test cert/key.
    let cert_pem = include_bytes!("../cert.pem");
    let key_pem = include_bytes!("../key.pem");

    let mut cert_reader = std::io::Cursor::new(cert_pem);
    let certs: Vec<CertificateDer<'static>> = rustls_pemfile::certs(&mut cert_reader)
        .collect::<Result<_, _>>()
        .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, format!("cert parse: {e}")))?;

    let mut key_reader = std::io::Cursor::new(key_pem);
    let key = rustls_pemfile::private_key(&mut key_reader)
        .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, format!("key parse: {e}")))?
        .ok_or_else(|| std::io::Error::new(std::io::ErrorKind::InvalidData, "missing key"))?;

    let key: PrivateKeyDer<'static> = key.into();

    let cfg = ServerConfig::builder()
        .with_no_client_auth()
        .with_single_cert(certs, key)
        .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, format!("cfg: {e}")))?;

    let conn = ServerConnection::new(std::sync::Arc::new(cfg))
        .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, format!("conn: {e}")))?;

    let mut tls = StreamOwned::new(conn, s);
    let _req = read_http_req(&mut tls, 64 * 1024)?;
    write_http_resp(&mut tls, body)?;
    Ok(())
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let mode = arg_value(&args, "--mode").unwrap_or_else(|| usage());
    let bind_ip = arg_value(&args, "--bind").unwrap_or_else(|| "127.0.0.1".to_string());
    let port: u16 = arg_value(&args, "--port").unwrap_or_else(|| "0".to_string()).parse().unwrap_or(0);
    let port_file = arg_value(&args, "--port-file");
    let body = arg_value(&args, "--body").unwrap_or_else(|| "hello".to_string()).into_bytes();

    let listener = TcpListener::bind(format!("{}:{}", bind_ip, port))
        .unwrap_or_else(|e| { eprintln!("bind failed: {e}"); std::process::exit(1); });

    let local_port = listener.local_addr().ok().map(|a| a.port()).unwrap_or(port);
    if let Err(e) = write_port_file(&port_file, local_port) {
        eprintln!("port-file write failed: {e}");
        std::process::exit(1);
    }

    // accept exactly one
    let (stream, _addr) = listener.accept()
        .unwrap_or_else(|e| { eprintln!("accept failed: {e}"); std::process::exit(1); });

    let res = match mode.as_str() {
        "tcp-echo" => serve_tcp_echo(stream),
        "http" => serve_http(stream, &body),
        "https" => serve_https(stream, &body),
        _ => { usage(); }
    };

    if let Err(e) = res {
        eprintln!("serve failed: {e}");
        std::process::exit(1);
    }
}
