# Native SQLite adapter integration notes (os.db.sqlite.*)

This bundle assumes the following OS builtins exist:

- `os.db.sqlite.open_v1(req: bytes, caps: bytes) -> bytes`
- `os.db.sqlite.query_v1(req: bytes, caps: bytes) -> bytes`
- `os.db.sqlite.exec_v1(req: bytes, caps: bytes) -> bytes`
- `os.db.sqlite.close_v1(req: bytes, caps: bytes) -> bytes`

The stdlib wrapper (`std.db.sqlite`) already packs requests and expects responses using:

- `docs/db/sqlite-v1.md` (EVDC/EVSO/EVSQ/EVSE/EVSC and EVDB envelope)
- `ext.data_model` canonical encoding for the query payload doc

## Recommended implementation approach

1. **Parse policy** (run-os & run-os-sandboxed):
   - `db.enabled`
   - `db.drivers.sqlite`
   - `db.sqlite.allow_paths` allowlist
   - plus any global limits you want (max live conns, query timeout, max bytes, etc.)

2. **Enforce path allowlist** in `open_v1`:
   - The `sqlite_policy_deny_path` smoke expects opening `secrets.db` to fail with:
     - `DB_ERR_POLICY_DENIED = 53249` (0xD001)

3. **Connection table**
   - `open_v1` returns a `conn_id` (u32) in the ok payload (4 bytes, little-endian).
   - `close_v1` removes the handle.

4. **Query mapping**
   - For each row, build DataModel values and then encode the canonical doc:
     - map keys: `cols`, `rows`
     - `cols`: seq of string column names
     - `rows`: seq of seqs of values

## Reference code

See `REFERENCE_os_db_sqlite.c` for a self-contained reference implementation that:
- parses requests
- calls sqlite3
- builds an EVDB response
- builds a canonical DataModel doc payload

It is not wired into any specific Evolang runtime; adapt the allocation and error plumbing to your toolchain.

