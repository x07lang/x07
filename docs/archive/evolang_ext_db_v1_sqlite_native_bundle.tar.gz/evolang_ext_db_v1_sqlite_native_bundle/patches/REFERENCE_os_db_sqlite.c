/*
REFERENCE_os_db_sqlite.c

This is a *reference* implementation for the Evolang OS SQLite builtins described in:

- docs/db/sqlite-v1.md

It is written to be easy to read and port, not to match your exact runtime ABI.

You will need to adapt:
- allocation (malloc/free vs runtime arena)
- how bytes are represented (ptr+len vs custom)
- how errors are surfaced (EVDB envelope)

This file is intentionally self-contained and uses sqlite3 directly.
*/

#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "sqlite3.h"

/* ---- Error codes (v1 suggested) ---- */
#define DB_ERR_POLICY_DENIED  ((uint32_t)53249) /* 0xD001 */
#define DB_ERR_BAD_REQ        ((uint32_t)53250) /* 0xD002 */
#define DB_ERR_SQLITE_OPEN    ((uint32_t)53504) /* 0xD100 */
#define DB_ERR_SQLITE_PREP    ((uint32_t)53505) /* 0xD101 */
#define DB_ERR_SQLITE_STEP    ((uint32_t)53506) /* 0xD102 */
#define DB_ERR_TOO_LARGE      ((uint32_t)53760) /* 0xD200 */

/* ---- Little-endian helpers ---- */
static uint32_t rd_u32_le(const uint8_t* p) {
  return ((uint32_t)p[0]) |
         ((uint32_t)p[1] << 8) |
         ((uint32_t)p[2] << 16) |
         ((uint32_t)p[3] << 24);
}
static void wr_u32_le(uint8_t* p, uint32_t x) {
  p[0] = (uint8_t)(x & 0xFF);
  p[1] = (uint8_t)((x >> 8) & 0xFF);
  p[2] = (uint8_t)((x >> 16) & 0xFF);
  p[3] = (uint8_t)((x >> 24) & 0xFF);
}

/* ---- EVDB envelope builder ----
   layout:
   0..4   "EVDB"
   4..8   version u32 (1)
   8..12  tag u32 (0 err, 1 ok)
   12..16 err_code u32 (0 if ok)
   16..20 payload_len u32
   20..   payload bytes
*/
static uint8_t* evdb_build(uint32_t tag, uint32_t err_code,
                           const uint8_t* payload, uint32_t payload_len,
                           uint32_t* out_len) {
  uint32_t total = 20u + payload_len;
  uint8_t* out = (uint8_t*)malloc(total);
  if (!out) return NULL;
  out[0]='E'; out[1]='V'; out[2]='D'; out[3]='B';
  wr_u32_le(out + 4, 1);
  wr_u32_le(out + 8, tag);
  wr_u32_le(out + 12, (tag==1) ? 0 : err_code);
  wr_u32_le(out + 16, payload_len);
  if (payload_len) memcpy(out + 20, payload, payload_len);
  *out_len = total;
  return out;
}

/* ---- Minimal DataModel encoder (canonical) ----
   This implements only what the smoke needs:
   - doc_ok(value)
   - value_map with entries blob
   - value_seq with elems blob
   - value_string (bytes)
   - value_number (ascii bytes)
   - value_null
   See docs/db/sqlite-v1.md and ext.data_model module for the full canonical format.
*/

static void dm_push_u8(uint8_t** buf, uint32_t* len, uint32_t* cap, uint8_t x) {
  if (*len + 1 > *cap) {
    uint32_t ncap = (*cap == 0) ? 256 : (*cap * 2);
    while (*len + 1 > ncap) ncap *= 2;
    *buf = (uint8_t*)realloc(*buf, ncap);
    *cap = ncap;
  }
  (*buf)[(*len)++] = x;
}

static void dm_push_u32le(uint8_t** buf, uint32_t* len, uint32_t* cap, uint32_t x) {
  dm_push_u8(buf,len,cap,(uint8_t)(x & 0xFF));
  dm_push_u8(buf,len,cap,(uint8_t)((x>>8) & 0xFF));
  dm_push_u8(buf,len,cap,(uint8_t)((x>>16) & 0xFF));
  dm_push_u8(buf,len,cap,(uint8_t)((x>>24) & 0xFF));
}

static void dm_push_mem(uint8_t** buf, uint32_t* len, uint32_t* cap, const uint8_t* p, uint32_t n) {
  for (uint32_t i=0;i<n;i++) dm_push_u8(buf,len,cap,p[i]);
}

/* Value tags (from the ext.data_model v1 design) */
#define DM_TAG_NULL   0
#define DM_TAG_BOOL   1
#define DM_TAG_NUMBER 2
#define DM_TAG_STRING 3
#define DM_TAG_MAP    4
#define DM_TAG_SEQ    5

static uint8_t* dm_value_null(uint32_t* out_len) {
  uint8_t* buf=NULL; uint32_t len=0, cap=0;
  dm_push_u32le(&buf,&len,&cap,DM_TAG_NULL);
  *out_len=len; return buf;
}

static uint8_t* dm_value_string(const uint8_t* bytes, uint32_t n, uint32_t* out_len) {
  uint8_t* buf=NULL; uint32_t len=0, cap=0;
  dm_push_u32le(&buf,&len,&cap,DM_TAG_STRING);
  dm_push_u32le(&buf,&len,&cap,n);
  dm_push_mem(&buf,&len,&cap,bytes,n);
  *out_len=len; return buf;
}

static uint8_t* dm_value_number_ascii(const uint8_t* bytes, uint32_t n, uint32_t* out_len) {
  uint8_t* buf=NULL; uint32_t len=0, cap=0;
  dm_push_u32le(&buf,&len,&cap,DM_TAG_NUMBER);
  dm_push_u32le(&buf,&len,&cap,n);
  dm_push_mem(&buf,&len,&cap,bytes,n);
  *out_len=len; return buf;
}

/* seq from elems blob: [tag=SEQ][len][elems...] */
static uint8_t* dm_value_seq_from_elems(const uint8_t* elems, uint32_t n, uint32_t* out_len) {
  uint8_t* buf=NULL; uint32_t len=0, cap=0;
  dm_push_u32le(&buf,&len,&cap,DM_TAG_SEQ);
  dm_push_u32le(&buf,&len,&cap,n);
  dm_push_mem(&buf,&len,&cap,elems,n);
  *out_len=len; return buf;
}

/* map from entries blob: [tag=MAP][len][entries...] */
static uint8_t* dm_value_map_from_entries(const uint8_t* entries, uint32_t n, uint32_t* out_len) {
  uint8_t* buf=NULL; uint32_t len=0, cap=0;
  dm_push_u32le(&buf,&len,&cap,DM_TAG_MAP);
  dm_push_u32le(&buf,&len,&cap,n);
  dm_push_mem(&buf,&len,&cap,entries,n);
  *out_len=len; return buf;
}

/* doc_ok(value): "EVDM" wrapper:
   For brevity this reference does not re-spec the full doc header.
   In your implementation, reuse ext.data_model.doc_ok and friends or copy its exact layout.
*/
static uint8_t* dm_doc_ok(const uint8_t* value, uint32_t value_len, uint32_t* out_len) {
  /* TODO: replace with the exact DataModel doc encoding used by ext.data_model in your tree. */
  (void)value; (void)value_len;
  *out_len = 0;
  return NULL;
}

/*
NOTE: The smoke test in this bundle constructs the *expected* doc using ext.data_model,
so the runtime must return the exact same canonical bytes.

In practice:
- call your existing ext.data_model builders from native code, OR
- port the full ext.data_model encoding into native code.

This reference file intentionally stops short of duplicating your entire DataModel module.
*/
