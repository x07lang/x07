# Evolang external DB bundle (SQLite native + byte-for-byte smoke)

This bundle extends the previous DB v1 scaffolding by adding:

- `std.db.sqlite` **stdlib wrapper** with concrete request packers:
  - `std.db.sqlite.spec.open_req_path_v1`
  - `std.db.sqlite.spec.query_req_v1`
  - `std.db.sqlite.spec.exec_req_v1`
  - `std.db.sqlite.spec.close_req_v1`
  - `std.db.sqlite.caps_default_v1`

- A **run-os-sandboxed smoke suite** that asserts a returned **DataModel doc payload** *byte-for-byte*.

## What this bundle does NOT include

The actual OS runtime implementation of the builtins is still required:

- `os.db.sqlite.open_v1(req: bytes, caps: bytes) -> bytes`
- `os.db.sqlite.query_v1(req: bytes, caps: bytes) -> bytes`
- `os.db.sqlite.exec_v1(req: bytes, caps: bytes) -> bytes`
- `os.db.sqlite.close_v1(req: bytes, caps: bytes) -> bytes`

See: `docs/db/sqlite-v1.md` for the pinned binary formats and DataModel mapping.

## Smoke suite

Suite file:

- `benchmarks/run-os-sandboxed/db-sqlite-smoke.json`

Cases:

1. **sqlite_query_items_dm_doc_bytes_match**
   - opens the fixture DB at `benchmarks/fixtures/db/sqlite/v1/app.db`
   - runs: `SELECT id,name,n,payload,note FROM items ORDER BY id;`
   - compares the returned DataModel doc payload **byte-for-byte** with an expected doc built using `ext.data_model` builders
   - prints `OK` on success

2. **sqlite_policy_deny_path**
   - attempts to open `secrets.db`
   - expects `DB_ERR_POLICY_DENIED = 53249`
   - prints `OK` on success

Policy file used by the suite:

- `schemas/run-os-policy.db.example.json`

## Files of interest

- `packages/evolang-ext-db-sqlite/0.1.0/modules/std/db/sqlite.evo.json`
- `tests/external_os/db_sqlite_smoke_ok/src/main.evo.json`
- `tests/external_os/db_sqlite_smoke_deny/src/main.evo.json`
- `docs/db/sqlite-v1.md`

## Toolchain integration

See `patches/INTEGRATION_os_db_sqlite.md`.
