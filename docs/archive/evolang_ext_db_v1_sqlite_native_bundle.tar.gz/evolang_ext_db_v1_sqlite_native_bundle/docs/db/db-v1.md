# DB v1 (external packages) — DataModel-native database access (run-os only)

Status: **Design pinned (v1)**  
Worlds: **run-os**, **run-os-sandboxed** (never available in solve-* worlds)

## Goals

- Provide SQLite, Postgres, MySQL access for Evolang **standalone** programs.
- Make results and parameters **DataModel-native** using `ext.data_model` (serde-like) so data flows cleanly between DB, JSON, CSV, YAML, etc.
- Make agent usage reliable:
  - no hand-written binary encodings
  - stable error codes + optional messages
  - small, consistent API (`std.db.*` facade)

## Packages

- `evolang:ext-db-core@0.1.0`
  - `std.db.spec` — pinned bytes envelopes (DbRespV1, DbOpenOkV1, etc.)
  - `std.db.params` — DataModel params builders/validators
  - `std.db.dm` — DataModel helpers for result docs
  - `std.db` — driver-neutral facade

- `evolang:ext-db-sqlite@0.1.0` — SQLite adapter
- `evolang:ext-db-postgres@0.1.0` — Postgres adapter (libpq)
- `evolang:ext-db-mysql@0.1.0` — MySQL adapter (MariaDB Connector/C recommended)

SQLite is public domain; embedding/linking is straightforward.  
Postgres uses libpq (parameterized execution via `PQexecParams`).  
MySQL uses a C connector; MariaDB Connector/C documents TLS and options.  
(See driver docs for details and policy requirements.)

## DataModel compatibility

### Parameters (DbParamsV1)

DB parameters are a **DataModel doc** whose root is a **sequence** of *scalar* values:

- null
- bool
- number (decimal ASCII bytes payload)
- string (UTF-8 bytes payload)
- (optional) blob represented as string with prefix `b64:` + base64url payload (v1 convention)

No nested seq/map in params v1 (reject deterministically).

### Query results (DbRowsDocV1)

`std.db.query_v1` returns a DbRespV1 whose OK payload is a DataModel doc with this canonical map shape:

- `rows` : seq<map<string, scalar|null>>
- `cols` : seq<string>     (column names in driver order)
- `types`: seq<string>     (driver type names; optional but recommended)
- `rows_affected`: number  (present for exec/dml; for select can be omitted or 0)
- `last_insert_id`: number (optional; sqlite/mysql)

Row maps MUST have deterministic key ordering (keys sorted lexicographically) so downstream lookups are stable and fast.

## DbRespV1 envelope (EVDB/1)

All DB operations return a `bytes` envelope (agent-friendly; no typed handles required).

Binary layout (little-endian u32):

- magic 4 bytes = "EVDB"
- version u32 = 1
- tag u32: 1 = OK, 0 = ERR
- op  u32: operation code (see `std.db.spec`)
- payload:
  - OK:  u32 ok_len + ok_bytes[ok_len]
  - ERR: u32 err_code + u32 msg_len + msg_bytes[msg_len]

OK payload by op:

- OPEN (op=1): `DbOpenOkV1` = u32 conn_handle
- EXEC (op=2): `DbExecOkV1` = DataModel doc (map with rows_affected, last_insert_id)
- QUERY(op=3): `DbQueryOkV1` = DataModel doc (DbRowsDocV1)

## Policy (run-os-sandboxed)

Add a `db` section to `schemas/run-os-policy.schema.json` and enforce:

- enable/disable per driver (sqlite/pg/mysql)
- allowlist sqlite file paths
- allowlist db hosts by DNS and CIDR + ports
- require TLS+verification for pg/mysql
- caps: max_live_conns, max_queries, timeouts, max rows, max response bytes

See `schemas/run-os-policy.db.section.json` and the example policy files in this bundle.

## Driver implementation notes (informative)

SQLite: use prepared statements (`sqlite3_prepare_v2`), bind (`sqlite3_bind_*`), step (`sqlite3_step`), finalize (`sqlite3_finalize`).  
Postgres: use `PQexecParams` with `$1..$n` placeholders; enforce `sslmode=verify-full`/`verify-ca`.  
MySQL: use prepared statements + TLS enforcement through connector options.

(References: SQLite C API docs; Postgres libpq exec+SSL docs; MariaDB Connector/C docs.)

