# Postgres adapter (db/postgres v1)

Status: design pinned (v1)

## Execution model

- Use libpq.
- Use parameterized execution (`PQexecParams`) with placeholders `$1`, `$2`, ...
  - pass parameter bytes separately (no manual SQL string interpolation)

## TLS policy

- Require TLS and server verification.
- Default secure config is `sslmode=verify-full` (or `verify-ca` if you must) plus root cert configuration.

## Type mapping (v1)

- Treat `NULL` as DataModel null.
- Treat boolean as DataModel bool.
- Treat numeric types as DataModel number (decimal ASCII).
- Treat text as DataModel string (UTF-8).
- Treat bytea as DataModel string with `b64:` prefix (v1 convention).
