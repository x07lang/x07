# SQLite adapter (db/sqlite v1)

This document pins the **v1** contract for the OS-backed SQLite adapter used by `std.db.sqlite`.

The design goal is:
- **Always-green**: SQLite has no external service dependency; it is file-based.
- **Deterministic & bytes-first**: requests and responses are binary specblobs, and `query` returns a canonical **DataModel doc** payload so callers can do byte-for-byte assertions.

## Status

- **stdlib** (`std.db.sqlite`) is implemented in this bundle.
- **native implementation** is expected as OS builtins:
  - `os.db.sqlite.open_v1(req: bytes, caps: bytes) -> bytes`
  - `os.db.sqlite.query_v1(req: bytes, caps: bytes) -> bytes`
  - `os.db.sqlite.exec_v1(req: bytes, caps: bytes) -> bytes`
  - `os.db.sqlite.close_v1(req: bytes, caps: bytes) -> bytes`

If these builtins are not present, the stdlib wrapper will link but calls will fail at compile-time / link-time depending on your toolchain.

## Binary formats

### DbCapsV1 (EVDC)

Used to pass per-call limits. The runtime should enforce `min(policy, caps)`.

`DbCapsV1` is a fixed 20-byte blob:

```
offset  size  field
0       4     magic = 'E''V''D''C'
4       4     version = u32_le(1)
8       4     connect_timeout_ms = u32_le
12      4     query_timeout_ms   = u32_le
16      4     max_rows           = u32_le
20      4     max_resp_bytes     = u32_le
```

**Default semantics**: in v1, a field value of `0` means “use policy default”.

The stdlib helper `std.db.sqlite.caps_default_v1()` returns `EVDC` with all-zero limits.

### SqliteOpenReqV1 (EVSO)

```
offset  size  field
0       4     magic = 'E''V''S''O'
4       4     version = u32_le(1)
8       4     flags = u32_le
12      4     path_len = u32_le
16      N     path_bytes
```

Flags (u32 bitset):
- bit 0: open_readonly
- bit 1: open_create
- all other bits must be 0 in v1

### SqliteQueryReqV1 (EVSQ)

```
offset  size  field
0       4     magic = 'E''V''S''Q'
4       4     version = u32_le(1)
8       4     conn_id = u32_le
12      4     flags   = u32_le
16      4     sql_len = u32_le
20      N     sql_bytes (UTF-8 recommended, but treated as bytes)
20+N    4     params_doc_len = u32_le
24+N    M     params_doc_bytes (DataModel doc; v1 may ignore)
```

Flags:
- bit 0: include_colnames (must be 1 in v1; runtime may ignore and always include)

Params:
- v1 supports **empty params** only (the smoke test uses `std.db.params.empty_v1()`).
- Future: bind positional params from a DataModel seq.

### SqliteExecReqV1 (EVSE)

Same layout as `EVSQ`, but magic is `EVSE`.

### SqliteCloseReqV1 (EVSC)

```
offset  size  field
0       4     magic = 'E''V''S''C'
4       4     version = u32_le(1)
8       4     conn_id = u32_le
```

### DbRespV1 (EVDB)

Responses use the v1 envelope defined in `docs/db/db-v1.md`:

- magic `EVDB`
- version `1`
- tag `0` = err, `1` = ok
- err_code u32_le (0 when ok)
- payload_len u32_le
- payload bytes

## Query result payload

For v1, `query` returns an **ok** response whose payload is a **DataModel doc** (encoded using `ext.data_model` canonical rules).

The doc body is a map with two keys:

- **"cols"** → sequence of column names (strings, bytes)
- **"rows"** → sequence of rows, each row is a sequence of values

Canonical key order is byte-lexicographic, so "cols" comes before "rows".

### Value mapping

For each SQLite column value:

- `NULL` → DataModel null
- `INTEGER` → DataModel number (decimal ASCII bytes, e.g. `"42"`)
- `REAL` → DataModel number (decimal ASCII; v1 may use SQLite's text form)
- `TEXT` → DataModel string (raw UTF-8 bytes)
- `BLOB` → DataModel string (raw bytes)

Notes:
- DataModel “string” is bytes; it is not required to be valid UTF‑8.
- v1 does not attempt to tag or distinguish TEXT vs BLOB beyond this mapping.

## Policy

The OS runtime must enforce allowlists from `run-os-policy`:

Example policy file: `schemas/run-os-policy.db.example.json`

Minimum requirements:
- `db.enabled = true`
- `db.drivers.sqlite = true`
- `db.sqlite.allow_paths` is a non-empty allowlist of database file paths

The smoke suite includes a negative test that attempts to open `secrets.db` and expects a **policy denied** error.

## Error codes (suggested)

These are **suggested** stable codes for v1:

- `DB_ERR_POLICY_DENIED = 53249` (0xD001)
- `DB_ERR_BAD_REQ       = 53250` (0xD002)
- `DB_ERR_SQLITE_OPEN   = 53504` (0xD100)
- `DB_ERR_SQLITE_PREP   = 53505` (0xD101)
- `DB_ERR_SQLITE_STEP   = 53506` (0xD102)
- `DB_ERR_TOO_LARGE     = 53760` (0xD200)

The smoke suite relies on `DB_ERR_POLICY_DENIED` exactly.
