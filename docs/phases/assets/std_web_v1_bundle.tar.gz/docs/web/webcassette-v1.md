# WebCassetteV1 (EVWC) — deterministic fixture replay format

This document pins the deterministic cassette format used by `std.web`.

## Encoding

Magic: ASCII `EVWC`

All integers are little-endian.

```
offset  size  field
0       4     magic = "EVWC"
4       1     version = 1
5       1     flags_u8 (must be 0 in v1)
6       2     reserved_u16 (must be 0)
8       4     req_len_u32
12      N     req_bytes (HttpReqV1 / EVRQ)
12+N    4     resp_len_u32
...     M     resp_bytes (HttpRespV1 / EVRS)
```

## Contract

- v1 MUST use `flags=0`.
- The cassette is purely a container; `req_bytes` and `resp_bytes` must each be valid v1 encodings.

## Helper functions

`std.web.cassette` provides:
- `pack_v1(req, resp) -> bytes`
- `req_v1(evwc_blob) -> bytes` (extract request bytes)
- `resp_v1(evwc_blob) -> bytes` (extract expected response bytes)

The smoke suites in this bundle validate this format end-to-end.
