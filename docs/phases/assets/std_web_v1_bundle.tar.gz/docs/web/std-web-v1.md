# std.web v1 — Agent-first web core (starter)

This document defines **std.web v1** as a *pure* HTTP “application core” plus *adapters*.

The intent is:
- **Apps are pure**: `handle(req_bytes) -> resp_bytes`.
- **Adapters are separate**: OS server adapters (run-os*) translate real HTTP to/from the `HttpReqV1/HttpRespV1` binary contracts.
- **Testing is cassette-first**: deterministic request/response replays use `WebCassetteV1` bytes (EVWC).

This starter bundle ships:
- `std.web.http.spec` — `HttpReqV1` + `HttpRespV1` pack/unpack helpers
- `std.web.http.headers` — minimal `HeadersTableV1` helpers (EVHT empty)
- `std.web.cassette` — `WebCassetteV1` helpers
- `std.web.router` — tiny deterministic router helper
- `std.web.response` — response helpers (thin wrappers around `std.web.http.spec`)
- smoke programs + smoke suites

## Architectural contract for agent-built web apps

**Canonical app shape (pure):**
- Module: `main`
- Exported function: `solve` (solve-* worlds) or `main.handle_v1` (adapter entry)
- Signature: `(defn main.handle_v1 ((req bytes)) bytes ...)`
- Semantics: MUST be pure (no OS I/O, no randomness); deterministic for the same input bytes.

**Adapters (run-os / run-os-sandboxed):**
- Translate from real HTTP to `HttpReqV1`.
- Call `main.handle_v1(req)`.
- Translate `HttpRespV1` back to real HTTP response bytes.

> This is the same “ports/adapters” (hexagonal) decomposition: your core logic is deterministic and the outside world is swappable.

## v1 binary contracts

This starter uses compact binary contracts instead of raw HTTP text. Agents never hand-roll offsets; they call helper functions.

- `HeadersTableV1` (EVHT): see `docs/web/webcassette-v1.md` for EVWC and see `std.web.http.headers`.
- `HttpReqV1` (EVRQ) and `HttpRespV1` (EVRS): see `std.web.http.spec` and the encoding section below.

### HttpReqV1 (EVRQ) encoding

All integers are **little-endian**.

```
offset  size  field
0       4     magic = "EVRQ"
4       1     version = 1
5       1     method_code (1=GET, 2=POST, 3=PUT, 4=DELETE, 5=PATCH, 6=HEAD, 7=OPTIONS)
6       2     flags_u16 (must be 0 in v1)
8       4     path_len_u32
12      N     path_bytes
12+N    4     headers_len_u32
...     H     headers_evht_bytes
...     4     body_len_u32
...     B     body_bytes
```

### HttpRespV1 (EVRS) encoding

```
offset  size  field
0       4     magic = "EVRS"
4       1     version = 1
5       1     tag (1=OK, 0=ERR)
6       2     flags_u16 (must be 0 in v1)

if tag==1 (OK):
8       4     status_u32 (e.g. 200, 404)
12      4     headers_len_u32
...     H     headers_evht_bytes
...     4     body_len_u32
...     B     body_bytes

if tag==0 (ERR):
8       4     err_code_u32
12      4     message_len_u32
...     M     message_bytes (UTF-8, may be empty)
```

## Testing via deterministic cassettes

`WebCassetteV1` (EVWC) wraps a request+expected response. You can:
- record cassettes from run-os adapters, and
- replay them in solve-pure (or solve-fs) to test `main.handle_v1` deterministically.

See `docs/web/webcassette-v1.md` and the smoke program `tests/external_pure/std_web_cassette_smoke/src/main.evo.json`.

## What’s intentionally missing in v1 starter

This is a *starter* designed to stabilize the core contracts and make agents productive.
Missing pieces for a full framework (planned follow-ons):
- streaming request bodies / streaming responses (chunked)
- router tables / param capture (`/users/:id`)
- middleware pipeline
- cookie parsing/building
- canonical header merge logic (RFC 9110) inside adapters

