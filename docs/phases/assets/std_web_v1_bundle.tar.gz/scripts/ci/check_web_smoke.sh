#!/usr/bin/env bash
set -euo pipefail

# Run solve-pure smoke suites for std.web
evolang smoke benchmarks/smoke/web-router-smoke.json
evolang smoke benchmarks/smoke/web-cassette-smoke.json
