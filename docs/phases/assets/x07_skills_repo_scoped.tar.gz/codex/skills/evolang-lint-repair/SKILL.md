---
name: evolang-lint-repair
description: Lint Evolang EvoAST JSON files, emit machine-readable diagnostics, and apply JSON Patch repairs deterministically (for autonomous agentic workflows).
metadata:
  short-description: Lint + apply JSON Patch repairs for Evolang
  version: 0.1.0
  kind: script-backed
---

# evolang-lint-repair

This skill is a **deterministic** wrapper around Evolang's linter plus a safe patch-apply loop.
It is designed for **autonomous coding agents** that generate Evolang programs (EvoAST JSON) and need a reliable way to:
1) get structured diagnostics, and
2) apply a proposed repair patch, and
3) re-lint until clean.

## When to use

Use this skill when:
- an Evolang file fails lint/compile due to syntax/arity/type errors,
- you want the agent to "self-repair" by iterating: **lint → patch → lint**,
- you want CI-friendly, machine-readable outputs (no prose).

## Inputs

- `--file PATH`: Path to an Evolang program/module in **EvoAST JSON** form (recommended: `*.evo.json`).
- `--apply-patch PATCH.json` (optional): JSON Patch (RFC 6902) to apply to the EvoAST file.
- `--in-place` (optional): Write patched content back to `--file`.

## Outputs

The script prints a **single JSON object** to stdout:

```json
{
  "ok": true,
  "lint_exit_code": 0,
  "diagnostics": { "...": "EvoDiag JSON" },
  "applied_patch": false,
  "files_modified": []
}
```

- If lint fails or `evolangc` is missing, `ok=false` and `diagnostics` contains a deterministic error payload.

## Workflow (agent loop)

1. Lint:
   - `python3 scripts/lint_repair.py --file src/main.evo.json`

2. If `ok=false` and diagnostics contain errors, the agent produces a **JSON Patch** that fixes *only* the reported issues.

3. Apply + re-lint:
   - `python3 scripts/lint_repair.py --file src/main.evo.json --apply-patch /tmp/repair.patch.json --in-place`

4. Repeat (max 3 iterations). If still failing:
   - perform a small, targeted rewrite (keep diffs minimal),
   - or regenerate the EvoAST cleanly from scratch.

## Hard rules (to keep repairs safe)

- Do **not** apply “broad refactors” as a repair. Keep patches minimal.
- Prefer **replace/remove/add** operations on the smallest subtrees needed.
- Never introduce new dependencies during repair.
- If the file is not valid JSON, do not guess: rewrite into valid JSON first.

## Files

- `scripts/lint_repair.py` — the deterministic wrapper + JSON Patch applier.
