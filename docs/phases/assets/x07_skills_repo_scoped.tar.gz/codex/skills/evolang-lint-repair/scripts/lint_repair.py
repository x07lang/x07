#!/usr/bin/env python3
"""
Deterministic lint + JSON-Patch apply wrapper for Evolang EvoAST JSON files.

Design goals:
- No network.
- Stable JSON output (single object printed to stdout).
- Minimal patch operations supported: add/remove/replace (+ basic 'test').

This is intentionally small and dependency-free (stdlib only).
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Tuple, Union


class PatchError(Exception):
    pass


def _json_pointer_unescape(seg: str) -> str:
    return seg.replace("~1", "/").replace("~0", "~")


def _split_pointer(ptr: str) -> List[str]:
    if ptr == "":
        return []
    if not ptr.startswith("/"):
        raise PatchError(f"Invalid JSON pointer (must start with '/'): {ptr!r}")
    parts = ptr.split("/")[1:]
    return [_json_pointer_unescape(p) for p in parts]


def _get_parent(doc: Any, ptr: str) -> Tuple[Any, Union[str, int]]:
    """
    Return (parent, key) where key is last segment; parent is container holding it.
    For root pointer '', raises PatchError (no parent).
    """
    parts = _split_pointer(ptr)
    if not parts:
        raise PatchError("Pointer refers to document root; no parent.")
    cur = doc
    for seg in parts[:-1]:
        if isinstance(cur, list):
            try:
                idx = int(seg)
            except ValueError:
                raise PatchError(f"Expected list index in pointer, got {seg!r}")
            if idx < 0 or idx >= len(cur):
                raise PatchError(f"Index out of bounds at segment {seg!r}")
            cur = cur[idx]
        elif isinstance(cur, dict):
            if seg not in cur:
                raise PatchError(f"Missing object key {seg!r} while traversing {ptr!r}")
            cur = cur[seg]
        else:
            raise PatchError(f"Cannot traverse into non-container at segment {seg!r}")
    last = parts[-1]
    if isinstance(cur, list):
        if last == "-":
            return cur, last
        try:
            return cur, int(last)
        except ValueError:
            raise PatchError(f"Expected list index at final segment, got {last!r}")
    elif isinstance(cur, dict):
        return cur, last
    else:
        raise PatchError(f"Pointer parent is not a container for {ptr!r}")


def _pointer_get(doc: Any, ptr: str) -> Any:
    parts = _split_pointer(ptr)
    cur = doc
    for seg in parts:
        if isinstance(cur, list):
            try:
                idx = int(seg)
            except ValueError:
                raise PatchError(f"Expected list index in pointer, got {seg!r}")
            if idx < 0 or idx >= len(cur):
                raise PatchError(f"Index out of bounds at segment {seg!r}")
            cur = cur[idx]
        elif isinstance(cur, dict):
            if seg not in cur:
                raise PatchError(f"Missing object key {seg!r} while reading {ptr!r}")
            cur = cur[seg]
        else:
            raise PatchError(f"Cannot traverse into non-container at segment {seg!r}")
    return cur


def _op_add(doc: Any, path: str, value: Any) -> None:
    parent, key = _get_parent(doc, path)
    if isinstance(parent, list):
        if key == "-":
            parent.append(value)
        else:
            idx = key
            if idx < 0 or idx > len(parent):
                raise PatchError(f"add index out of bounds: {idx}")
            parent.insert(idx, value)
    else:
        parent[key] = value


def _op_remove(doc: Any, path: str) -> None:
    parent, key = _get_parent(doc, path)
    if isinstance(parent, list):
        idx = key
        if idx < 0 or idx >= len(parent):
            raise PatchError(f"remove index out of bounds: {idx}")
        del parent[idx]
    else:
        if key not in parent:
            raise PatchError(f"remove missing key: {key!r}")
        del parent[key]


def _op_replace(doc: Any, path: str, value: Any) -> None:
    # spec: path must exist
    _ = _pointer_get(doc, path)
    _op_remove(doc, path)
    _op_add(doc, path, value)


def _op_test(doc: Any, path: str, value: Any) -> None:
    cur = _pointer_get(doc, path)
    if cur != value:
        raise PatchError(f"test failed at {path!r}: expected {value!r}, got {cur!r}")


def apply_json_patch(doc: Any, patch_ops: List[Dict[str, Any]]) -> Any:
    for op in patch_ops:
        if not isinstance(op, dict):
            raise PatchError(f"Patch op is not an object: {op!r}")
        typ = op.get("op")
        path = op.get("path")
        if not isinstance(typ, str) or not isinstance(path, str):
            raise PatchError(f"Patch op missing op/path: {op!r}")
        if typ == "add":
            _op_add(doc, path, op.get("value"))
        elif typ == "remove":
            _op_remove(doc, path)
        elif typ == "replace":
            _op_replace(doc, path, op.get("value"))
        elif typ == "test":
            _op_test(doc, path, op.get("value"))
        else:
            raise PatchError(f"Unsupported patch op: {typ!r}")
    return doc


def run_linter(evolangc: str, file_path: Path) -> Tuple[int, str, str]:
    """
    Runs evolangc lint and returns (exit_code, stdout, stderr).
    The linter is expected to emit EvoDiag JSON on stdout.
    """
    cmd_variants = [
        [evolangc, "lint", "--format", "evodiag-json", "--path", str(file_path)],
        [evolangc, "lint", "--emit-json", "--path", str(file_path)],
        [evolangc, "lint", "--json", "--path", str(file_path)],
        [evolangc, "lint", str(file_path)],
    ]
    last = (127, "", f"evolangc not found: {evolangc}")
    for cmd in cmd_variants:
        try:
            p = subprocess.run(cmd, capture_output=True, text=True)
        except FileNotFoundError:
            return (127, "", f"evolangc not found: {evolangc}")
        # Heuristic: if subcommand/flag unsupported, try next variant.
        stderr = p.stderr.lower()
        if "unknown" in stderr or "unrecognized" in stderr or "unexpected argument" in stderr:
            last = (p.returncode, p.stdout, p.stderr)
            continue
        return (p.returncode, p.stdout, p.stderr)
    return last


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True, help="Path to EvoAST JSON file (e.g., src/main.evo.json).")
    ap.add_argument("--apply-patch", help="Path to JSON Patch file (RFC 6902) to apply to the EvoAST.")
    ap.add_argument("--in-place", action="store_true", help="Write patched EvoAST back to --file.")
    ap.add_argument("--evolangc", default=os.environ.get("EVOLANGC", "evolangc"), help="evolangc binary (default: evolangc)")
    args = ap.parse_args()

    file_path = Path(args.file)
    out: Dict[str, Any] = {
        "ok": False,
        "lint_exit_code": None,
        "diagnostics": None,
        "applied_patch": False,
        "files_modified": [],
    }

    if not file_path.exists():
        out["diagnostics"] = {
            "schema": "evodiag@0.1.0",
            "errors": [{
                "code": "EVOFILE_NOT_FOUND",
                "message": f"File does not exist: {str(file_path)}",
                "path": str(file_path),
            }],
            "warnings": [],
        }
        print(json.dumps(out, ensure_ascii=False, sort_keys=True))
        return 2

    # Load JSON (EvoAST).
    try:
        doc = json.loads(file_path.read_text(encoding="utf-8"))
    except Exception as e:
        out["diagnostics"] = {
            "schema": "evodiag@0.1.0",
            "errors": [{
                "code": "EVOJSON_PARSE",
                "message": f"Invalid JSON (EvoAST): {e}",
                "path": str(file_path),
            }],
            "warnings": [],
        }
        print(json.dumps(out, ensure_ascii=False, sort_keys=True))
        return 1

    # Apply patch if requested.
    if args.apply_patch:
        patch_path = Path(args.apply_patch)
        try:
            patch_ops = json.loads(patch_path.read_text(encoding="utf-8"))
            if not isinstance(patch_ops, list):
                raise PatchError("Patch file must be a JSON array of ops.")
            apply_json_patch(doc, patch_ops)
            out["applied_patch"] = True
            if args.in_place:
                file_path.write_text(json.dumps(doc, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
                out["files_modified"].append(str(file_path))
        except Exception as e:
            out["diagnostics"] = {
                "schema": "evodiag@0.1.0",
                "errors": [{
                    "code": "EVOPATCH_APPLY_FAILED",
                    "message": str(e),
                    "path": str(patch_path),
                }],
                "warnings": [],
            }
            print(json.dumps(out, ensure_ascii=False, sort_keys=True))
            return 1

    # Run evolangc linter.
    exit_code, stdout, stderr = run_linter(args.evolangc, file_path)
    out["lint_exit_code"] = exit_code

    diag_obj: Any = None
    if stdout.strip():
        try:
            diag_obj = json.loads(stdout)
        except Exception:
            # Wrap non-JSON into a deterministic diagnostic.
            diag_obj = {
                "schema": "evodiag@0.1.0",
                "errors": [{
                    "code": "EVOLINT_NON_JSON",
                    "message": "evolangc lint did not emit JSON. See raw_stdout_b64.",
                    "path": str(file_path),
                }],
                "warnings": [],
                "raw_stdout_b64": base64.b64encode(stdout.encode("utf-8")).decode("ascii"),
            }
    else:
        diag_obj = {
            "schema": "evodiag@0.1.0",
            "errors": [{
                "code": "EVOLINT_EMPTY_STDOUT",
                "message": "evolangc lint emitted empty stdout; expected EvoDiag JSON.",
                "path": str(file_path),
            }],
            "warnings": [],
        }

    out["diagnostics"] = diag_obj
    out["ok"] = (exit_code == 0)
    # Keep stderr out of the main structure unless you want it; agents can re-run with verbose.
    if not out["ok"] and stderr.strip():
        out["diagnostics"].setdefault("notes", [])
        out["diagnostics"]["notes"].append({"code": "EVOLINT_STDERR", "message": stderr.strip()[:4000]})

    print(json.dumps(out, ensure_ascii=False, sort_keys=True))
    return 0 if out["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
