---
name: evolang-package
description: Manage Evolang project manifests and lockfiles for reproducible builds (init, lock, verify). Designed for autonomous agents.
metadata:
  short-description: Evolang manifest + lockfile management
  version: 0.1.0
  kind: script-backed
---

# evolang-package

This skill helps an agent keep Evolang projects reproducible by maintaining:

- `evolang.json` — project manifest (human/agent edited)
- `evolang.lock` — deterministic lockfile (machine generated)

## When to use

Use this skill when:
- creating a new Evolang project,
- adding/updating dependencies,
- ensuring the repo contains a lockfile that matches the manifest.

## Manifest format (v0)

`evolang.json`:

```json
{
  "manifest_version": 0,
  "name": "my-app",
  "version": "0.1.0",
  "entry": "src/main.evo.json",
  "module_root": "src",
  "world": "solve-pure",
  "deps": [
    { "id": "evolang:stdlib@0.1.1", "source": "path", "path": "deps/evolang/stdlib" }
  ]
}
```

## Lockfile format (v0)

`evolang.lock`:

```json
{
  "lock_version": 0,
  "deps": [
    { "id": "evolang:stdlib@0.1.1", "source": "path", "path": "deps/evolang/stdlib", "sha256": "..." }
  ]
}
```

## Commands

- Initialize:
  - `python3 scripts/package.py init`

- Generate lock:
  - `python3 scripts/package.py lock`

- Verify lock is up to date:
  - `python3 scripts/package.py verify`

## Determinism rules

- Directory hashing is stable: lexicographic file order, hash over (relative_path + file_bytes).
- No timestamps in the lockfile.
- No network access in v0 (path deps only).
