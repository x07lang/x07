#!/usr/bin/env python3
"""
Minimal, deterministic manifest+lockfile manager for Evolang projects.

v0 scope:
- path dependencies only (no network fetch).
- stable directory hashing (path + bytes, lexicographic order).
- deterministic JSON output (sorted keys, no timestamps).

This is a *starting point* for an agent-friendly packaging workflow.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import hashlib
from pathlib import Path
from typing import Any, Dict, List, Tuple


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def hash_path(path: Path) -> str:
    """
    Deterministic hash for a file or directory.
    For directories: sha256 over concatenation of (relative_path + NUL + file_bytes) for all files,
    with relative paths sorted lexicographically.
    """
    if path.is_file():
        return sha256_bytes(path.read_bytes())
    if not path.is_dir():
        raise FileNotFoundError(str(path))

    items: List[Tuple[str, bytes]] = []
    for p in sorted(path.rglob("*")):
        if p.is_file():
            rel = p.relative_to(path).as_posix()
            items.append((rel, p.read_bytes()))

    h = hashlib.sha256()
    for rel, data in items:
        h.update(rel.encode("utf-8"))
        h.update(b"\0")
        h.update(data)
        h.update(b"\n")
    return h.hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def cmd_init(manifest_path: Path) -> int:
    if manifest_path.exists():
        print(f"manifest already exists: {manifest_path}", file=sys.stderr)
        return 1
    manifest = {
        "manifest_version": 0,
        "name": "my-app",
        "version": "0.1.0",
        "entry": "src/main.evo.json",
        "module_root": "src",
        "world": "solve-pure",
        "deps": [
            # Example pinned stdlib vendored into deps/evolang/stdlib
            {"id": "evolang:stdlib@0.1.1", "source": "path", "path": "deps/evolang/stdlib"},
        ],
    }
    write_json(manifest_path, manifest)
    return 0


def cmd_lock(manifest_path: Path, lock_path: Path) -> int:
    manifest = read_json(manifest_path)
    deps = manifest.get("deps", [])
    if not isinstance(deps, list):
        raise SystemExit("manifest.deps must be a list")

    locked: List[Dict[str, Any]] = []
    for dep in deps:
        if not isinstance(dep, dict):
            raise SystemExit("each dep must be an object")
        src = dep.get("source")
        if src != "path":
            raise SystemExit(f"v0 only supports path deps; got source={src!r}")
        dep_path = Path(dep.get("path", ""))
        if not dep_path.exists():
            raise SystemExit(f"dep path missing: {dep_path}")
        locked.append({
            "id": dep.get("id"),
            "source": "path",
            "path": dep.get("path"),
            "sha256": hash_path(dep_path),
        })

    # Stable ordering by id then path.
    locked.sort(key=lambda d: (str(d.get("id")), str(d.get("path"))))

    lock = {"lock_version": 0, "deps": locked}
    write_json(lock_path, lock)
    return 0


def cmd_verify(manifest_path: Path, lock_path: Path) -> int:
    if not lock_path.exists():
        print(f"missing lockfile: {lock_path}", file=sys.stderr)
        return 1
    expected = read_json(lock_path)
    tmp_path = lock_path.with_suffix(".lock.tmp")
    cmd_lock(manifest_path, tmp_path)
    got = read_json(tmp_path)
    tmp_path.unlink(missing_ok=True)

    if expected != got:
        print("lockfile out of date (expected != recomputed)", file=sys.stderr)
        # Print a small diff hint deterministically.
        print(json.dumps({"expected": expected, "recomputed": got}, sort_keys=True)[:4000], file=sys.stderr)
        return 1
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", default=os.environ.get("EVOLANG_MANIFEST", "evolang.json"))
    ap.add_argument("--lock", default=os.environ.get("EVOLANG_LOCK", "evolang.lock"))
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init")
    sub.add_parser("lock")
    sub.add_parser("verify")
    args = ap.parse_args()

    manifest_path = Path(args.manifest)
    lock_path = Path(args.lock)

    if args.cmd == "init":
        return cmd_init(manifest_path)
    if args.cmd == "lock":
        return cmd_lock(manifest_path, lock_path)
    if args.cmd == "verify":
        return cmd_verify(manifest_path, lock_path)
    raise SystemExit("unknown command")


if __name__ == "__main__":
    raise SystemExit(main())
