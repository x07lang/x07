#!/usr/bin/env python3
"""
Deterministic build+run wrapper for Evolang (C backend).

Assumptions (can be adjusted as your toolchain evolves):
- `evolangc compile ... --emit-c <path>` emits a self-contained C file.
- A system C compiler (cc/clang/gcc) is available.
- The produced executable reads stdin bytes and writes stdout bytes (solve-style).

This wrapper is intended for autonomous agents: it emits one JSON report to stdout.
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple


def try_compile(evolangc: str, entry: Path, module_root: Path, world: str, out_c: Path) -> Tuple[bool, Dict[str, Any]]:
    cmd_variants = [
        [evolangc, "compile", "--entry", str(entry), "--module-root", str(module_root), "--world", world, "--emit-c", str(out_c)],
        [evolangc, "compile", "--entry", str(entry), "--module-root", str(module_root), "--world", world, "--out-c", str(out_c)],
        [evolangc, "compile", str(entry), "--module-root", str(module_root), "--world", world, "--emit-c", str(out_c)],
    ]
    last: Dict[str, Any] = {"cmd": None, "exit_code": 127, "stdout": "", "stderr": f"evolangc not found: {evolangc}"}
    for cmd in cmd_variants:
        try:
            p = subprocess.run(cmd, capture_output=True, text=True)
        except FileNotFoundError:
            return False, last
        last = {"cmd": cmd, "exit_code": p.returncode, "stdout": p.stdout, "stderr": p.stderr}
        # If the CLI variant is wrong, try next.
        stderr_l = (p.stderr or "").lower()
        if "unknown" in stderr_l or "unrecognized" in stderr_l or "unexpected argument" in stderr_l:
            continue
        # Otherwise accept result.
        return (p.returncode == 0), last
    return False, last


def cc_compile(cc: str, c_path: Path, exe_path: Path, cflags: List[str]) -> Tuple[bool, Dict[str, Any]]:
    cmd = [cc, "-std=c11", "-O2", "-o", str(exe_path), str(c_path)] + cflags
    try:
        p = subprocess.run(cmd, capture_output=True, text=True)
    except FileNotFoundError:
        return False, {"cmd": cmd, "exit_code": 127, "stdout": "", "stderr": f"C compiler not found: {cc}"}
    return (p.returncode == 0), {"cmd": cmd, "exit_code": p.returncode, "stdout": p.stdout, "stderr": p.stderr}


def run_exe(exe_path: Path, stdin_bytes: bytes, timeout_ms: int) -> Tuple[bool, Dict[str, Any]]:
    t0 = time.time()
    try:
        p = subprocess.run([str(exe_path)], input=stdin_bytes, capture_output=True, timeout=timeout_ms / 1000.0)
        dt = time.time() - t0
        return (p.returncode == 0), {
            "cmd": [str(exe_path)],
            "exit_code": p.returncode,
            "time_s": dt,
            "stdout_b64": base64.b64encode(p.stdout).decode("ascii"),
            "stderr": (p.stderr or b"").decode("utf-8", errors="replace")[:4000],
        }
    except subprocess.TimeoutExpired as e:
        dt = time.time() - t0
        return False, {
            "cmd": [str(exe_path)],
            "exit_code": 124,
            "time_s": dt,
            "stdout_b64": base64.b64encode(e.stdout or b"").decode("ascii"),
            "stderr": ("TIMEOUT\n" + ((e.stderr or b"").decode("utf-8", errors="replace")))[:4000],
        }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--entry", default="src/main.evo.json")
    ap.add_argument("--module-root", default="src")
    ap.add_argument("--world", default=os.environ.get("EVOLANG_WORLD", "solve-pure"))
    ap.add_argument("--stdin", help="Optional input file passed to program stdin.")
    ap.add_argument("--out-dir", default="target/evolang-build")
    ap.add_argument("--evolangc", default=os.environ.get("EVOLANGC", "evolangc"))
    ap.add_argument("--cc", default=os.environ.get("CC", "cc"))
    ap.add_argument("--cflags", default="", help="Extra flags, e.g. '-g -O0'.")
    ap.add_argument("--timeout-ms", type=int, default=5000)
    ap.add_argument("--write-stdout", help="Write raw stdout bytes to this path.")
    args = ap.parse_args()

    entry = Path(args.entry)
    module_root = Path(args.module_root)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    report: Dict[str, Any] = {"compile": {}, "cc": {}, "run": {}}

    if not entry.exists():
        report["compile"] = {"ok": False, "exit_code": 2, "error": f"entry not found: {str(entry)}"}
        print(json.dumps(report, sort_keys=True))
        return 2

    c_path = out_dir / "program.c"
    exe_path = out_dir / "program.exe"

    ok, comp = try_compile(args.evolangc, entry, module_root, args.world, c_path)
    report["compile"] = {
        "ok": ok,
        "exit_code": comp.get("exit_code"),
        "cmd": comp.get("cmd"),
        "stdout": (comp.get("stdout") or "")[-4000:],
        "stderr": (comp.get("stderr") or "")[-4000:],
        "c_path": str(c_path) if c_path.exists() else None,
    }
    if not ok:
        print(json.dumps(report, sort_keys=True))
        return 1

    ok2, cc_rep = cc_compile(args.cc, c_path, exe_path, args.cflags.split() if args.cflags.strip() else [])
    report["cc"] = {
        "ok": ok2,
        "exit_code": cc_rep.get("exit_code"),
        "cmd": cc_rep.get("cmd"),
        "stdout": (cc_rep.get("stdout") or "")[-4000:],
        "stderr": (cc_rep.get("stderr") or "")[-4000:],
        "exe_path": str(exe_path) if exe_path.exists() else None,
    }
    if not ok2:
        print(json.dumps(report, sort_keys=True))
        return 1

    stdin_bytes = b""
    if args.stdin:
        stdin_path = Path(args.stdin)
        stdin_bytes = stdin_path.read_bytes()

    ok3, run_rep = run_exe(exe_path, stdin_bytes, args.timeout_ms)
    report["run"] = run_rep
    report["run"]["ok"] = ok3

    if args.write_stdout and "stdout_b64" in run_rep:
        out_bytes = base64.b64decode(run_rep["stdout_b64"].encode("ascii"))
        Path(args.write_stdout).write_bytes(out_bytes)

    print(json.dumps(report, sort_keys=True))
    return 0 if (ok and ok2 and ok3) else 1


if __name__ == "__main__":
    raise SystemExit(main())
