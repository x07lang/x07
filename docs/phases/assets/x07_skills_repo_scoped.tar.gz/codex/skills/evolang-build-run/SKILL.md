---
name: evolang-build-run
description: Compile Evolang (EvoAST JSON) to native via the C backend and run it, returning a machine-readable run report (stdout bytes + stderr text).
metadata:
  short-description: Build + run Evolang programs
  version: 0.1.0
  kind: script-backed
---

# evolang-build-run

This skill provides a **single deterministic CLI** for an autonomous agent to:
- compile Evolang to a native executable using the **C backend**, and
- run the resulting program with binary stdin, capturing binary stdout.

## When to use

Use this skill when:
- you need to validate that a generated Evolang program actually runs,
- you want a single JSON report for compilation + execution (good for CI and agent loops).

## Inputs

- `--entry PATH` (default: `src/main.evo.json`)
- `--module-root DIR` (default: `src`)
- `--world NAME` (default: `solve-pure`)
  - For production, you can also use `run-os` / `run-os-sandboxed` **if your toolchain provides them**.
- `--stdin PATH` (optional): binary file passed to the program via stdin
- `--out-dir DIR` (default: `target/evolang-build`)
- `--cc CC` (default: `cc`)
- `--cflags "..."`
- `--timeout-ms N` (default: 5000)

## Outputs

Prints a single JSON object to stdout:

```json
{
  "compile": { "ok": true, "exit_code": 0, "c_path": "...", "exe_path": "..." },
  "run": { "ok": true, "exit_code": 0, "stdout_b64": "...", "stderr": "..." }
}
```

## Notes

- This skill intentionally does not fetch dependencies. Pair with `evolang-package` for pinning/vendoring.
- If your Evolang compiler already has a `build` subcommand, update the script to call it directly.
