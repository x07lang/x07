# WEB-01 + WEB-02 — drop-in delta bundle (std.web.http1)

This bundle adds **deterministic HTTP/1.1 framing** for Evolang:

- `std.web.http1.parse_req_v1` — strict request parsing into a pinned binary request doc (`WebReqDocV1`)
- `std.web.http1.build_resp_v1` — canonical response serialization from `HeadersTableV1` (EVHT) + body

### Files

- Docs:
  - `docs/web/http1-framing-v1.md`
- Package:
  - `packages/evolang-ext-web/0.1.1/package.json`
  - `packages/evolang-ext-web/0.1.1/modules/std/web/http1/module.evo.json`
- Compile stubs:
  - `tests/external_os/web_http1_parse_smoke/src/main.evo.json`
  - `tests/external_os/web_http1_build_resp_smoke/src/main.evo.json`
- Solve-pure smoke suites:
  - `benchmarks/solve-pure/phaseWEB01-http1-parse-smoke.json`
  - `benchmarks/solve-pure/phaseWEB02-http1-build-resp-smoke.json`

### Quick usage (Evolang)

```lisp
; Parse a request
(let r (std.web.http1.parse_req_v1 raw (bytes.alloc 0)))
(if (result_bytes.is_ok r)
  (let req (result_bytes.unwrap_or r (bytes.alloc 0)))
  ...
)

; Build a response
(let rr (std.web.http1.build_resp_v1 200 headers_evht body))
...
```
