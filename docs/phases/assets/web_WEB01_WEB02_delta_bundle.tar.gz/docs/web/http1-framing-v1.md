# HTTP/1 Framing v1 (std.web.http1)

This document pins the deterministic, security-oriented HTTP/1.1 *framing* rules used by Evolang's `std.web.http1` modules.

Goals:

- Deterministic behavior for agentic code (no ambiguous parsing).
- Defense against request-smuggling style ambiguity (Transfer-Encoding vs Content-Length).
- Canonical, comparable bytes encodings for parsed requests and serialized responses.

Non-goals (v1):

- Chunked transfer-coding support (v1 rejects `Transfer-Encoding`).
- HTTP/2 / HTTP/3.
- Trailers, Upgrade, CONNECT tunneling.

---

## 1. On-wire parsing contract (requests)

### 1.1 Function surface

`std.web.http1.parse_req_v1(raw: bytes, caps: bytes) -> result_bytes`

- **OK**: `result_bytes.ok(req_doc_bytes)`
- **ERR**: `result_bytes.err(spec_err_i32)`

The `req_doc_bytes` are encoded as `WebReqDocV1` (see §3).

### 1.2 Acceptable request form

Only **origin-form** request-targets are accepted:

```
METHOD SP request-target SP HTTP/1.1 CRLF
*( header-field CRLF )
CRLF
[ message-body ]
```

- `HTTP/1.0` is rejected (v1 server core is HTTP/1.1 only).
- Line folding (obs-fold) is rejected (any header line that begins with SP or HTAB is an error).
- Header field-names are normalized to lowercase ASCII in the output table.

### 1.3 Message body rules

To avoid ambiguity:

- Any presence of `Transfer-Encoding` is an error (`SPEC_ERR_HTTP1_TRANSFER_ENCODING_UNSUPPORTED`).
- `Content-Length` may appear **0+ times**:
  - If it appears more than once, all values must be identical after trimming OWS and after splitting on commas.
  - If any values differ → `SPEC_ERR_HTTP1_CONTENT_LENGTH_CONFLICT`.
- If a non-zero body is present, **Content-Length must be present**, and must match the number of body bytes provided in `raw`.
  - Extra bytes after the body are rejected (`SPEC_ERR_HTTP1_BODY_SIZE_MISMATCH`).

---

## 2. On-wire serialization contract (responses)

### 2.1 Function surface

`std.web.http1.build_resp_v1(status: i32, headers_evht: bytes, body: bytes) -> result_bytes`

- **OK**: `result_bytes.ok(raw_http_bytes)`
- **ERR**: `result_bytes.err(spec_err_i32)`

### 2.2 Status line

Always emits:

`HTTP/1.1 <status-decimal> <reason>
`

Reason phrases are **deterministic** and minimal:

- 200 → `OK`
- otherwise → `ERR`

### 2.3 Headers

Input headers are provided as `HeadersTableV1` (EVHT, §4) and MUST be sorted `(name,value)`.

Rules:

- Any presence of `transfer-encoding` is an error (`SPEC_ERR_HTTP1_TRANSFER_ENCODING_UNSUPPORTED`).
- Any input `content-length` rows are ignored/stripped; the serializer always emits a single canonical `content-length` computed from `body.len`.
- Duplicate header names are merged into **one field line per name**, by joining values with `", "` *except*:
  - `set-cookie` is **never merged**; each value is emitted as a separate `set-cookie:` line.

After headers, emits the empty line `
` and then `body` bytes.

---

## 3. WebReqDocV1 encoding (req_doc_bytes)

All integers are little-endian.

```
Offset  Size  Field
0       4     magic = "EWHR"
4       2     version_u16 = 1
6       1     method_u8   (see table below)
7       1     flags_u8    (must be 0)
8       4     target_len_u32
12      N     target_bytes (exactly target_len)
12+N    4     headers_len_u32
...     M     headers_evht_bytes (exactly headers_len)
...     4     body_len_u32
...     K     body_bytes (exactly body_len)
```

Method codes:

- 1 = GET
- 2 = POST
- 3 = PUT
- 4 = DELETE
- 5 = HEAD
- 6 = OPTIONS
- 7 = PATCH

Unknown methods are rejected in v1.

---

## 4. HeadersTableV1 (EVHT) encoding

EVHT is a compact, sorted, binary-searchable header table.

All integers are little-endian.

Header:

```
Offset  Size  Field
0       4     magic = "EVHT"
4       2     version_u16 = 1
6       2     count_u16
8       16*count  rows[]
8+16*count  ...   payload bytes
```

Row entry (16 bytes):

```
name_off_u32   (offset into payload, relative to payload start)
name_len_u32
value_off_u32  (offset into payload, relative to payload start)
value_len_u32
```

Conventions:

- Field-names are stored **lowercase ASCII**.
- The row array is sorted by `(name_bytes, value_bytes)` lexicographically.
- Offsets are relative to the start of the payload region (i.e., the byte immediately after the last row entry).

---

## 5. SPEC_ERR numeric space (http1)

All errors are `i32` codes returned in `result_bytes.err(code)`.

HTTP/1 framing uses the dedicated range:

- `0x6200..0x62FF` (decimal 25088..25343)

Pinned codes:

- `0x6200` SPEC_ERR_HTTP1_BAD_START_LINE
- `0x6201` SPEC_ERR_HTTP1_UNSUPPORTED_VERSION
- `0x6202` SPEC_ERR_HTTP1_BAD_METHOD
- `0x6203` SPEC_ERR_HTTP1_HEADER_TOO_LARGE
- `0x6204` SPEC_ERR_HTTP1_TOO_MANY_HEADERS
- `0x6205` SPEC_ERR_HTTP1_BAD_HEADER_LINE
- `0x6206` SPEC_ERR_HTTP1_OBS_FOLD
- `0x6207` SPEC_ERR_HTTP1_TRANSFER_ENCODING_UNSUPPORTED
- `0x6208` SPEC_ERR_HTTP1_CONTENT_LENGTH_INVALID
- `0x6209` SPEC_ERR_HTTP1_CONTENT_LENGTH_CONFLICT
- `0x620A` SPEC_ERR_HTTP1_BODY_WITHOUT_CONTENT_LENGTH
- `0x620B` SPEC_ERR_HTTP1_BODY_SIZE_MISMATCH
